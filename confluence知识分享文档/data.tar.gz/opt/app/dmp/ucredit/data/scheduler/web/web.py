#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys,os
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
import glob
import re
from bottle import request,run,route,template,redirect,response,debug
from sql import *
from data.scheduler.utils import get_date,get_localhost,do_sql as execute_sql,param2str,str2obj,obj2mt,get_pid,store_pid,kill_pid
from data.scheduler.conf import conf
from data.scheduler.worker import Asker
from data.scheduler.job import JobVar
from subprocess import Popen,PIPE,STDOUT
from SocketServer import ThreadingMixIn
from wsgiref.simple_server import WSGIServer
from collections import OrderedDict
from permissions import (First_class_permission_check, 
                         Second_class_permission_check, Third_class_permission_check)

urls=dict(
    index_url='/',
    top_url='/top.py',
    bottom_url='/bottom.py',
    left_url='/left.py',
    right_url='/right.py',
    frame_url='/frame.py',
    login_url='/login.py',
    total_url='/total.py',
    job_url='/job.py',
    record_url='/record.py',
    upload_url='/upload.py',
)

def get_tpl_path():
    if os.name!='nt':
        path='{0}/web/tpl'.format(conf.sched_path)
    else:
        path='{0}/tpl'.format(os.getcwd())
    return path

tpls=dict((os.path.basename(tpl).replace('.','_'),tpl) for tpl in glob.glob(get_tpl_path()+'/*.tpl'))

job_home=conf.job_path
log_home=conf.worker_log_path

attrs=dict(
    man='负责人',
    group='任务组',
    host='服务器',
    state='任务状态',
    tx_time='数据日期',
    priority='优先级',
    zipper='是否拉链',
    transfer='可转移',
    enable='是否启用',
    hour='时间段',
)

sched_menus=OrderedDict(
    {
        1:('总体监控','total_tpl'),
        2:('任务列表','job_tpl'),
        3:('任务记录','record_tpl'),
        4:('运行时长','runtime_tpl'),
        5:('任务操作','cmd_tpl'),
        6:('任务配置','cfg_tpl'),
    }
)

hive_menus=OrderedDict(
    {
        1:('任务监控','http://nothing:8081/'),
    }
)

admin_menus=OrderedDict(
    {
        1:('用户管理','http://nothing:8081/'),
    }
)

menus=OrderedDict(
    {
        1:('调度系统',sched_menus),
        2:('抽取管理',hive_menus),
        3:('用户管理', admin_menus),
    }
)

total_opers=[(name,attrs[name]) for name in ('man','group','host','priority','hour','tx_time')]

job_opers=OrderedDict(
    {
        1:('do_job','执行任务'),
        2:('loop_job','循环执行'),
        3:('rerun_job','重跑任务'),
        4:('kill_job','杀死任务'),
        5:('get_job','查看任务'),
        6:('add_job','增加任务'),
        7:('update_job','更新任务'),
        8:('delete_job','删除任务'),
    }
)

cfg_opers=OrderedDict(
    {
        1:('quick_add','一键加任务'),
        2:('extract_table','表数据抽取'),
        3:('etl_table','表间隔抽取'),
        4:('etl_log','日志抽取'),
        5:('data_source', '数据源列表')
        #1:('quick_add','one key add task'),
        #2:('extract_table','table data extract'),
        #3:('etl_table','table interval extract'),
        #4:('etl_log','log extract'),
        #5:('data_source', 'data source')
    }
)

record_opers=OrderedDict(
    {
        9:('cat_log','查看日志'),
        10:('get_log','历史记录'),
        11:('get_record','查看记录'),
        12:('update_record','更新记录'),
        13:('forward_depend','前置依赖'),
        14:('backward_depend','后置依赖'),
        15:('delete_record','删除记录'),
        16:('delete_log','删除日志'),
    }
)
cmd_opers = OrderedDict()
cmd_opers.update(job_opers)
cmd_opers.update(record_opers)
opers_dict=dict((k,v) for k,v in cmd_opers.values())
opers_dict['delete_depend']='删除依赖'

dims=('man','group','host','priority','state','tx_time')
states=('UNSTART','WAIT','PENDING','TRANSFER','RUNNING','RETRY','TIMEOUT','KILLED','FAILED','DONE')
hosts=conf.workers
dbc=conf.sched_dbc

def get_txtimes():
    var=JobVar()
    tx_times=dict(
        txmonth=var.var_txmonth(),
        txdate=var.var_txdate(),
        txhour=var.var_txhour(),
        txminute=var.var_txminute(),
        )
    return tx_times

def do_sql(sql,**kwargs):
    try:
        return execute_sql(sql,dbc=dbc,**kwargs)
    except Exception,error:
        print error
        return error
    
def _get_jobs_sql_dim_field(dim_name):
    if dim_name=='host':
        dim_field='IFNULL(r.`host`,j.`host`)'
    elif dim_name=='hour':
        dim_field='HOUR(r.`start_time`)'
    elif dim_name=='tx_time':
        dim_field='r.`tx_time`'
    else:
        dim_field='j.`{dim_name}`'.format(dim_name=dim_name)
    return dim_field
    
def get_total_jobs(**kwargs):
    dim_field=_get_jobs_sql_dim_field(kwargs.get('dim_name'))
    sql=total_jobs_sql.format(dim_field=dim_field,**kwargs)
    return do_sql(sql,has_fields=True)

def count_rows(sql,**kwargs):
    idx=sql.find('FROM')
    stop_idx=sql.find('LIMIT')
    sql="SELECT COUNT(1) "+sql[idx:stop_idx].format(**kwargs)
    return do_sql(sql)[0][0]

def get_job_dims():
    names=dims[:4]
    job_dims=dict((name,set()) for name in names)
    rows=do_sql(dim_values_sql,to_dict=True)
    for row in rows:
        for name,value in row.items():
            if name not in names:
                continue
            job_dims[name].add(value)
    job_dims['host']=hosts
    return job_dims

def get_jobs(**kwargs):
    dim_values=get_job_dims()
    total_rows=count_rows(jobs_sql,**kwargs)
    sql=jobs_sql.format(**kwargs)
    rows=do_sql(sql,has_fields=True)
    return dict(rows=rows,nrows=len(rows)-1,total_rows=total_rows,dim_values=dim_values)

def get_record_dims():
    record_dims=dict((name,set()) for name in dims)
    rows=do_sql(dim_values_sql,to_dict=True)
    for row in rows:
        for name,value in row.items():
            record_dims[name].add(value)
    record_dims['state']=states
    record_dims['host']=hosts
    return record_dims

def _get_records_sql_dim_field(dim_name,dim_value):
    if dim_value=='全部':
        return '1=1'
    kw=dict()
    if dim_value=='None':
        kw['op']='IS'
        kw['dim_value']='NULL'
    else:
        kw['op']='='
        kw['dim_value']=int(dim_value) if dim_name=='hour' else dim_value
    if dim_name=='host':
        return "r.`host` {op} '{dim_value}'".format(**kw)
    elif dim_name=='hour':
        return "HOUR(r.`start_time`) {op} {dim_value}".format(**kw)
    elif dim_name=='tx_time':
        return "r.`tx_time` {op} {dim_value}".format(**kw)
    else:
        return "j.`{dim_name}` {op} '{dim_value}'".format(dim_name=dim_name,**kw)

def get_job_records(**kwargs):
    dim_values=get_record_dims()
    kwargs['dim_field']=_get_records_sql_dim_field(kwargs.get('dim_name'),kwargs.get('dim_value'))
    total_rows=count_rows(job_records_sql,**kwargs)
    sql=job_records_sql.format(**kwargs)
    rows=do_sql(sql,has_fields=True)
    return dict(rows=rows,nrows=len(rows)-1,total_rows=total_rows,dim_values=dim_values)

def get_runtime_records(**kwargs):
    if kwargs.get('tx_time')==get_date():
        sql=runtime_records_sql.format(**kwargs)
    else:
        sql=runtime_logs_sql.format(**kwargs)
    return do_sql(sql,has_fields=True)

def get_cmd_dims():
    cmd_dims=get_job_dims()
    cmd_dims['zipper']=(0,1)
    cmd_dims['transfer']=(0,1)
    cmd_dims['enable']=(0,1)
    return cmd_dims

def get_job(name):
    sql=job_sql2.format(name=name)
    rows=do_sql(sql,to_dict=True)
    try:
        return rows[0]
    except IndexError:
        return {}
    
def search_job(name):
    sql=job_sql3.format(name=name)
    rows=do_sql(sql,to_dict=True)
    return rows

def get_depends(name):
    sql=depends_sql.format(name=name)
    rows=do_sql(sql,to_dict=True)
    return rows

def get_record(name):
    sql=record_sql2.format(name=name)
    rows=do_sql(sql,to_dict=True)
    try:
        return rows[0]
    except IndexError:
        return {}

def check_login(username,password):
    if all([username,password]):
        sql=check_login_sql.format(name=username)
        passwd=do_sql(sql)
        if not passwd:
            return False
        if passwd[0][0]==password:
            return True
    return False

def get_cookie_user():
    return request.get_cookie('sched_user','',secret='sched-cookie-secret')

def set_cookie_user(user):
    response.set_cookie("sched_user",user,secret='sched-cookie-secret')

def get_shared_params():
    params=dict(date=get_date(),dim_names=dims,attrs=attrs,all='全部',job_home=job_home,log_home=log_home,**tpls)
    params.update(urls)
    params.update(get_txtimes())
    return params

def get_total_params():
    shared=get_shared_params()
    query=request.query
    dim_name=query.get('dim_name','man')
    params=dict(dim_name=dim_name,
                dim_alias=attrs[dim_name],
                total_opers=total_opers,
                **shared)
    params['rows']=get_total_jobs(**params)
    return params

def get_job_params(rows_func=get_jobs):
    shared=get_shared_params()
    query=request.query
    page_offset=int(query.get('page_offset',0))
    page_rows=int(query.get('page_rows',20))
    params=dict(name=query.get('name','').replace('*','%'),
                dim_name=query.get('dim_name','man'),
                dim_value=query.get('dim_value','man'),
                link_id=int(query.get('link_id',0)),
                exact=int(query.get('exact',0)),
                page_offset=page_offset,
                page_rows=page_rows,
                goto_no=query.get('goto_no',''),
                **shared)
    for name in dims:
        params[name]=query.get(name,'全部')
    rows_params=rows_func(**params)
    nrows=rows_params['nrows']
    total_rows=rows_params['total_rows']
    page_no=int(query.get('page_no',1))
    params['page_no']=page_no
    params['sum_rows']=(page_no-1)*page_rows+nrows
    total_page=int(total_rows/page_rows)
    if total_rows%page_rows>0:
        total_page+=1
    params['total_page']=total_page
    params.update(rows_params)
    return params

def get_record_params():
    return get_job_params(get_job_records)

def get_runtime_params():
    params=get_shared_params()
    query=request.query
    params['topn']=int(query.get('topn',50))
    params['tx_time']=query.get('tx_time',get_date())
    params['rows']=get_runtime_records(**params)
    return params

def _get_cmd_lines(cmd):
    proc=Popen(cmd,shell=True,stdout=PIPE,stderr=STDOUT)
    stdout,stderr=proc.communicate()
    return '\n'.join([stdout or '',stderr or ''])

def do_operate(operate,name,*args):
    path=conf.sched_path
    oper,subject=operate.split('_',1)
    cmd='{0}/bin/sched {1} -{2} {3} {4}'.format(path,subject,oper,name,' '.join(args))
    return _get_cmd_lines(cmd)

def _get_valid_params(kwargs):
    return dict((k,str2obj(v)) for k,v in kwargs.items() if v!='')

def do_ask(operate,name,**kwargs):
    kwargs=_get_valid_params(kwargs)
    asker=Asker(conf.master_host,conf.master_port)
    answer=asker.ask(operate,name,**kwargs)
    return answer

def _get_ssh_cmd(host,cmd):
    cmd="ssh {user}@{host} -p 22222 '{cmd}'".format(user='lixinguang',host=host,cmd=cmd)
    return cmd

def cmd_do_job(name,**kwargs):
    return do_ask('do_job',name,**kwargs)

def cmd_batch_job(name,**kwargs):
    return do_ask('batch_job',name,**kwargs)

def cmd_rerun_job(name,**kwargs):
    return do_ask('rerun_job',name,**kwargs)

def cmd_loop_job(name,**kwargs):
    return do_ask('loop_job',name,**kwargs)

def cmd_kill_job(name,**kwargs):
    return do_ask('kill_job',name,**kwargs)

def cmd_cat_log(name,**kwargs):
    tx_time=kwargs.get('tx_time') or get_date()
    if tx_time==get_date():
        sql=record_sql2.format(name=name,tx_time=tx_time)
    else:
        sql=record_log_sql.format(name=name,tx_time=tx_time)
    rows=do_sql(sql,to_dict=True)
    if rows:
        record=rows[0]
    else:
        return 'No such job {0}'.format(name)
    cmd="cat {path}/{name}.log".format(path=record['path'],name=name)
    if record['host']!=conf.web_host:
        cmd=_get_ssh_cmd(record['host'],cmd)
    lines=_get_cmd_lines(cmd)
    lines=lines.splitlines()
    answer=tuple(lines[-1000:])
    return answer

def cmd_add_job(name,**kwargs):
    depends=kwargs.pop('depends',[])
    if depends:
        cmd_add_depend(name,depends=depends)
    kwargs=_get_valid_params(kwargs)
    kwargs['name']=name
    keys=kwargs.keys()
    values=','.join(map(lambda key:obj2mt(kwargs.get(key)),keys))
    keys=','.join(map(lambda key:'`{key}`'.format(key=key),keys))
    sql=insert_sql.format(table='sched_job',keys=keys,values=values)
    return do_sql(sql)

def cmd_update_job(name,**kwargs):
    depends=filter(lambda d:len(d.strip())>0,kwargs.pop('depends',[]))
    if depends:
        cmd_add_depend(name,depends=depends)
    kwargs=_get_valid_params(kwargs)
    sets=','.join('`{k}`={v}'.format(k=k,v=obj2mt(v)) for k,v in kwargs.items())
    sql=update_sql.format(table='sched_job',sets=sets,where="name='{0}'".format(name))
    return do_sql(sql)

def cmd_get_job(name,**kwargs):
    sql=job_sql.format(name=name,job_home=job_home,log_home=log_home)
    return do_sql(sql,has_fields=True)

def cmd_get_log(name,**kwargs):
    sql=log_sql.format(last_mdate=get_date(itv=-30),name=name)
    return do_sql(sql,has_fields=True)

def cmd_get_record(name,**kwargs):
    sql=record_sql.format(name=name,job_home=job_home,log_home=log_home)
    return do_sql(sql,has_fields=True)

def cmd_update_record(name,**kwargs):
    kwargs=_get_valid_params(kwargs)
    sets=','.join('`{k}`={v}'.format(k=k,v=obj2mt(v)) for k,v in kwargs.items())
    sql=update_sql.format(table='sched_job_record',sets=sets,where="`name`='{0}'".format(name))
    return do_sql(sql)

def cmd_forward_depend(name,**kwargs):
    sql=forward_depend_sql.format(name=name)
    return do_sql(sql,has_fields=True)

def cmd_delete_record(name,**kwargs):
    sql=delete_sql.format(table='sched_job_record',where="`name`='{0}'".format(name))
    return do_sql(sql)

def cmd_delete_job(name,**kwargs):
    sql=delete_sql.format(table='sched_job',where="`name`='{0}'".format(name))
    return do_sql(sql)

def cmd_add_depend(name,**kwargs):
    names=('name','dependency','enable')
    depends=kwargs.get('depends',[])
    if not depends:
        return False
    try:
        for depend in depends:
            depend=depend.strip()
            if not depend:
                continue
            values=','.join(map(repr,(name,depend,1)))
            keys=','.join(map(lambda key:'`{key}`'.format(key=key),names))
            sql=insert_sql.format(table='sched_job_dependency',keys=keys,values=values)
            do_sql(sql)
    except Exception,error:
        return error
    return True

def cmd_update_depend(name,**kwargs):
    kwargs['name']=name
    sets='`enable`={enable}'.format(enable=kwargs.pop('enable',1))
    where=' AND '.join('`{k}`={v}'.format(k=k,v=obj2mt(v)) for k,v in kwargs.items())
    sql=update_sql.format(table='sched_job_dependency',sets=sets,where=where)
    return do_sql(sql)

def cmd_get_depend(name,**kwargs):
    sql=depend_sql.format(name=name)
    return do_sql(sql,has_fields=True)

def cmd_backward_depend(name,**kwargs):
    sql=backward_depend_sql.format(dependency=name)
    return do_sql(sql,has_fields=True)

def cmd_delete_depend(name,**kwargs):
    where="`name`='{name}' AND `dependency`='{dependency}' ".format(name=name,**kwargs)
    sql=delete_sql.format(table='sched_job_dependency',where=where)
    return do_sql(sql)

def cmd_delete_log(name,**kwargs):
    where="`name`='{name}' AND `tx_time`='{tx_time}' ".format(name=name,**kwargs)
    sql=delete_sql.format(table='sched_job_log',where=where)
    return do_sql(sql)

cmd_dict=dict(
    do_job=cmd_do_job,
    loop_job=cmd_loop_job,
    rerun_job=cmd_rerun_job,
    kill_job=cmd_kill_job,
    get_job=cmd_get_job,
    cat_log=cmd_cat_log,
    get_log=cmd_get_log,
    get_record=cmd_get_record,
    update_record=cmd_update_record,
    forward_depend=cmd_forward_depend,
    backward_depend=cmd_backward_depend,
    delete_record=cmd_delete_record,
    delete_depend=cmd_delete_depend,
    delete_job=cmd_delete_job,
    add_job=cmd_add_job,
    update_job=cmd_update_job,
    delete_log=cmd_delete_log,
)

def check_depends(name,depends):
    _depends="','".join(depends)
    no_jobs=set()
    sql=check_depends_sql.format(depends=_depends)
    jobs=set(map(lambda r:r[0],do_sql(sql)))
    for depend in depends:
        if depend not in jobs:
            no_jobs.add(depend)
    return no_jobs

def dist_file(file,hosts=hosts):
    for host in hosts:
        cmd="scp -P 22222 {file} {user}@{host}:{path}".format(file=file,user='lixinguang',host=host,path=job_home)
        state=os.system(cmd)
        if state!=0:
            raise Exception("Execute cmd failed, return code is %s" % state)
    return True

def dist_script(script,host):
    cmd="scp -P 22222 {user}@{host}:{file} {path}".format(file=script,user='lixinguang',host=host,path=job_home)
    state=os.system(cmd)
    if state!=0:
        raise Exception("Execute cmd failed, return code is %s" % state)
    script=os.path.join(job_home,os.path.basename(script))
    return dist_file(script)

def upload_script(upload):
    script=os.path.join(job_home,upload.filename)
    upload.save(script)
    dist_file(script)
    return script

def _clean_script(script):
    lines=[]
    with open(script,'r') as f:
        for line in f:
            line=line.strip()
            end_index=line.find('#')
            if end_index!=-1:
                line=line[:end_index]
            lines.append(line)
    return '\n'.join(lines)

def list_depends(script):
    path=os.path.dirname(script)
    if path in ('.',''):
        script=os.path.join(job_home,script)
    if not os.path.exists(script):
        return []
    lines=_clean_script(script)
    job_name=os.path.basename(script).split('.')[0].lower()
    pattern=re.compile(r'\b(?:stg|ods|dwd|dws|app|dim|dwa|pub|exp)_\w+_(?:di|da)\b',re.I)
    depend_jobs=[depend_job.lower() for depend_job in set(pattern.findall(lines)) if depend_job.lower()!=job_name]
    return depend_jobs

def get_cmd_params():
    shared=get_shared_params()
    query=request.query
    operate=query.pop('operate','do_job')
    name=query.pop('name','').lower()
    menu_id=query.pop('menu_id',5)
    first_menu_id = query.pop('first_menu_id', 1)
    is_run=int(query.pop('is_run',0))
    clicked_depend=query.pop('clicked_depend','')
    depend_enable=int(query.pop('depend_enable',1))
    var_depend=int(query.pop('var_depend',0))
    var_delete=int(query.pop('var_delete',0))
    depends=map(lambda d:d.lower().strip(),re.split(r'\r\n|\n|,',query.pop('depends','').strip()))
    if operate in ('add_job','update_job'):
        query['depends']=depends
    answer_error,answer=None,''
    if is_run and operate and name:
        if operate in cmd_dict:
            try:
                answer=cmd_dict[operate](name,**query)
                answer_error=''
            except Exception,error:
                answer_error=error
        else:
            answer='No such operation: {0}'.format(operate)
    user = get_cookie_user()
    c_opers = Third_class_permission_check([job_opers, record_opers], user, first_menu_id, menu_id)
    params=dict(operate=operate,name=name,answer=answer,answer_error=answer_error,
                job_opers=c_opers[0], record_opers=c_opers[1], opers_dict=opers_dict,
                query=query,hosts=hosts,states=states,**shared)
    if operate in ('add_job','update_job'):
        params['dim_values']=get_cmd_dims()
        if var_depend==1:
            if depends:
                params['query']['no_jobs']=check_depends(name,depends)
        elif var_depend==2:
            try:
                script=re.split(r'\s+',query.get('cmd','').lower())[1]
            except IndexError:
                script=''
            if script:
                params['query']['depends']=list_depends(script)
        if operate=='update_job':
            if not name:
                return params
            params['query'].update(get_job(name))
            params['query']['exist_depends']=get_depends(name)
            if not clicked_depend:
                return params
            cmd_update_depend(name,enable=depend_enable,dependency=clicked_depend)
            params['query']['exist_depends']=get_depends(name)
    elif operate=='update_record':
        if name:
            record=get_record(name)
            params['query'].update(record)
    elif operate=='delete_job':
        try:
            if var_delete==1:
                cmd_delete_job(name)
            elif var_delete==2:
                cmd_delete_depend(name,**query)
            answer_error=''
        except Exception,error:
            print error
            answer_error=error
        params['answer_error']=answer_error
        params['query']['var_delete']=var_delete
    return params

def cfg_quick_add(**kwargs):
    args=[kwargs.get(k,'') for k in ('port','db','tb','odstype','man')]
    dmp_home=os.environ['DMP_HOME']
    cmd="python "+dmp_home+"/ucredit/data/util/Tasker.py %s" % (' '.join(args))
    lines=_get_cmd_lines(cmd)
    return tuple(lines.splitlines())

cfg_dict=dict(
    quick_add=cfg_quick_add,
)

def get_cfg_params():
    shared=get_shared_params()
    query=request.query
    menu_id=query.pop('menu_id',6)
    first_menu_id = query.pop('first_menu_id', 1)
    operate=query.pop('operate','quick_add')
    user=get_cookie_user()
    c_opers = Third_class_permission_check(cfg_opers, user, first_menu_id, menu_id)
    params=dict(operate=operate,cfg_opers=c_opers,query=query,**shared)
    is_run=int(query.pop('is_run',0))
    answer,answer_error='',None
    if is_run and operate in cfg_dict:
        try:
            answer=cfg_dict[operate](**query)
            answer_error=''
        except Exception,error:
            answer_error=error
    else:
        answer='No such operation: {0}'.format(operate)
    if params['operate'] == 'extract_table':
        params['rows'] = do_sql(total_extract_table_sql)
    elif params['operate'] == 'extract_detail':
        link_id = query.pop('link_id')
        params['rows'] = do_sql(fetch_extract_detail % link_id)[0]
        params['db_source'] = do_sql(total_source_table_sql)
    elif params['operate'] == 'data_source':
        params['rows'] = do_sql(total_source_table_sql)
    elif params['operate'] == 'source_detail':
        dbsrc_id = query.pop('dbsrc_id')
        params['rows'] = do_sql(fetch_source_detail % dbsrc_id)[0]
    params['answer']=answer
    params['answer_error']=answer_error
    return params

params_dict={
    1:get_total_params,
    2:get_job_params,
    3:get_record_params,
    4:get_runtime_params,
    5:get_cmd_params,
    6:get_cfg_params,
}

def get_params():
    menu_id=int(request.query.get('menu_id',1))
    params_func=params_dict.get(menu_id)
    if params_func is None:
        raise Exception('No such menu_id: %s' % (menu_id))
    tpl_name=sched_menus[menu_id][1]
    some_tpl=tpls.get(tpl_name)
    params=params_func()
    params['menu_id']=menu_id
    params['some_tpl']=some_tpl
    return params

@route(urls['index_url'])
def index_page():
    return redirect(urls['frame_url'])
    
@route(urls['login_url'])
def login_page():
    failed=bool(request.query.get('failed',False))
    return template(tpls['login_tpl'],failed=failed,user=get_cookie_user(),action=urls['frame_url'],**tpls)

@route(urls['frame_url'],method='POST')
def do_login():
    user=request.forms.get('username')
    passwd=request.forms.get('password')
    user=user.replace(' ','+').replace('\t','+').replace('\r','+').replace('\n','+').replace(';','+').replace("'",'+').replace('"','+')
    if check_login(user,passwd):
        set_cookie_user(user)
        return frame_page()
    return redirect('{0}?failed=True'.format(urls['login_url']))
    
@route(urls['top_url'])
def top_page():
    user=get_cookie_user()
    if user:
        return template(tpls['top_tpl'],user=user,login_url=urls['login_url'],**tpls)
    return redirect(urls['login_url'])
    
@route(urls['bottom_url'])
def bottom_page():
    return template(tpls['bottom_tpl'],**tpls)


@route(urls['left_url'])
def left_page():
    user = get_cookie_user()
    c_menus = First_class_permission_check(menus, user)
    c_menus = Second_class_permission_check(c_menus, user)
    return template(tpls['left_tpl'],right_url=urls['right_url'],menus=c_menus,**tpls)

@route(urls['right_url'])
def right_page():
    user=get_cookie_user()
    if not user:
        return redirect(urls['login_url'])
    params=get_params()
    some_tpl=params.pop('some_tpl')
    return template(tpls['right_tpl'],some_tpl=some_tpl,params=params)

@route(urls['right_url'], method="POST")
def right_page():
    operate = request.query.get('operate')
    if operate == 'update_extract':
        form_data = request.POST
        task_name = form_data.get('task_name')
        task_type_id = form_data.get('task_type_id')
        client_domain = form_data.get('client_domain')
        client_ip = form_data.get('client_ip')
        client_port = form_data.get('client_port')
        tbl_name = form_data.get('tbl_name')
        dbsrc_id = form_data.get('dbsrc_id')
        hive_db_name = form_data.get('hive_db_name')
        hive_tbl_name = form_data.get('hive_tbl_name')
        task_sql_all = form_data.get('task_sql_all')
        task_sql_filter = form_data.get('task_sql_filter')
        is_increment = form_data.get('is_increment')
        exec_cfg_id = form_data.get('exec_cfg_id')
        task_sql_insert = form_data.get('task_sql_insert')
        step_lines = form_data.get('step_lines')
        dbtgt_id = form_data.get('dbtgt_id')
        task_id = form_data.get('task_id')
        do_sql(update_extract_detail % (task_name, task_type_id, client_domain, client_ip, client_port,
                                        tbl_name, dbsrc_id, hive_db_name, hive_tbl_name, task_sql_all,
                                        task_sql_filter, is_increment, exec_cfg_id, task_sql_insert,
                                        step_lines, dbtgt_id, task_id))
        return redirect('/right.py?operate=extract_table&menu_id=6')
    elif operate == 'update_source':
        form_data = request.POST
        dbsrc_type_id = form_data.get('dbsrc_type_id')
        dbsrc_name = form_data.get('dbsrc_name')
        db_ip = form_data.get('db_ip')
        db_port = form_data.get('db_port')
        db_name = form_data.get('db_name')
        db_user = form_data.get('db_user')
        db_password = form_data.get('db_password')
        db_schema = form_data.get('db_schema')
        db_instance = form_data.get('db_instance')
        enable = form_data.get('enable')
        dbsrc_id = form_data.get('dbsrc_id')
        do_sql(update_source_detail % (int(dbsrc_type_id), dbsrc_name, db_ip, db_port, db_name, db_user,
                                       db_password, db_schema, db_instance, int(enable), int(dbsrc_id)))
        return redirect('/right.py?operate=data_source&menu_id=6')

@route(urls['upload_url'],method='POST')
def upload_page():
    user=get_cookie_user()
    if not user:
        return redirect(urls['login_url'])
    form=request.forms
    var_script=int(form.get('var_script',0))
    script,error,script_host,func='','','',''
    if var_script==1:
        upload=request.files.get('upload')
        func='上传脚本'
        if upload and upload.filename:
            try:
                upload_script(upload)
            except Exception,error:
                print error
            script=upload.filename
    elif var_script==2:
        script=form.get('script','')
        path=os.path.dirname(script)
        if path in ('.',''):
            script=os.path.join(job_home,script)
        script_host=form.get('host',host)
        func='分发脚本'
        if script:
            try:
                dist_script(script,script_host)
            except Exception,error:
                print error
    return template(tpls['upload_tpl'],script=script,host=script_host,func=func,error=error,**tpls)
    
def frame_page():
    query=request.query
    pass_param=int(query.pop('pass_param',0))
    if pass_param:
        right_params='?{0}'.format('&'.join('='.join([k,v]) for k,v in query.items()))
    else:
        right_params=''
    return template(tpls['frame_tpl'],header_tpl=tpls['header_tpl'],style_tpl=tpls['style_tpl'],right_params=right_params,**urls)

@route(urls['frame_url'])
def show_frame():
    user=get_cookie_user()
    if user:
        return frame_page()
    return redirect(urls['login_url'])

def get_pid_file():
    path=conf.pid_path if os.name!='nt' else os.getcwd()
    pid_file='{0}/web.pid'.format(path)
    return pid_file

def get_web_log():
    path=conf.web_log_path if os.name!='nt' else os.getcwd()
    web_log='{0}/web.log'.format(path)
    return web_log

def get_host():
    if os.name!='nt':
        host=conf.web_host
    else:
        host='127.0.0.1'
    return host

def log(msg):
    sys.stdout.write(msg+'\n')
    sys.stdout.flush()

host=get_host()
port=conf.web_port

class WebServer(ThreadingMixIn,WSGIServer):
    def __repr__(self):
        return '<WebServer>'
    
def run_server():
    stdout,stderr=sys.stdout,sys.stderr
    fout=open(get_web_log(),'w')
    sys.stdout=fout
    sys.stderr=fout
    try:
        return run(host=host,port=port,server_class=WebServer)
    finally:
        fout.close()
        sys.stdout=stdout
        sys.stderr=stderr
    
def start():
    pid_file=get_pid_file()
    pid=get_pid(pid_file)
    pid = None
    if pid is not None:
        log("Web({0}, {1}) is already started".format(host,port))
        sys.exit(2)
    store_pid(pid_file)
    log("Web({0}, {1}) is started".format(host,port))
    run(host=host,port=8080,server_class=WebServer, reloader=True)
    
def stop():
    state=kill_pid(get_pid_file())
    if state==0:
        log("Web({0}, {1}) is stopped".format(host,port))
    elif state==1:
        log("Web({0}, {1}) stop failed".format(host,port))
    else:
        log("Web({0}, {1}) is not started".format(host,port))
    
def main():
    if sys.argv[1]=='-start':
        start()
    elif sys.argv[1]=='-stop':
        stop()
        
if __name__ == '__main__':
    debug(True)
    main()
    
