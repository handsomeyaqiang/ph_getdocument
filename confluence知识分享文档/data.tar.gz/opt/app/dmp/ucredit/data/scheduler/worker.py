#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys
import time
from socket import socket,AF_INET,SOCK_STREAM
from logger import Logger
from threads import MsgQueue,spawn
from job import Job,JobPool,JobState
from utils import get_pid,store_pid,kill_pid,param2str,get_localhost,check_busy,send,recv,log,get_value

default_host='localhost'
default_port=8090
localhost=get_localhost()


class Client(object):
    
    def __init__(self,host=default_host,port=default_port):
        self._address=(host,int(port))
        self._logger=None
        
    def log(self,msg,**kwargs):
        log(msg,logger=self._logger,**kwargs)
        
    def set_address(self,host,port):
        self._address=(host,int(port))
        
    def get_address(self):
        return self._address
    
    def wait(self,seconds):
        time.sleep(seconds)
        
    def connect(self,times=10):
        sock=None
        i=0
        while sock is None:
            i+=1
            try:
                sock=socket(AF_INET,SOCK_STREAM)
                sock.connect(self._address)
            except Exception,error:
                sock=None
                self.log("Connect master{addr} error: {error}".format(addr=self._address,error=error))
                if not times:
                    self.wait(5)
                elif i<times:
                    self.wait(5)
                else:
                    raise error
        return sock
    
    def send(self,sock,req,*args,**kwargs):
        send(sock,(req,args,kwargs),logger=self._logger)
        
    def recv(self,sock):
        return recv(sock,logger=self._logger)
    
    def submit(self,req,*args,**kwargs):
        log_req=kwargs.pop('log_req',True)
        log_rep=kwargs.pop('log_rep',True)
        sock=self.connect()
        self.send(sock,req,*args,**kwargs)
        params=param2str(*args,**kwargs)
        if log_req:
            self.log("Send request: {req}({params})".format(req=req,params=params))
        response=self.recv(sock)
        sock.close()
        if log_rep:
            self.log("Get response: {rep}".format(rep=response))
        return response
    
    def close(self):
        if self._logger:
            self._logger.close()
            
class Worker(Client):
    
    def __init__(self,conf=None):
        self._conf=conf
        super(Worker,self).__init__()
        
    def set_conf(self,conf):
        self._conf=conf
        
    def _setup_var(self):
        self._host=get_value(self._conf,'master_host',default_host)
        self._port=get_value(self._conf,'master_port',default_port)
        self._address=(self._host,self._port)
        self._log_path=get_value(self._conf,'worker_log_path','.')
        self._pid_path=get_value(self._conf,'pid_path','.')
        self._heartbeat_period=get_value(self._conf,'heartbeat_period',20)
        self._max_jobs=get_value(self._conf,'max_jobs',30)
        self._check_hadoop=get_value(self._conf,'check_hadoop',False)
        self._hadoop_user=get_value(self._conf,'hadoop_user','pcs.sa')
        self._hadoop_url=get_value(self._conf,'hadoop_url','http://10.10.64.70:8088/cluster/scheduler')
        
    def get_worker_pid_file(self):
        return '{path}/worker.pid'.format(path=self._pid_path)
    
    def get_job_pid_file(self,name):
        return '{path}/{name}.pid'.format(path=self._pid_path,name=name)
    
    def _setup_worker(self):
        self._store_pid()
        self._logger=Logger(name='worker',path=self._log_path)
        self._job_pool=JobPool(self._max_jobs,logger=self._logger)
        self._notify_queue=MsgQueue(logger=self._logger)
        
    def _store_pid(self):
        pid_file=self.get_worker_pid_file()
        pid=get_pid(pid_file)
        if pid is not None:
            log("Worker({host}) is already started".format(host=localhost),flush=True)
            sys.exit(2)
        store_pid(pid_file)
        
    def _start_heartbeat(self):
        try:
            self._heartbeat=spawn(self.heartbeat,thread_name='HeartBeat')
            log("Worker({host}) is started".format(host=localhost),flush=True)
        except Exception,error:
            log("Worker({host}) start failed, because {error}".format(host=localhost,error=error),flush=True)
            sys.exit(1)
            
    @property
    def is_busy(self):
        return any([check_busy(logger=self._logger,check_hadoop=self._check_hadoop,url=self._hadoop_url,user=self._hadoop_user),self._job_pool.jobs>=self._max_jobs])
    
    def _send_notify(self,**record):
        sock=self.connect()
        self.send(sock,'notify',**record)
        notified=self.recv(sock)
        sock.close()
        return notified
        
    def send_notify(self,**record):
        params=param2str(**record)
        retried=0
        while retried<3:
            try:
                notified=self._send_notify(**record)
            except Exception,error:
                self.log("Send notify: record({params}): failed, because {error}, retried: {retried}".format(params=params,error=error,retried=retried))
                notified=False
            if notified:
                self.log("Send notify: record({params}): success".format(params=params))
                break
            retried+=1
            
    def send_heartbeat(self):
        sock=self.connect(0)
        is_busy=self.is_busy
        self.send(sock,'heartbeat',is_busy=is_busy)
        self.log("Send heartbeat: is_busy={is_busy}".format(is_busy=is_busy))
        jobs=self.recv(sock)
        sock.close()
        if jobs is None or (not isinstance(jobs,list)):
            jobs=[]
        self.log("Get {count} jobs: {jobs}".format(count=len(jobs),jobs=jobs))
        return jobs
    
    def heartbeat(self):
        while True:
            jobs=[]
            try:
                jobs=self.send_heartbeat()
            except Exception,error:
                self.log("Send heartbeat error: {error}".format(error=error))
            try:
                self.submit_jobs(jobs)
            except Exception,error:
                self.log("Submit jobs error: {error}".format(error=error))
            self.wait(self._heartbeat_period)
            
    def _notify_job(self,**record):
        self._notify_queue.submit(self.send_notify,**record)
        
    def submit_jobs(self,jobs):
        for job in jobs:
            if isinstance(job,list):
                self._submit_jobs(job)
            else:
                state=job.get('state')
                if state==JobState.KILLED:
                    self._kill_job(job.get('name'))
                else:
                    self._submit_job(job)
                    
    def _setup_job(self,job):
        state=job.pop('state',JobState.PENDING)
        tx_time=job.pop('tx_time',None)
        _job=Job(**job)
        _job.setup(state=state,tx_time=tx_time,opened=True,replace=False,pid_path=self._pid_path,notify=self._notify_job)
        return _job
    
    def _submit_job(self,job):
        job=self._setup_job(job)
        self._job_pool.submit(job)
        
    def _submit_jobs(self,jobs):
        jobs=[self._setup_job(job) for job in jobs]
        self._job_pool.submit(jobs)
        
    def _kill_job(self,name):
        pid_file=self.get_job_pid_file(name)
        return kill_pid(pid_file)
    
    def _check_hearbeat(self):
        if hasattr(self,'_heartbeat') and self._heartbeat.isAlive():
            return
        self.log('HeartBeat is dead, begin to restart it')
        self._start_heartbeat()
        
    def _check_job_pool(self):
        job_count=self._job_pool.jobs
        if job_count>0:
            self.log('JobPool: job_count={count}'.format(count=job_count))
            if not self._job_pool.is_alive:
                self.log("JobPool's workers are dead, begin to spawn a new worker")
                self._job_pool.spawn()
                
    def _check_notify_queue(self):
        notify_count=self._notify_queue.jobs
        if notify_count>0:
            self.log('NotifyQueue: notify_count={count}'.format(count=notify_count))
            if not self._notify_queue.is_alive:
                self._notify_queue.spawn()
                self.log("NotifyQueue's worker is dead, begin to spawn a new worker")
                
    def _start_deamon(self):
        while True:
            self._check_hearbeat()
            self._check_job_pool()
            self._check_notify_queue()
            self.wait(60)
        
    def start(self):
        self._setup_var()
        self._setup_worker()
        self._start_heartbeat()
        self._start_deamon()
        
    def stop(self):
        self._setup_var()
        pid_file=self.get_worker_pid_file()
        state=kill_pid(pid_file)
        if state==0:
            log('Worker({host}) is stopped'.format(host=localhost),flush=True)
        elif state==1:
            log('Worker({host}) stop failed'.format(host=localhost),flush=True)
        else:
            log('Worker({host}) is not started'.format(host=localhost),flush=True)
            
class Asker(Client):
    
    def __init__(self,host=default_host,port=default_port):
        super(Asker,self).__init__(host,port)
        self._logger=Logger()
        
    def __getattr__(self,attr):
        if attr not in self.__dict__:
            return lambda *args,**kwargs:self.submit(attr,*args,**kwargs)
        return getattr(self,attr)
        
    def add_job(self,name,**kwargs):
        kwargs.setdefault('host',localhost)
        return self.submit('add_job',name,**kwargs)
    
    def ask(self,question,*args,**kwargs):
        question=question.lower()
        func=getattr(self,question)
        kwargs['log_rep']=False
        result=func(*args,**kwargs)
        self.log("Get response:")
        if question not in ('get_job','get_record') and result and isinstance(result,(tuple,list)):
            for item in result:
                self.log(item,has_time=False)
        else:
            self.log(str(result),has_time=False)
        return result
    
