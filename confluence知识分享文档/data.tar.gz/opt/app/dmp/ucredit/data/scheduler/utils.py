#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import socket
import signal
from threading import Lock
import errno
import commands
import re
import urllib2
try:
    import cPickle as pickle
except ImportError:
    import pickle
import datetime
import decimal
import time

def get_localhost():
    import socket,fcntl,struct
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ifname='em2'
    inet = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
    return socket.inet_ntoa(inet[20:24])
#    return socket.gethostbyname(socket.gethostname())
    
def store_pid(pid_file,pid=None):
    pid=pid is None and os.getpid() or pid
    path=os.path.dirname(pid_file)
    if not os.path.exists(path):
        os.mkdir(path)
    f=open(pid_file,'w')
    f.write(str(pid))
    f.close()
    
def get_pid(pid_file):
    if not os.path.exists(pid_file):
        return None
    f=open(pid_file)
    pid=int(f.read())
    f.close()
    return pid

def remove_file(some_file):
    if os.path.exists(some_file):
        os.remove(some_file)
        
def kill_pid(pid_file=None):
    if pid_file is not None:
        pid=get_pid(pid_file)
        if pid is None:
            remove_file(pid_file)
            return 2
    else:
        pid=os.getpid()
    try:
        os.kill(pid,signal.SIGTERM)
        state=0
    except:
        try:
            os.kill(pid,signal.SIGKILL)
            state=0
        except:
            state=1
    if pid_file is not None:
        remove_file(pid_file)
    return state

def ignore_errors():
    errons=[errno.EINTR,errno.EAGAIN,errno.EWOULDBLOCK,errno.EINPROGRESS]
    for err in ["WSAEINTR","WSAEWOULDBLOCK","WSAEINPROGRESS"]:
        if hasattr(errno,err):
            errons.append(getattr(errno,err))
    return errons

def param2str(*args,**kwargs):
    def _get_value(value):
        if value is None:
            return 'None'
        if isinstance(value,basestring):
            return "'%s'" % (value)
        elif isinstance(value,(int,long,float,bool)):
            return repr(value)
        return str(value)
    params=[]
    if args:
        params.append(', '.join(map(_get_value,args)))
    if kwargs:
        params.append(', '.join('{k}={v}'.format(k=k,v=_get_value(v)) for k,v in kwargs.items()))
    return ', '.join(params)

def _check_worker_busy(logger=None):
    try:
        cmd="top -b |head -n 5"
        status,output=commands.getstatusoutput(cmd)
        if status!=0:
            return False
        lines=output.splitlines()
        cpus=re.split(r',\s+',lines[2])
        idle=float(cpus[3].split('%')[0])
##        idle=float(cpus[3].split(' ')[0])
        mm=re.search(r'Mem:\s+(\d+)k\s+total.+?(\d+)k\s+used.+?(\d+)k.+?(\d+)k',lines[3])
##        mm=re.search(r'Mem:\s+(\d+)k\s+total,+?(\d+)k\s+used,+?(\d+)k.+?(\d+)k',lines[3])
        mems=re.split(r',\s+',lines[3])
        total_mem=re.split(r'\s+',mems[0])[1].rstrip('k')
##        total_mem=','.join(mems[0].split()).split(',')[2]
        free_mem=re.split(r'\s+',mems[2])[0].rstrip('k')
##        free_mem= mems[2].split()[0]
        buffers=re.split(r'\s+',mems[3])[0].rstrip('k')
##        buffers=mems[3].split()[0]
        swaps=re.split(r',\s+',lines[4])
##        swaps= ','.join(lines[4].split()).split(',')[2]
##        cached=lines[4].split()[8]
        cached=re.split(r'\s+',swaps[3])[0].rstrip('k')
        mem=float(sum(map(int,(free_mem,buffers,cached))))/int(total_mem)
        return any([idle<10,mem<0.1])
    except Exception,error:
        msg="Check worker busy error: {error}".format(error=error)
        log(msg,logger=logger)
        return False
    
def _check_hadoop_busy(logger=None,url='http://10.10.64.70:8088/cluster/scheduler',user='pcs.sa'):
    try:
        r=urllib2.urlopen(url)
        data=r.read()
        for d in re.findall(r'<table class="info">(.+?)</table>',data,re.S):
            if d.find("'%s' Queue Status" % (user))>-1:
                m=re.search(r'<th>(?:\s|\n)*Absolute Used Capacity:(?:\s|\n)*<td>(?:\s|\n)*([^\s\n<]+)',d)
                if m:
                    return float(m.group(1).rstrip('%'))>90
    except Exception,error:
        msg="Check hadoop busy error: {error}".format(error=error)
        log(msg,logger=logger)
    return False

def check_busy(logger=None,check_hadoop=False,**kwargs):
    states=[]
    worker_state=_check_worker_busy(logger)
    states.append(worker_state)
    if check_hadoop:
        hadoop_state=_check_hadoop_busy(logger=logger,**kwargs)
        states.append(hadoop_state)
    return any(states)

def send_sms(job,mobile,logger=None,url='http://hy6.nbark.com:7602/sms.aspx?action=send&userid=174&account=youzhongyxhy6&password=IXh9UT9KyhK8GcAZ0lJv&mobile=%s&content=%s'):
    try:
        content = u'报:%s,警:调度平台'% job.name 
        url=url % (mobile, content.encode('utf8'))
        r=urllib2.urlopen(url)
        return r.read()
    except Exception,error:
        msg="Send sms error: {error}".format(error=error)
        log(msg,logger=logger)
        return None
    
def str2obj(string):
    if not isinstance(string,basestring):
        return string
    if string=='None':
        return None
    if string=='True':
        return True
    if string=='False':
        return False
    if string.find('.')>-1:
        try:
            return float(string)
        except:
            return string
    if re.match(r'\d+$',string):
        return int(string)
    return string

def mt2obj(mt):
    """mysql table data type to python object data type"""
    if mt in ('NULL',None):
        return None
    if isinstance(mt,(long,int)):
        return int(mt)
    if isinstance(mt,(decimal.Decimal,float)):
        return float(mt)
    if isinstance(mt,(datetime.datetime,datetime.date)):
        return str(mt)
    return str(mt)

def obj2mt(obj):
    """python object data type to mysql table data type"""
    if obj is None:
        return 'NULL'
    if obj in (True,False):
        return repr(int(obj))
    if isinstance(obj,(int,long)):
        return repr(int(obj))
    if isinstance(obj,basestring):
        return "'{obj}'".format(obj=str(obj))
    if isinstance(obj,(datetime.datetime,datetime.date)):
        return "'{obj}'".format(obj=str(obj))
    if isinstance(obj,(decimal.Decimal,float)):
        return repr(float(obj))
    return repr(obj)

def log(msg,logger=None,flush=False,**kwargs):
    if logger:
        logger.log(msg,flush=flush,**kwargs)
    else:
        sys.stdout.write('{msg}\n'.format(msg=msg))
        if flush:
            sys.stdout.flush()
            
def send(sock,data,suffix=b'\n'*4,logger=None):
    try:
        data=pickle.dumps(data,True)
        sock.sendall(data+suffix)
    except Exception,error:
        log("Send error: {error}".format(error=error),logger=logger)
        
def recv(sock,size=4096,suffix=b'\n'*4,logger=None):
    data=''
    while not data.endswith(suffix):
        try:
            msg=sock.recv(size)
            if not msg:
                log("Recv data not enough",logger=logger)
                break
            data+=msg
        except Exception,error:
            log("Recv error: {error}".format(error=error),logger=logger)
            return None
    data=data[:-len(suffix)]
    try:
        return pickle.loads(data)
    except EOFError:
        return None
    
def dt2ts(dt):
    return dt.days*86400+dt.seconds+dt.microseconds/1000000.0

def get_date(sep='',itv=-1):
    fmt=sep.join(['%Y','%m','%d'])
    return time.strftime(fmt,time.localtime(time.time()+itv*24*60*60))

def do_sql(sql,**kwargs):
    charset=kwargs.get('charset','utf8')
    to_dict=kwargs.get('to_dict',False)
    has_fields=kwargs.get('has_fields',False)
    retries=kwargs.get('retries',3)
    dbc=kwargs.get('dbc')
    import MySQLdb
    conn,cursor=None,None
    try:
        conn=MySQLdb.connect(**dbc)
        cursor=conn.cursor(to_dict and MySQLdb.cursors.DictCursor or MySQLdb.cursors.Cursor)
        cursor.execute("SET NAMES %s" % charset)
        effected_rows=int(cursor.execute(sql))
        cmd=re.split(r'\s|\n',sql.strip())[0].upper()
        if cmd in ('SELECT','SHOW','DESC'):
            result=[]
            if has_fields:
                result.append(tuple(map(lambda a:a[0],cursor.description)))
            for row in cursor.fetchall():
                if isinstance(row,dict):
                    row=dict((k,mt2obj(v)) for k,v in row.items())
                else:
                    row=map(mt2obj,row)
                result.append(row)
            return result
        else:
            conn.commit()
            return effected_rows
    except Exception as error:
        if conn:
            conn.rollback()
        if retries>0:
            time.sleep(1)
            kwargs['retries']=retries-1
            return do_sql(sql,**kwargs)
        else:
            raise error
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

def get_value(conf,key,default=None):
    if conf:
        return getattr(conf,key,default)
    return default

