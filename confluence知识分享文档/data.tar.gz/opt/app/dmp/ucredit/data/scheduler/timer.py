#!/usr/bin/env python
#-*- coding:utf-8 -*-
import re
import time
from datetime import datetime,timedelta
from threading import Thread,Condition,Event

MINUTE=timedelta(minutes=1)
HOUR=timedelta(hours=1)
DAY=timedelta(days=1)
WEEK=timedelta(days=7)
MONTH=timedelta(days=28)
YEAR=timedelta(days=365)

def _month_incr(dt,*args):
    ndt=dt+MONTH
    while ndt.month==dt.month:
        ndt+=DAY
    ndt=ndt.replace(day=1)
    return ndt-dt

def _year_incr(dt,*args):
    mod=dt.year % 4
    if mod==0 and (dt.month,dt.day)<(2,29):
        return YEAR+DAY
    if mod==3 and (dt.month,dt.day)>(2,29):
        return YEAR+DAY
    return YEAR

def _month_decr(dt,*args):
    ndt=dt.replace(day=1)-DAY
    return ndt-dt

def _year_decr(dt,*args):
    mod=dt.year % 4
    if mod==0 and (dt.month,dt.day)>(2,29):
        return -(YEAR+DAY)
    if mod==1 and (dt.month,dt.day)<(2,29):
        return -(YEAR+DAY)
    return -YEAR

def _day_decr_reset(dt,x):
    if x>=-DAY:
        return dt
    cur=dt.month
    while dt.month==cur:
        dt+=DAY
    return dt-DAY

_dt_re=re.compile(r'^(?P<year>\d{4})(?:[^\d]*)(?P<month>\d{2})(?:[^\d]*)(?P<day>\d{2})?(?:\s(?P<hour>\d{2}):(?P<minute>\d{2}):(?P<second>\d{2}))?(?:\.(?P<microsecond>\d{6}))?$')
def _str2dt(string):
    m=_dt_re.match(string)
    if m:
        dt_dict=dict((k,int(v or 0)) for k,v in m.groupdict().items())
        year=dt_dict.pop('year')
        month=dt_dict.pop('month')
        day=dt_dict.pop('day')
        return datetime(year,month,day,**dt_dict)
    else:
        raise Exception("Wrong time string format,use yyyy-MM-dd hh:mm::ss style instead")
        
def _parse_dt(string):
    m=_dt_re.match(string)
    if m:
        dt_dict=dict((k,int(v or 0)) for k,v in m.groupdict().items())
        return dt_dict
    else:
        raise Exception("Wrong time string format,use yyyy-MM-dd hh:mm::ss style instead")

def _unify_dt(dt):
    if dt is None:
        dt=datetime.now()
    elif isinstance(dt,(int,float)):
        dt=datetime.fromtimestamp(dt)
    elif isinstance(dt,datetime):
        dt=dt
    else:
        dt=_str2dt(dt)
    return dt

_entry_deltas=[
    ('minute',MINUTE),
    ('hour',HOUR),
    ('day',DAY),
]

def get_prev_dt(dt,now=None):
    now=_unify_dt(now)
    dt_dict=_parse_dt(dt)
    now=now.replace(second=0,microsecond=0)
    day=dt_dict.get('day')
    if day==0:
        return (now+_month_decr(now)).replace(hour=0,minute=0)
    for entry,delta in _entry_deltas:
        attr=dt_dict.get(entry)
        if attr!=0:
            prev_dt=now-delta
            return prev_dt
        else:
            now=now.replace(**{entry:0})
    prev_dt=(now-DAY).replace(hour=0,minute=0,second=0,microsecond=0)
    return prev_dt

_entries=[
    'minute',
    'hour',
    'day',
    'month',
    'weekday',
    'year'
]

_entry_dict=dict(
    minute=dict(
        range=range(60),
        incr=lambda *args:MINUTE,
        incr_reset=lambda dt,*args:dt.replace(minute=0),
        decr=lambda *args:-MINUTE,
        decr_reset=lambda dt,*args:dt.replace(minute=59),
        ),
    hour=dict(
        range=range(24),
        incr=lambda *args:HOUR,
        incr_reset=lambda dt,*args:dt.replace(hour=0),
        decr=lambda *args:-HOUR,
        decr_reset=lambda dt,*args:dt.replace(hour=23),
        ),
    day=dict(
        range=range(1,32),
        incr=lambda *args:DAY,
        incr_reset=lambda dt,x:dt.replace(day=1) if x>DAY else dt,
        decr=lambda *args:-DAY,
        decr_reset=_day_decr_reset,
        ),
    month=dict(
        range=range(1,13),
        incr=_month_incr,
        incr_reset=lambda dt,x: dt.replace(month=1) if x>DAY else dt,
        decr=_month_decr,
        decr_reset=lambda dt,x: dt.replace(month=12)if x<-DAY else dt,
        ),
    weekday=dict(
        range=range(7),
        incr=lambda *args:DAY,
        incr_reset=lambda dt,*args:dt,
        decr=lambda *args:-DAY,
        decr_reset=lambda dt,*args:dt,
        ),
    year=dict(
        range=range(1970,2100),
        incr=_year_incr,
        decr=_year_decr
        ),
    )

_dash_re=re.compile('(\d+)-(\d+)')
_every_re=re.compile('\*\/(\d+)')

class _Entry(object):
    
    def __init__(self,which,entry):
        self.which=which
        self.entry=isinstance(entry,int) and str(entry) or entry
        self.entry_range=_entry_dict.get(which).get('range')
        self.allowed=self.parse_entry()
        
    def __call__(self,entry):
        return entry in self.allowed
    
    def parse_entry(self):
        allowed=set()
        for piece in self.entry.split(','):
            if piece=='*':
                allowed.update(self.entry_range)
                continue
            if piece.isdigit():
                piece=int(piece)
                if piece not in self.entry_range:
                    raise ValueError('%d is not a valid input' % piece)
                allowed.add(piece)
            else:
                dash_match=_dash_re.match(piece)
                if dash_match:
                    lhs,rhs=map(int,dash_match.groups())
                    if lhs not in self.entry_range or rhs not in self.entry_range:
                        raise ValueError('%s is not a valid input' % piece)
                    allowed.update(range(lhs,rhs+1))
                    continue
                every_match=_every_re.match(piece)
                if every_match:
                    interval=int(every_match.groups()[0])
                    allowed.update(self.entry_range[::interval])
        return allowed
    
def _unify_timer(timer):
    if isinstance(timer,basestring):
        parts=re.split('\s+',timer.strip())
        assert len(parts)==5,"Timer must be 5 parts, like '0 * * * *'"
        return parts
    elif isinstance(timer,dict):
        return map(lambda fmt:timer.get(fmt,'*'),entries)
    elif isinstance(timer,(tuple,list)):
        assert len(timer)==5,"Timer must be 5 parts"
        return timer
    else:
        raise Exception("Wrong timer formats")
    
class Crontab(object):
    
    def __init__(self,timer=dict(minute='*',hour='*',day='*',month='*',weekday='*')):
        self._timer=timer
        if self._timer:
            self.parse()
            
    def set_timer(self,timer):
        self._timer=timer
        self.parse()
        
    def get_timer(self):
        return self._timer
    
    def parse(self):
        timer=_unify_timer(self._timer)+['*']
        self.entries=self._parse_entries(timer)
        return self.entries
    
    def _parse_entries(self,timer):
        return dict((which,_Entry(which,entry)) for which,entry in zip(_entries,timer))
    
    def check_entry(self,which,dt):
        if which=='weekday':
            attr=getattr(dt,'isoweekday')
            attr=attr() % 7
        else:
            attr=getattr(dt,which)
        return self.entries.get(which)(attr)
    
    def check(self,dt=None):
        dt=_unify_dt(dt)
        for which in _entries:
            if not self.check_entry(which,dt):
                return False
        return True
    
    def _compute(self,now,reverse,delta):
        now=_unify_dt(now)
        _vary=reverse and 'decr' or 'incr'
        _reset=reverse and 'decr_reset' or 'incr_reset'
        future=now.replace(second=0,microsecond=0)+_entry_dict['minute'][_vary]()
        idx=5
        while idx>=0:
            which=_entries[idx]
            if not self.check_entry(which,future):
                inc=_entry_dict.get(which).get(_vary)(future)
                future+=inc
                for i in xrange(0,idx):
                    future=_entry_dict.get(_entries[i]).get(_reset)(future,inc)
                idx=5
                continue
            idx-=1
        if delta:
            delay=future-now
            return delay.days*86400+delay.seconds+delay.microseconds/1000000.
        return future
    
    def next(self,now=None,delta=False):
        return self._compute(now,False,delta)
    
    def prev(self,now=None,delta=False):
        return self._compute(now,True,delta)

class PeriodicTimer(object):
    
    def __init__(self,interval):
        self._interval=interval
        self._stopped=Event()
        self._cv=Condition()
        self._flag=0
        self._timer=None
        
    def start(self):
        self._timer=Thread(target=self.__run,name='PeriodicTimer')
        self._timer.setDaemon(True)
        self._timer.start()
        
    def __run(self):
        while not self._stopped.isSet():
            time.sleep(self._interval)
            with self._cv:
                self._flag^=1
                self._cv.notify_all()
                
    def wait(self):
        with self._cv:
            last_flag=self._flag
            while last_flag==self._flag:
                self._cv.wait()
                
    def stop(self):
        self._stopped.set()
        
