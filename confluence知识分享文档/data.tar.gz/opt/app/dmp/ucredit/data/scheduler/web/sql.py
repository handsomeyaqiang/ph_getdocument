#!/usr/bin/env python
#-*- coding:utf-8 -*-

check_login_sql="""
SELECT passwd FROM sched_job_user WHERE enable=1 AND email='{name}@ucredit.com'
"""

__total_jobs_field_part="""
    COUNT(1) AS '总任务',
    COUNT(CASE
        WHEN LENGTH(r.`tx_time`)=6 AND r.`tx_time`<'{txmonth}' THEN 1
        WHEN LENGTH(r.`tx_time`)=8 AND r.`tx_time`<'{txdate}' THEN 1
        WHEN LENGTH(r.`tx_time`)=10 AND r.`tx_time`<'{txhour}' THEN 1
        WHEN LENGTH(r.`tx_time`)=12 AND r.`tx_time`<'{txminute}' THEN 1
        ELSE NULL
        END) AS 'UNSTART',
    COUNT(IF(r.`state`='WAIT',1,NULL)) AS 'WAIT',
    COUNT(IF(r.`state`='PENDING',1,NULL)) AS 'PENDING',
    COUNT(IF(r.`state`='TRANSFER',1,NULL)) AS 'TRANSFER',
    COUNT(IF(r.`state`='RUNNING',1,NULL)) AS 'RUNNING',
    COUNT(IF(r.`state`='RETRY',1,NULL)) AS 'RETRY',
    COUNT(IF(r.`state`='TIMEOUT',1,NULL)) AS 'TIMEOUT',
    COUNT(IF(r.`state`='KILLED',1,NULL)) AS 'KILLED',
    COUNT(IF(r.`state`='FAILED',1,NULL)) AS 'FAILED',
    COUNT(CASE
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=6 AND r.`tx_time`>='{txmonth}' THEN 1
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=8 AND r.`tx_time`>='{txdate}' THEN 1
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=10 AND r.`tx_time`>='{txhour}' THEN 1
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=12 AND r.`tx_time`>='{txminute}' THEN 1
        ELSE NULL
        END) AS 'DONE',
    CONCAT(CAST(COUNT(CASE
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=6 AND r.`tx_time`>='{txmonth}' THEN 1
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=8 AND r.`tx_time`>='{txdate}' THEN 1
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=10 AND r.`tx_time`>='{txhour}' THEN 1
        WHEN r.`state`='DONE' AND LENGTH(r.`tx_time`)=12 AND r.`tx_time`>='{txminute}' THEN 1
        ELSE NULL
        END)*100/COUNT(1) AS DECIMAL(9,2)),'%') AS '完成率',
    COUNT(IF(LENGTH(r.`tx_time`)=6,1,NULL)) AS '按 月',
    COUNT(IF(LENGTH(r.`tx_time`)=8,1,NULL)) AS '按 天',
    COUNT(IF(LENGTH(r.`tx_time`)=10,1,NULL)) AS '按小时',
    COUNT(IF(r.`tx_time` IS NULL OR LENGTH(r.`tx_time`) NOT IN (6,8,10),1,NULL)) AS '其 他'
""".strip('\r\n')

total_jobs_sql="""
SELECT
    *
FROM
(
    SELECT
    '{all}' AS '{dim_alias}',
%s
    FROM
        sched_job j
    LEFT JOIN
        sched_job_record r
    ON
        j.`name`=r.`name`
    WHERE
        j.`enable`=1
) a
UNION ALL
SELECT
    {dim_field} AS '{dim_alias}',
%s
FROM
    sched_job j
LEFT JOIN
    sched_job_record r
ON
    j.`name`=r.`name`
WHERE
    j.`enable`=1
GROUP BY
    {dim_field}
""" % (__total_jobs_field_part,__total_jobs_field_part)

dim_values_sql1="""
SELECT
    j.`man`,
    j.`group`,
    j.`priority`,
    r.`tx_time`
FROM
    sched_job j
LEFT JOIN
    sched_job_record r
ON
    j.`name`=r.`name`
WHERE
    j.`enable`=1
"""
dim_values_sql="""
SELECT a.name       AS `man`
,b.group_name       AS `group`
,0                  AS `priority`
,SUBSTR(NOW(),1,10) AS `tx_time`
FROM sched_job_user a
LEFT OUTER JOIN sched_job_group b
ON 1=1 and a.enable=1"""

jobs_sql="""
SELECT
    `name` AS '任务名称',
    `man` AS '负责人',
    `group` AS '任务组',
    `host` AS '服务器',
    `timer` AS '任务定时',
    `priority` AS '优先级',
    `retries` AS '重试次数',
    `delay` AS '重试延迟',
    `step` AS '时间步调',
    `timeout` AS '超时设置',
    `zipper` AS '是否拉链',
    `transfer` AS '可转移'
FROM
    sched_job
WHERE
    `enable`=1
    AND IF('{name}'='',1=1,IF({exact}=1,`name`='{name}',`name` LIKE '%{name}%'))
    AND IF('{man}'='{all}',1=1,`man`='{man}')
    AND IF('{group}'='{all}',1=1,`group`='{group}')
    AND IF('{host}'='{all}',1=1,`host`='{host}')
    AND IF('{priority}'='{all}',1=1,`priority`='{priority}')
LIMIT
    {page_offset},{page_rows}
"""

__job_records_state_part="""
CASE
        WHEN '{state}'='{all}' THEN 1=1
        WHEN '{state}'='UNSTART' THEN 
            CASE
            WHEN LENGTH(r.`tx_time`)=6 THEN r.`tx_time`<'{txmonth}'  
            WHEN LENGTH(r.`tx_time`)=8 THEN r.`tx_time`<'{txdate}'
            WHEN LENGTH(r.`tx_time`)=10 THEN r.`tx_time`<'{txhour}'
            WHEN LENGTH(r.`tx_time`)=12 THEN r.`tx_time`<'{txminute}'
            END
        WHEN '{state}'='DONE' THEN
            CASE
            WHEN LENGTH(r.`tx_time`)=6 THEN r.`tx_time`>='{txmonth}'  
            WHEN LENGTH(r.`tx_time`)=8 THEN r.`tx_time`>='{txdate}'
            WHEN LENGTH(r.`tx_time`)=10 THEN r.`tx_time`>='{txhour}'
            WHEN LENGTH(r.`tx_time`)=12 THEN r.`tx_time`>='{txminute}'
            END
        ELSE r.`state`='{state}'
        END
""".strip('\r\n')

job_records_sql="""
SELECT
    j.`name` AS '任务名称',
    j.`man` AS '负责人',
    j.`group` AS '任务组',
    j.`timer` AS '定时',
    r.`host` AS '服务器',
    r.`state` AS '任务状态',
    r.`tx_time` AS '数据日期',
    r.`start_time` AS '开始时间',
    r.`end_time` AS '结束时间',
    r.`exit_code` AS '返回值',
    r.`retried` AS '重试次数'
FROM
    sched_job j
LEFT JOIN
    sched_job_record r
ON
    j.`name`=r.`name`
WHERE
    j.`enable`=1
    AND IF('{name}'='',1=1,IF({exact}=1,j.`name`='{name}',j.`name` LIKE '%{name}%'))
    AND CASE WHEN {link_id}=1
    THEN
        {dim_field}
        AND """+__job_records_state_part+"""
    ELSE
        IF('{man}'='{all}',1=1,j.`man`='{man}')
        AND IF('{group}'='{all}',1=1,j.`group`='{group}')
        AND IF('{host}'='{all}',1=1,r.`host`='{host}')
        AND IF('{tx_time}'='{all}',1=1,r.`tx_time`='{tx_time}')
        AND """+__job_records_state_part+"""
    END 
LIMIT
    {page_offset},{page_rows}
"""

job_sql="""
SELECT
    `name` AS '名称',
    REPLACE(`cmd`,'{job_home}','$jobs') AS '命令',
    `timer` AS '定时',
    `host` AS '服务器',
    `priority` AS '优先级',
    `retries` AS '重试',
    `delay` AS '延迟',
    `step` AS '步调',
    `timeout` AS '超时',
    `zipper` AS '拉链',
    `transfer` AS '可转移',
    `man` AS '负责人',
    `group` AS '任务组',
    REPLACE(`path`,'{log_home}','$logs') AS '日志路径',
    `desc` AS '描述',
    `enable` AS '启用'
FROM
    sched_job
WHERE
    `name`='{name}'
"""

job_sql2="""
SELECT
    *
FROM
    sched_job
WHERE
    `name`='{name}'
"""

job_sql3="""
SELECT
    *
FROM
    sched_job
WHERE
    `name` LIKE '%{name}%'
"""

record_sql="""
SELECT
    `name` AS '名称',
    `state` AS '状态',
    REPLACE(`cmd`,'{job_home}','$jobs') AS '命令',
    `tx_time` AS '数据时间',
    `start_time` AS '开始时间',
    `end_time` AS '结束时间',
    `exit_code` AS '返回值',
    `retried` AS '重试',
    `host` AS '服务器',
    REPLACE(`path`,'{log_home}','$logs') AS '日志路径'
FROM
    sched_job_record
WHERE
    `name`='{name}'
"""

record_sql2="""
SELECT
    *
FROM
    sched_job_record
WHERE
    `name`='{name}'
"""

record_log_sql="""
SELECT
    *
FROM
    sched_job_log
WHERE
    `name`='{name}' AND `tx_time`='{tx_time}'
"""

log_sql="""
SELECT
    `name` AS '任务名称',
    `start_time` AS '开始时间',
    `end_time` AS '结束时间',
    CONCAT(ROUND(TIMESTAMPDIFF(MINUTE,`start_time`,`end_time`)/60,2),'h') AS '运行时长',
    `exit_code` AS '返回值',
    `retried` AS '重试次数',
    `host` AS '服务器',
    `state` AS '任务状态',
    `tx_time` AS '数据时间'
FROM
    sched_job_log
WHERE
    `name`='{name}' AND IF(LENGTH(`tx_time`)=8,`tx_time`>='{last_mdate}',1=1)
ORDER BY
    id DESC
"""

runtime_records_sql="""
SELECT
    j.`man` AS '负责人',
    j.`name` AS '任务名称',
    j.`desc` AS '任务描述',
    r.`host` AS '服务器',
    r.`start_time` AS '开始时间',
    r.`end_time` AS '结束时间',
    CONCAT(ROUND(TIMESTAMPDIFF(MINUTE,r.`start_time`,r.`end_time`)/60,2),'h') AS '运行时长',
    r.`state` AS '任务状态',
    r.`tx_time` AS '数据日期'
FROM
    sched_job j
LEFT JOIN
    sched_job_record r
ON
    j.`name`=r.`name` AND j.`enable`=1 AND r.`state`='DONE' AND r.`tx_time`='{tx_time}'
ORDER BY
    TIMESTAMPDIFF(MINUTE,r.`start_time`,r.`end_time`) DESC
LIMIT
    {topn}
"""

runtime_logs_sql="""
SELECT
    j.`man` AS '负责人',
    j.`name` AS '任务名称',
    j.`desc` AS '任务描述',
    r.`host` AS '服务器',
    r.`start_time` AS '开始时间',
    r.`end_time` AS '结束时间',
    CONCAT(ROUND(TIMESTAMPDIFF(MINUTE,r.`start_time`,r.`end_time`)/60,2),'h') AS '运行时长',
    r.`state` AS '任务状态',
    r.`tx_time` AS '数据日期'
FROM
    sched_job j
LEFT JOIN
(
    SELECT
        *
    FROM
        sched_job_log
    WHERE
        `state`='DONE' AND `tx_time`='{tx_time}'
) r
ON
    j.`name`=r.`name` AND j.`enable`=1
ORDER BY
    TIMESTAMPDIFF(MINUTE,r.`start_time`,r.`end_time`) DESC
LIMIT
    {topn}
"""

depends_sql="""
SELECT
    *
FROM
    sched_job_dependency
WHERE
    `name`='{name}'
"""

depend_sql="""
SELECT
    `name` AS '任务名称',
    `dependency` AS '任务依赖',
    `enable` AS '是否有效'
FROM
    sched_job_dependency
WHERE
    `name`='{name}'
"""

forward_depend_sql="""
SELECT
    j.`name` AS '任务名称',
    j.`man` AS '负责人',
    j.`timer` AS '任务定时',
    r.`host` AS '服务器',
    r.`start_time` AS '开始时间',
    r.`end_time` AS '结束时间',
    r.`exit_code` AS '返回值',
    r.`state` AS '任务状态',
    r.`tx_time` AS '数据时间'
FROM
    sched_job j
LEFT JOIN
    sched_job_record r
ON
    j.`name`=r.`name`
WHERE
    j.`enable`=1
    AND j.`name` IN (SELECT `dependency` FROM sched_job_dependency WHERE `enable`=1 AND `name`='{name}')
"""

backward_depend_sql="""
SELECT
    j.`name` AS '任务名称',
    j.`man` AS '负责人',
    j.`timer` AS '任务定时',
    r.`host` AS '服务器',
    r.`start_time` AS '开始时间',
    r.`end_time` AS '结束时间',
    r.`exit_code` AS '返回值',
    r.`state` AS '任务状态',
    r.`tx_time` AS '数据时间'
FROM
    sched_job j
LEFT JOIN
    sched_job_record r
ON
    j.`name`=r.`name`
LEFT JOIN
    sched_job_dependency d
ON
    j.`name`=d.`name`
WHERE
    j.`enable`=1 AND d.`enable`=1 AND d.`dependency`='{dependency}'
"""

check_depends_sql="""
SELECT
    `name`
FROM
    sched_job
WHERE
    `enable`=1 AND `name` IN ('{depends}') 
"""

check_depend_sql="""
SELECT
    `dependency`
FROM
    sched_job_dependency
WHERE
    `enable`=1 AND `name`='{name}' AND `dependency` IN ('{depends}')
"""

insert_sql="INSERT INTO {table} ({keys}) VALUES ({values}) "

update_sql="UPDATE {table} SET {sets} WHERE {where} "

delete_sql="DELETE FROM {table} WHERE {where}"

total_extract_table_sql = "select * from task_info_cfg"

fetch_extract_detail = "select * from task_info_cfg where task_id = %s"

update_extract_detail = '''update task_info_cfg set task_name="%s", task_type_id=%s, client_domain="%s", client_ip="%s", client_port=%s, tbl_name="%s",
                           dbsrc_id=%s, hive_db_name="%s", hive_tbl_name="%s", task_sql_all="%s", task_sql_filter="%s", is_increment=%s, exec_cfg_id=%s,
                           task_sql_insert="%s", step_lines=%s, dbtgt_id=%s where task_id=%s'''

total_source_table_sql = "SELECT * FROM db_source_cfg"
fetch_source_detail = "select * from db_source_cfg where dbsrc_id = %s"
update_source_detail = '''update db_source_cfg set dbsrc_type_id=%d, dbsrc_name="%s", db_ip="%s", db_port="%s", db_name="%s", db_user="%s",
                          db_password="%s", db_schema="%s", db_instance="%s", enable=%d where dbsrc_id=%d'''
