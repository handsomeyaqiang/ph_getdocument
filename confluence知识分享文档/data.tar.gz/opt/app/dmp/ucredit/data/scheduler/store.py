#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys
import os
import re
import time
import shelve
from threading import Lock
from utils import param2str,mt2obj,obj2mt,log,get_value
from job import Job,JobUser,JobState
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
from data.scheduler.conf import conf

class JobStore(object):
    
    def __init__(self,logger=None,conf=None):
        self._logger=logger
        self._lock=Lock()
        self._query_opers=dict(get=1,has=1,list=1)
        self._sched_job=get_value(conf,'sched_job','sched_job')
        self._sched_job_record=get_value(conf,'sched_job_record','sched_job_record')
        self._sched_job_dependency=get_value(conf,'sched_job_dependency','sched_job_dependency')
        self._sched_job_log=get_value(conf,'sched_job_log','sched_job_log')
        self._sched_job_user=get_value(conf,'sched_job_user','sched_job_user')
#        self._sched_dbc=get_value(conf,'sched_dbc',dict(host='10.255.33.6',port=3306,user='etluser',passwd='etluser',db='db_datamgrcfg'))
        self._sched_dbc=get_value(conf,'sched_dbc',conf.sched_dbc)
        self._init()
        
    def get_logger(self):
        return self._logger
    
    def _init(self):
        pass
    
    def log(self,msg,**kwargs):
        log(msg,logger=self._logger)
        
    def _get_oper_obj(self,func):
        fname=func.__name__.lstrip('_')
        fparts=fname.split('_')
        oper=fparts[0]
        obj=fparts[1]
        return fname,oper,obj
    
    def do(self,func,*args,**kwargs):
        fname,oper,obj=self._get_oper_obj(func)
        params=param2str(*args,**kwargs)
        fps='{func}({params})'.format(func=fname,params=params)
        try:
            if oper not in self._query_opers:
                self._lock.acquire()
            result=func(db,*args,**kwargs)
            name=args and ','.join(args) or ''
            if result is None:
                self.log("{fps}: no such {obj} {name}".format(fps,obj=obj,name=name))
            elif result==-1:
                self.log('{fps}: {obj} {name} is already exists'.format(fps=fps,obj=obj,name=name))
            else:
                self.log('{fps}: success'.format(fps=fps))
            return result
        except Exception as error:
            self.log('{fps}: failed, because {error}'.format(fps=fps,error=error))
            if oper in self._query_opers:
                return None
            return False
        finally:
            if oper not in self._query_opers:
                self._lock.release()
                
    def has_job(self,name):
        return self.do(self._has_job,name)
        
    def _has_job(self,name):
        pass
    
    def get_job(self,name):
        return self.do(self._get_job,name)
    
    def _get_job(self,name):
        pass
    
    def get_jobs(self,enable=1,**kwargs):
        return self.do(self._get_jobs,enable=enable,**kwargs)
    
    def _get_jobs(self,enable=1,**kwargs):
        pass
    
    def get_job_records(self,enable=1,**kwargs):
        return self.do(self._get_job_records,enable=enable,**kwargs)
    
    def _get_job_records(self,enable=1,**kwargs):
        return self.do(self._get_job_records,enable=enable,**kwargs)
    
    def get_periodic_jobs(self):
        return self.do(self._get_periodic_jobs)
        
    def _get_periodic_jobs(self):
        pass
    
    def get_full_jobs(self):
        return self.do(self._get_full_jobs)
        
    def _get_full_jobs(self):
        pass
    
    def get_undone_jobs(self,tx_time=None):
        return self.do(self._get_undone_jobs,tx_time=tx_time)
        
    def _get_undone_jobs(self,tx_time=None):
        pass
    
    def get_redo_jobs(self,**kwargs):
        return self.do(self._get_redo_jobs,**kwargs)
        
    def _get_redo_jobs(self,**kwargs):
        pass
    
    def add_job(self,name,**kwargs):
        job=Job(name=name,**kwargs)
        job=job.to_dict()
        job.pop('name')
        return self.do(self._add_job,name,**job)
        
    def _add_job(self,name,**kwargs):
        pass
    
    def add_jobs(self,jobs):
        _jobs=[]
        for job in jobs:
            name=job.pop('name',None)
            _job=Job(name=name,**job)
            _job=_job.to_dict()
            _jobs.append(_job)
        return self.do(self._add_jobs,_jobs)
    
    def _add_jobs(self,jobs):
        for job in jobs:
            name=job.pop('name')
            self._add_job(name,**job)
            
    def update_job(self,name,**kwargs):
        return self.do(self._update_job,name,**kwargs)
    
    def _update_job(self,name,**kwargs):
        pass
    
    def update_jobs(self,jobs):
        return self.do(self._update_jobs,jobs)
    
    def _update_jobs(self,jobs):
        for job in jobs:
            name=job.pop('name')
            self._update_job(name,**job)
            
    def remove_job(self,name):
        return self.do(self._remove_job,name)
        
    def _remove_job(self,name):
        pass
    
    def remove_jobs(self,jobs):
        return self.do(self._remove_jobs,jobs)
        
    def _remove_jobs(self,jobs):
        for name in jobs:
            self._remove_job(name)
            
    def has_record(self,name):
        return self._has_record(name)
    
    def _has_record(self,name):
        pass
    
    def get_record(self,name):
        return self.do(self._get_record,name)
    
    def _get_record(self,name):
        pass
    
    def get_records(self,**kwargs):
        return self.do(self._get_records,**kwargs)
    
    def _get_records(self,**kwargs):
        pass
    
    def add_record(self,name,**kwargs):
        return self.do(self._add_record,name,**kwargs)
    
    def _add_record(self,name,**kwargs):
        pass
    
    def update_record(self,name,**kwargs):
        return self.do(self._update_record,name,**kwargs)
    
    def _update_record(self,name,**kwargs):
        pass
    
    def update_records(self,records):
        return self.do(self._update_records,records)
        
    def _update_records(self,records):
        for record in records:
            name=record.pop('name')
            self._update_record(name,**record)
            
    def remove_record(self,name):
        return self.do(self._remove_record,name)
    
    def _remove_record(self,name):
        pass
    
    def remove_records(self,records):
        return self.do(self._remove_records,records)
    
    def _remove_records(self,records):
        for name in records:
            self._remove_record(name)
            
    def renew_record(self,name,**kwargs):
        return self.do(self._renew_record,name,**kwargs)
    
    def _renew_record(self,name,**kwargs):
        pass
    
    def add_log(self,name,**kwargs):
        return self.do(self._add_log,name,**kwargs)
    
    def _add_log(self,name,**kwargs):
        pass
    
    def get_log(self,name,tx_time=None):
        return self.do(self._get_log,name,tx_time=tx_time)
        
    def _get_log(self,name,tx_time=None):
        pass
    
    def get_logs(self,**kwargs):
        return self.do(self._get_logs,**kwargs)
    
    def _get_logs(self,**kwargs):
        pass
    
    def remove_log(self,name,tx_time=None):
        return self.do(self._remove_log,name,tx_time=tx_time)
        
    def _remove_log(self,name,tx_time=None):
        pass
    
    def add_dependency(self,name,depend):
        return self.do(self._add_dependency,name,depend)
    
    def _add_dependency(self,name,depend):
        pass
    
    def add_depend(self,depend,name):
        return self.do(self._add_depend,depend,name)
        
    def _add_depend(self,depend,name):
        pass
    
    def get_depend(self,name,enable=1):
        return self.do(self._get_depend,name,enable=enable)
    
    def _get_depend(self,name,enable=1):
        pass
    
    def get_depends(self,enable=1):
        return self.do(self._get_depends,enable=enable)
        
    def _get_depends(self,enable=1):
        pass
    
    def update_dependency(self,name,**kwargs):
        return self.do(self._update_dependency,name,**kwargs)
        
    def _update_dependency(self,name,**kwargs):
        pass
    
    def update_depend(self,depend,**kwargs):
        return self.do(self._update_depend,depend,**kwargs)
        
    def _update_depend(self,depend,**kwargs):
        pass
    
    def remove_dependency(self,name,depend):
        return self.do(self._remove_dependency,name,depend)
    
    def _remove_dependency(self,name,depend):
        pass
    
    def remove_depend(self,depend,name=None):
        return self.do(self._remove_depend,depend,name=name)
        
    def _remove_depend(self,depend,name=None):
        pass
    
    def has_user(self,name):
        return self.do(self._has_user,name)
    
    def _has_user(self,name):
        pass
    
    def get_user(self,name):
        return self.do(self._get_user,name)
    
    def _get_user(self,name):
        pass
    
    def get_users(self,enable=1,**kwargs):
        return self.do(self._get_users,enable=enable,**kwargs)
    
    def _get_users(self,enable=1,**kwargs):
        pass
    
    def add_user(self,name,**kwargs):
        user=JobUser(name=name,**kwargs)
        user=user.to_dict()
        user.pop('name')
        return self.do(self._add_user,name,**user)
    
    def _add_user(self,name,**kwargs):
        pass
    
    def update_user(self,name,**kwargs):
        return self.do(self._update_user,**kwargs)
    
    def _update_user(self,name,**kwargs):
        pass
    
    def remove_user(self,name):
        return self.do(self._remove_user)
    
    def _remove_user(self,name):
        pass
    
class MemoryStore(JobStore):
    
    def _init(self):
        self._jobs=dict()
        self._records=dict()
        self._logs=dict()
        self._depends=dict()
        self._users=dict()
        
    def _has_job(self,name):
        return name in self._jobs
    
    def _get_job(self,name):
        job=self._jobs.get(name)
        if job is None:
            return None
        return dict(name=name,**job)
    
    def _get_jobs(self,enable=1,**kwargs):
        attrs=dict(enable=enable,**kwargs)
        jobs=dict()
        for name in self._jobs:
            job=self._jobs.get(name)
            _job=dict(name=name,**job)
            if all(_job.get(k)==v for k,v in _job.items()):
                jobs[name]=job
        return jobs
    
    def _get_periodic_jobs(self):
        jobs=list()
        for name in self._jobs:
            job=self._jobs[name]
            if not job['enable']:
                continue
            if job.get('timer'):
                record=self._records.get('name',{})
                job['state']=record.get('state')
                job['tx_time']=record.get('tx_time')
                jobs.append(job)
        return jobs
    
    def _get_full_jobs(self):
        jobs=dict()
        depends=self._get_depends()
        for name in self._jobs:
            job=self._jobs.get('name')
            if not job['enable']:
                continue
            record=self._records.get(name)
            job['state']=record.get('state')
            job['tx_time']=record.get('tx_time')
            job['depends']=depends.get(name,{})
            jobs[name]=job
        return jobs
    
    def _get_undone_jobs(self,tx_time=None):
        jobs=list()
        for name in self._jobs:
            job=self._jobs[name]
            if not job['enable']:
                continue
            record=self._records.get('name',{})
            state=record.get('state')
            if state and state in (JobState.PENDING,JobState.RUNNING):
                job['host']=record.get('host') or job['host']
                if tx_time is None:
                    jobs.append(job)
                else:
                    if record['tx_time']==tx_time:
                        jobs.append(job)
        return jobs
    
    def _get_redo_jobs(self,tx_time=None,state=None):
        jobs=list()
        for _name in self._jobs:
            job=self._jobs[_name]
            if not job['enable']:
                continue
            record=self._records.get('name',{})
            rstate=record.get('state')
            if (state and state==rstate) or (state is None and rstate and rstate!=JobState.DONE):
                if tx_time is None:
                    jobs.append(job)
                else:
                    if record['tx_time']==tx_time:
                        jobs.append(job)
        return jobs
    
    def _get_records(self,**kwargs):
        if kwargs:
            records=dict()
            for name in self._records:
                record=self._records.get(name)
                _record=dict(name=name,**record)
                if all(_record.get(k)==v for k,v in kwargs.items() if k in _record):
                    records[name]=record
            return records
        return self._records
    
    def _add_job(self,name,**kwargs):
        if name in self._jobs:
            return -1
        self._jobs[name]=kwargs
        return True
    
    def _update_job(self,name,**kwargs):
        job=self._jobs.get(name)
        if job is None:
            return None
        self._jobs[name].update(kwargs)
        return True
    
    def _remove_job(self,name):
        if name not in self._jobs:
            return None
        self._jobs.pop(name)
        return True
    
    def _has_record(self,name):
        return name in self._records
    
    def _get_record(self,name):
        record=self._records.get(name)
        if record is None:
            return None
        return dict(name=name,**record)
    
    def _add_record(self,name,**kwargs):
        if name in self._records:
            return -1
        self._records[name].update(kwargs)
        return True
    
    def _update_record(self,name,**kwargs):
        if name not in self._records:
            self._records[name]=kwargs
        else:
            self._records[name].update(kwargs)
        return True
    
    def _remove_record(self,name):
        if name not in self._records:
            return None
        self._records.pop(name)
        return True
    
    def _renew_record(self,name,**kwargs):
        self._records.pop(name,None)
        self._records[name]=kwargs
        return True
    
    def _get_log(self,name,tx_time=None):
        if name in self._logs:
            if tx_time is not None:
                for log in self._logs[name]:
                    if tx_time==log['tx_time']:
                        return dict(name=name,**log)
            else:
                logs=self._logs.get(name)
                return [dict(name=name,**log) for log in logs]
        return None
    
    def _get_logs(self,**kwargs):
        if kwargs:
            logs=dict()
            for name in self._logs:
                for log in self._logs[name]:
                    if all(log.get(k)==v for k,v in kwargs.items() if k in log):
                        logs.setdefault(name,[]).append(log)
            return logs
        return self._logs
    
    def _add_log(self,name,**kwargs):
        if name in self._logs:
            self._logs[name].append(kwargs)
        else:
            self._logs[name]=[kwargs]
        return True
    
    def _remove_log(self,name,tx_time=None):
        if name not in self._logs:
            return None
        if tx_time is None:
            return self._logs.pop(name)
        for log in self._logs[name]:
            if tx_time==log['tx_time']:
                logs=self._logs[name]
                logs.remove(log)
                self._logs[name]=logs
                return True
        return None
    
    def _get_depend(self,name,enable=1):
        if name not in self._depends:
            return []
        depends=[]
        for depend in self._depends[name]:
            row=self._depends[name][depend]
            if row.get('enable')==enable:
                depends.append(depend)
        return depends
    
    def _get_depends(self,enable=1):
        depends=dict()
        for name in self._depends:
            for depend in self._depends[name]:
                row=self._depends[name][depend]
                if row.get('enable')==enable:
                    if name in depends:
                        depends[name][depend]=row
                    else:
                        depends[name]={depend:row}
        return depends
    
    def _add_dependency(self,name,depend):
        if name in self._depends:
            if depend in self._depends[name]:
                return -1
            self._depends[name][depend]=dict(enable=1)
        else:
            self._depends[name]={depend:dict(enable=1)}
        return True
    
    def _add_depend(self,depend,name):
        depends=isinstance(depend,basestring) and depend.split(',') or depend
        for depend in depends:
            if name in self._depends:
                if depend in self._depends[name]:
                    continue
                self._depends[name][depend]=dict(enable=1)
            else:
                self._depends[name]={depend:dict(enable=1)}
        return True
    
    def _update_dependency(self,name,**kwargs):
        depends=self._depends.get(name)
        if name not in self._depends:
                return None
        for depend in self._depends:
            _depend=self._depends[name][depend]
            _depend.update(kwargs)
            self._depends[name][depend]=_depend
        return True
    
    def _update_depend(self,depend,**kwargs):
        for name in self._depends:
            for _depend in self._depends[name]:
                if depend in self._depends[name][_depend]:
                    __depend=self._depends[name][_depend]
                    __depend.update(kwargs)
                    self._depends[name][_depend]=__depend
        return True
    
    def _remove_dependency(self,name,depend):
        if name in self._depends:
            if depend in self._depends[name]:
                self._depends[name].pop(depend)
                return True
        return None
    
    def _remove_depend(self,depend,name=None):
        if name:
            depends=self._depends.get(name)
            if not depends:
                return None
            if depend in depends:
                self._depends[name].pop(depend)
                return True
            return None
        for name in self._depends:
            if depend in self._depends[name]:
                self._depends[name].pop(depend)
        return True
    
    def _has_user(self,name):
        return name in self._users
    
    def _get_user(self,name):
        if name in self._users:
            return dict(name=name,**self._users[name])
        return None
    
    def _get_users(self,enable=1,**kwargs):
        where=dict(enable=enable,**kwargs)
        users=dict()
        for name in self._users:
            user=self._users[name]
            _user=dict(name=name,**user)
            if all(_user.get(k)==v for k,v in where.items() if k in _user):
                users[name]=user
        return users
    
    def _add_user(self,name,**kwargs):
        if name in self._users:
            return -1
        self._users[name]=kwargs
        return True
    
    def _update_user(self,name,**kwargs):
        if name not in self._users:
            return None
        self._users[name]=kwargs
        return True
    
    def _remove_user(self,name):
        if name not in self._users:
            return None
        self._users.pop(name)
        return True
    
_obj_pat=re.compile(r'_(job|record|log|depend)')

class ShelveStore(JobStore):
    
    def _init(self):
        self._path='{path}{sep}db{sep}'.format(path=os.getcwd(),sep=os.sep)
        self._job_db='{path}{job}.db'.format(path=self._path,job=self._sched_job)
        self._record_db='{path}{record}.db'.format(path=self._path,record=self._sched_job_record)
        self._log_db='{path}{log}.db'.format(path=self._path,log=self._sched_job_log)
        self._depend_db='{path}{depend}.db'.format(path=self._path,depend=self._sched_job_dependency)
        self._user_db='{path}{user}.db'.format(path=self._path,user=self._sched_job_user)
        
    def _open_db(self,db):
        if not os.path.exists(self._path):
            os.mkdir(self._path)
        return shelve.open(db)
        
    def _get_db_name(self,fname):
        m=re.search(_obj_pat,fname)
        if m:
            some_db=getattr(self,'_{some}_db'.format(some=m.group(1)))
            return some_db
        else:
            raise Exception("no such func {func}'s db".format(func=fname))
            
    def do(self,func,*args,**kwargs):
        fname,oper,obj=self._get_oper_obj(func)
        params=param2str(*args,**kwargs)
        fps='{func}({params})'.format(func=fname,params=params)
        db=None
        try:
            if oper not in self._query_opers:
                self._lock.acquire()
            some_db=self._get_db_name(fname)
            db=self._open_db(some_db)
            result=func(db,*args,**kwargs)
            name=args and ','.join(args) or ''
            if result is None:
                self.log("{fps}: no such {obj} {name}".format(fps=fps,obj=obj,name=name))
            elif result==-1:
                self.log('{fps}: {obj} {name} is already exists'.format(fps=fps,obj=obj,name=name))
            else:
                self.log('{fps}: success'.format(fps=fps))
            return result
        except Exception as error:
            self.log('{fps}: failed, because {error}'.format(fps=fps,error=error))
            if oper in self._query_opers:
                return None
            return False
        finally:
            if db:
                db.close()
            if oper not in self._query_opers:
                self._lock.release()
                
    def _has_job(self,db,name):
        return name in db
    
    def _get_job(self,db,name):
        if name in db:
            return dict(name=name,**db[name])
        return None
    
    def _add_job(self,db,name,**kwargs):
        if name in db:
            return -1
        db[name]=kwargs
        return True
    
    def _add_jobs(self,db,jobs):
        for job in jobs:
            name=job.pop('name')
            if name in db:
                continue
            db[name]=job
        return True
    
    def _update_job(self,db,name,**kwargs):
        if name in db:
            job=db[name]
            job.update(kwargs)
            db[name]=job
            return True
        return None
    
    def _update_jobs(self,db,jobs):
        for job in jobs:
            name=job.pop('name')
            if name in db:
                _job=db[name]
                _job.update(job)
                db[name]=_job
        return True
    
    def _remove_job(self,db,name):
        if name in db:
            del db[name]
            return True
        return None
    
    def _remove_jobs(self,db,jobs):
        for name in jobs:
            if name in db:
                del db[name]
        return True
    
    def _get_jobs(self,db,enable=1,**kwargs):
        attrs=dict(enable=enable,**kwargs)
        jobs=dict()
        for name in db:
            job=db[name]
            _job=dict(name=name,**job)
            if all(_job.get(k)==v for k,v in _job.items()):
                jobs[name]=job
        return jobs
    
    def _get_periodic_jobs(self,db):
        records=self.get_records()
        jobs=list()
        for name in db:
            job=db[name]
            if job['timer'] and job['enable']:
                record=records.get(name,dict())
                job['state']=record.get('state')
                job['tx_time']=record.get('tx_time')
                jobs.append(job)
        return jobs
    
    def _get_full_jobs(self,db):
        jobs=dict()
        rows=self._get_jobs(db)
        records=self.get_records()
        depends=self.get_depends()
        for row in rows:
            name=row.pop('name')
            record=records.get(name)
            row['state']=record.get('state')
            row['tx_time']=record.get('tx_time')
            row['depends']=depends.get(name,{})
            jobs[name]=row
        return jobs
    
    def _get_undone_jobs(self,db,tx_time=None):
        records=self.get_records()
        jobs=list()
        for name in db:
            job=db[name]
            if not job['enable']:
                continue
            record=records.get(name,dict())
            state=record.get('state')
            if state and state in (JobState.PENDING,JobState.RUNNING):
                job['host']=record['host'] or job['host']
                if tx_time is None:
                    jobs.append(job)
                else:
                    if record['tx_time']==tx_time:
                        jobs.append(job)
        return jobs
    
    def _get_redo_jobs(self,db,tx_time=None,state=None):
        records=self.get_records()
        jobs=list()
        for name in db:
            job=db[name]
            if not job['enable']:
                continue
            record=records.get(name,dict())
            last_state=record.get('state')
            if (state and state==last_state) or (state is None and last_state and last_state!=JobState.DONE):
                if tx_time is None:
                    jobs.append(job)
                else:
                    if record['tx_time']==tx_time:
                        jobs.append(job)
        return jobs
    
    def _get_records(self,db,**kwargs):
        records=dict()
        for name in db:
            record=db[name]
            if not kwargs:
                records[name]=record
            _record=dict(name=name,**record)
            if kwargs and all(_record.get(k)==v for k,v in kwargs.items() if k in _record):
                records[name]=record
        return records
    
    def _has_record(self,db,name):
        return name in db
    
    def _get_record(self,db,name):
        if name in db:
            return dict(name=name,**db[name])
        return None
    
    def _add_record(self,db,name,**kwargs):
        if name in db:
            return -1
        db[name]=kwargs
        return True
    
    def _update_record(self,db,name,**kwargs):
        if name in db:
            record=db[name]
            record.update(kwargs)
            db[name]=record
        else:
            db[name]=kwargs
        return True
    
    def _update_records(self,db,records):
        for record in records:
            name=record.pop('name')
            if name in db:
                _record=db[name]
                _record.update(record)
                db[name]=_record
            else:
                db[name]=record
        return True
    
    def _remove_record(self,db,name):
        if name in db:
            del db[name]
            return True
        return None
    
    def _remove_records(self,db,records):
        for name in records:
            if name in db:
                del db[name]
        return True
    
    def _renew_record(self,db,name,**kwargs):
        if name in db:
            del db[name]
        db[name]=kwargs
        return True
    
    def _add_log(self,db,name,**kwargs):
        if name in db:
            logs=db[name]
            logs.append(kwargs)
            db[name]=logs
        else:
            db[name]=[kwargs]
        return True
    
    def _get_log(self,db,name,tx_time=None):
        if name in db:
            if tx_time is None:
                logs=db[name]
                return [dict(name=name,**log) for log in logs]
            else:
                for log in db[name]:
                    if tx_time==log['tx_time']:
                        return dict(name=name,**log)
        return None
    
    def _get_logs(self,db,**kwargs):
        logs=dict()
        for name in db:
            if not kwargs:
                logs[name]=db[name]
            else:
                for log in db[name]:
                    _log=dict(name=name,**log)
                    if kwargs and all(_log.get(k)==v for k,v in kwargs.items() if k in _log):
                        logs.setdefault(name,[]).append(log)
        return logs
    
    def _remove_log(self,db,name,tx_time=None):
        if name in db:
            if tx_time is None:
                del db[name]
                return True
            else:
                for log in db[name]:
                    if tx_time==log['tx_time']:
                        logs=db[name]
                        logs.remove(log)
                        db[name]=logs
                        return True
        return None
    
    def _get_depend(self,db,name,enable=1):
        depends=[]
        if name in db:
            for depend in db[name]:
                row=db[name][depend]
                if row.get('enable')==enable:
                    depends.append(depend)
        return depends
    
    def _get_depends(self,db,enable=1):
        depends=dict()
        for name in db:
            for depend in db[name]:
                row=db[name][depend]
                if row.get('enable')==enable:
                    if name in depends:
                        depends[name][depend]=row
                    else:
                        depends[name]={depend:row}
        return depends
    
    def _add_dependency(self,db,name,depend):
        if name in db:
            if depend in db[name]:
                return -1
            else:
                db[name][depend]=dict(enable=1)
        else:
            db[name]={depend:dict(enable=1)}
        return True
    
    def _add_depend(self,db,depend,name):
        depends=isinstance(depend,basestring) and depend.split(',') or depend
        for depend in depends:
            if name in db:
                if depend in db[name]:
                    continue
                else:
                    db[name][depend]=dict(enable=1)
            else:
                db[name]={depend:dict(enable=1)}
        return True
    
    def _update_dependency(self,db,name,**kwargs):
        if name not in db:
            return None
        for depend in db[name]:
            _depend=db[name][depend]
            _depend.update(kwargs)
            db[name][depend]=_depend
        return True
    
    def _update_depend(self,db,depend,**kwargs):
        for name in db:
            for _depend in db[name]:
                if depend in db[name][_depend]:
                    __depend=db[name][_depend]
                    __depend.update(kwargs)
                    db[name][_depend]=__depend
        return True
    
    def _remove_dependency(self,db,name,depend):
        if name in db:
            if depend in db[name]:
                d=db[name]
                d.pop(depend)
                db[name]=d
                return True
        return None
    
    def _remove_depend(self,db,depend,name=None):
        if name:
            if name in db:
                depends=db[name]
                if depend not in depends:
                    return None
                depends.pop(depend)
                db[name]=depends
                return True
            return None
        for name in db:
            depends=db[name]
            if depend not in depends:
                continue
            depends.pop(depend)
            db[name]=depends
        return True
    
    def _has_user(self,db,name):
        return name in db
    
    def _get_user(self,db,name):
        if name in db:
            return dict(name=name,**db[name])
        return None
    
    def _get_users(self,db,enable=1,**kwargs):
        where=dict(enable=enable,**kwargs)
        users=dict()
        for name in db:
            user=db[name]
            _user=dict(name=name,**user)
            if all(_user.get(k)==v for k,v in where.items() if k in _user):
                users[name]=user
        return users
    
    def _add_user(self,db,name,**kwargs):
        if name in db:
            return -1
        db[name]=kwargs
        return True
    
    def _update_user(self,db,name,**kwargs):
        if name not in db:
            return None
        db[name]=kwargs
        return True
    
    def _remove_user(self,db,name):
        if name not in db:
            return None
        del db[name]
        return True
    
class TableStore(JobStore):
    
    def _init(self):
        self._dbc=self._sched_dbc
        self._job_table=self._sched_job
        self._record_table=self._sched_job_record
        self._log_table=self._sched_job_log
        self._depend_table=self._sched_job_dependency
        self._user_table=self._sched_job_user
        
    def do(self,func,*args,**kwargs):
        charset=kwargs.pop('charset','utf8')
        to_dict=kwargs.pop('to_dict',True)
        retries=kwargs.pop('retries',3)
        fname,oper,obj=self._get_oper_obj(func)
        params=param2str(*args,**kwargs)
        fps='{func}({params})'.format(func=fname,params=params)
        import MySQLdb
        conn,cursor=None,None
        try:
            #if oper not in self._query_opers:
            #    self._lock.acquire()
            conn=MySQLdb.connect(**self._dbc)
            cursor=conn.cursor(to_dict and MySQLdb.cursors.DictCursor or MySQLdb.cursors.Cursor)
            cursor.execute("SET NAMES %s" % charset)
            result=func(cursor,*args,**kwargs)
            conn.commit()
            name=args and ','.join(args) or ''
            if result is None:
                self.log("{fps}: no such {obj} {name}".format(fps=fps,obj=obj,name=name))
            elif result==-1:
                self.log('{fps}: {obj} {name} is already exists'.format(fps=fps,obj=obj,name=name))
            else:
                self.log('{fps}: success'.format(fps=fps))
            return result
        except Exception as error:
            self.log('{fps}: failed, because {error}'.format(fps=fps,error=error))
            if conn:
                conn.rollback()
            if retries>0:
                time.sleep(1)
                kwargs['retries']=retries-1
                return self.do(func,*args,**kwargs)
            else:
                raise error
            if oper in self._query_opers:
                return None
            return False
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
            #if oper not in self._query_opers:
            #    self._lock.release()
            
    def _get_where_value(self,value):
        value=obj2mt(value)
        if value=='NULL':
            return 'IS NULL'
        return '={value}'.format(value=value)
    
    def _add(self,cursor,table,**kwargs):
        keys=kwargs.keys()
        values=','.join(map(lambda key:obj2mt(kwargs.get(key)),keys))
        keys=','.join(map(lambda key:'`{key}`'.format(key=key),keys))
        sql="INSERT INTO {table} ({keys}) VALUES ({values})".format(table=table,keys=keys,values=values)
        cursor.execute(sql)
        return True
    
    def _add_many(self,cursor,table,keys,values):
        _keys=','.join(map(lambda key:'`{key}`'.format(key=key),keys))
        sql="INSERT INTO {table} ({keys}) VALUES ({values})".format(table=table,keys=_keys,values=','.join('%s' for k in keys))
        cursor.executemany(sql,values)
        return True
    
    def _get(self,cursor,table,**kwargs):
        other=kwargs.pop('other','')
        fields=kwargs.pop('fields','*')
        where=' AND '.join("`{k}`{v}".format(k=k,v=self._get_where_value(v)) for k,v in kwargs.items()) or '1=1'
        if other:
            where=where+' '+other
        sql="SELECT {fields} FROM {table} WHERE {where}".format(fields=fields,table=table,where=where)
        cursor.execute(sql)
        rows=cursor.fetchall()
        return self._switch_rows(rows)
    
    def _update(self,cursor,table,where=None,**kwargs):
        if where:
            where=' AND '.join('`{k}`{v}'.format(k=k,v=self._get_where_value(v)) for k,v in where.items())
        else:
            where='1=1'
        sets=','.join('`{k}`={v}'.format(k=k,v=obj2mt(v)) for k,v in kwargs.items())
        sql="UPDATE {table} SET {sets} WHERE {where} ".format(table=table,sets=sets,where=where)
        cursor.execute(sql)
        return True
    
    def _remove(self,cursor,table,**kwargs):
        where=' AND '.join('`{k}`{v}'.format(k=k,v=self._get_where_value(v)) for k,v in kwargs.items()) or '1=1'
        sql="DELETE FROM {table} WHERE {where}".format(table=table,where=where)
        cursor.execute(sql)
        return True
    
    def _has_job(self,cursor,name):
        job=self._get(cursor,self._job_table,name=name)
        return job and True or False
    
    def _has_record(self,cursor,name):
        record=self._get(cursor,self._record_table,name=name)
        return record and True or False
        
    def _add_job(self,cursor,name,**kwargs):
        if self._has_job(cursor,name):
            return -1
        return self._add(cursor,self._job_table,name=name,**kwargs)
        
    def _update_job(self,cursor,name,**kwargs):
        if not self._has_job(cursor,name):
            return None
        return self._update(cursor,self._job_table,where=dict(name=name),**kwargs)
        
    def _remove_job(self,cursor,name):
        if not self._has_job(cursor,name):
            return None
        return self._remove(cursor,self._job_table,name=name)
    
    def _add_record(self,cursor,name,**kwargs):
        if self._has_record(cursor,name):
            return -1
        return self._add(cursor,self._record_table,name=name,**kwargs)
    
    def _add_log(self,cursor,name,**kwargs):
        return self._add(cursor,self._log_table,name=name,**kwargs)
    
    def _add_dependency(self,cursor,name,depend):
        return self._add(cursor,self._depend_table,name=name,dependency=depend,enable=1)
    
    def _add_depend(self,cursor,depend,name):
        depends=isinstance(depend,basestring) and depend.split(',') or depend
        values=map(lambda d:(name,d,1),depends)
        return self._add_many(cursor,self._depend_table,('name','dependency','enable'),values)
    
    def _remove_dependency(self,cursor,name,depend):
        return self._remove(cursor,self._depend_table,name=name,dependency=depend)
    
    def _remove_depend(self,cursor,depend,name=None):
        where=dict(dependency=depend)
        if name:
            where['name']=name
        return self._remove(cursor,self._depend_table,**where)
    
    def _remove_log(self,cursor,name,tx_time=None):
        where=dict(name=name)
        if tx_time is not None:
            where['tx_time']=tx_time
        return self._remove(cursor,self._log_table,**where)
    
    def _update_record(self,cursor,name,**kwargs):
        return self._update(cursor,self._record_table,where=dict(name=name),**kwargs)
    
    def _update_dependency(self,cursor,name,**kwargs):
        return self._update(cursor,self._depend_table,where=dict(name=name),**kwargs)
    
    def _update_depend(self,cursor,depend,**kwargs):
        return self._update(cursor,self._depend_table,where=dict(dependency=depend),**kwargs)
    
    def _remove_record(self,cursor,name):
        if not self._has_record(cursor,name):
            return None
        return self._remove(cursor,self._record_table,name=name)
    
    def _renew_record(self,cursor,name,**kwargs):
        self._remove(cursor,self._record_table,name=name)
        self._add(cursor,self._record_table,name=name,**kwargs)
        return True
    
    def _get_job(self,cursor,name):
        jobs=self._get(cursor,self._job_table,name=name)
        return jobs and jobs[0] or None
    
    def _get_jobs(self,cursor,enable=1,**kwargs):
        where=dict(enable=enable,**kwargs)
        rows=self._get(cursor,self._job_table,**where)
        jobs=dict()
        for row in rows:
            name=row.pop('name')
            jobs[name]=row
        return jobs
    
    def _get_job_records(self,cursor,enable=1,**kwargs):
        other=kwargs.pop('other','')
        job_fields=kwargs.pop('job_fields','')
        record_fields=kwargs.pop('record_fields','')
        fields=[]
        for field in (job_fields,record_fields):
            if field:
                fields.append(field)
        if not fields:
            fields='j.*,r.*'
        else:
            fields=','.join(fields)
        kwargs['enable']=enable
        where=' AND '.join("{k}{v}".format(k=k,v=self._get_where_value(v)) for k,v in kwargs.items())
        if other:
            where=where+' '+other
        sql="SELECT {fields} FROM {job_table} j LEFT JOIN {record_table} r ON j.name=r.name WHERE {where} ".format(fields=fields,where=where,job_table=self._job_table,record_table=self._record_table)
        cursor.execute(sql)
        rows=cursor.fetchall()
        return self._switch_rows(rows)
    
    def _switch_rows(self,rows):
        new_rows=[]
        for row in rows:
            new_row=dict((k,mt2obj(v)) for k,v in row.items())
            new_rows.append(new_row)
        return new_rows
    
    def _get_undone_jobs(self,cursor,tx_time=None):
        where=dict(job_fields='j.*',record_fields='r.host',enable=1,other="AND r.state='{state}'".format(state=JobState.RUNNING))
        if tx_time:
            where['tx_time']=tx_time
        rows=self._get_job_records(cursor,**where)
        jobs=[]
        for row in rows:
            rhost=row.pop('r.host')
            host=row.pop('host')
            row['host']=rhost or host
            jobs.append(row)
        return jobs
    
    def _get_redo_jobs(self,cursor,tx_time=None,state=None,**kwargs):
        if state is None:
            other="AND state!='{state}' AND state!='' AND state IS NOT NULL ".format(state=JobState.DONE)
        else:
            other="AND state='{state}' ".format(state=state)
	for key,value in kwargs.items():
            if key!='timer' and value is not None:
                if value.find('*')>-1:
                    other+="AND j.`{key}` LIKE '{value}' ".format(key=key,value=value.replace('*','%'))
                else:
                    other+="AND j.`{key}`='{value}' ".format(key=key,value=value)
        where=dict(job_fields='j.*',record_fields='tx_time',enable=1,other=other)
        if tx_time:
            where['tx_time']=tx_time
        return self._get_job_records(cursor,**where)
    
    def _get_periodic_jobs(self,cursor):
        where=dict(job_fields='j.*',record_fields='state,tx_time',enable=1,other="AND timer IS NOT NULL AND timer!=''")
        return self._get_job_records(cursor,**where)
    
    def _get_full_jobs(self,cursor):
        rows=self._get_job_records(cursor,enable=1,job_fields='j.*',record_fields='state,tx_time')
        depends=self._get_depends(cursor)
        jobs=dict()
        for row in rows:
            name=row.pop('name')
            row['depends']=depends.get(name,{})
            jobs[name]=row
        return jobs
    
    def _get_records(self,cursor,**kwargs):
        rows=self._get(cursor,self._record_table,**kwargs)
        records=dict()
        for row in rows:
            name=row.pop('name')
            records[name]=row
        return records
    
    def _get_record(self,cursor,name):
        records=self._get(cursor,self._record_table,name=name)
        return records and records[0] or None
    
    def _get_log(self,cursor,name,tx_time=None):
        where=dict(name=name)
        if tx_time is not None:
            where['tx_time']=tx_time
        logs=self._get(cursor,self._log_table,**where)
        return logs
    
    def _get_logs(self,cursor,**kwargs):
        rows=self._get(cursor,self._log_table,**kwargs)
        logs=dict()
        for row in rows:
            name=row.pop('name')
            logs.setdefault(name,[]).append(row)
        return logs
    
    def _get_depend(self,cursor,name,enable=1):
        where=dict(name=name,enable=enable)
        rows=self._get(cursor,self._depend_table,**where)
        if not rows:
            return []
        depends=[]
        for row in rows:
            depends.append(row['dependency'])
        return depends
    
    def _get_depends(self,cursor,enable=1):
        rows=self._get(cursor,self._depend_table,enable=enable)
        if not rows:
            return dict()
        depends=dict()
        for row in rows:
            name=row.pop('name')
            dependency=row.pop('dependency')
            if name in depends:
                depends[name][dependency]=row
            else:
                depends[name]={dependency:row}
        return depends
    
    def _has_user(self,cursor,name):
        user=self._get(cursor,self._user_table,name=name)
        return user and True or False
    
    def _get_user(self,cursor,name):
        users=self._get(cursor,self._user_table,name=name)
        return users and users[0] or None
    
    def _get_users(self,cursor,enable=1,**kwargs):
        where=dict(enable=enable,**kwargs)
        rows=self._get(cursor,self._user_table,**where)
        users=dict()
        for row in rows:
            name=row.pop('name')
            users[name]=row
        return users
    
    def _add_user(self,cursor,name,**kwargs):
        if self._has_user(cursor,name):
            return -1
        return self._add(cursor,self._user_table,name=name,**kwargs)
    
    def _update_user(self,cursor,name,**kwargs):
        if not self._has_user(cursor,name):
            return None
        return self._update(cursor,self._user_table,where=dict(name=name),**kwargs)
    
    def _remove_user(self,cursor,name):
        if not self._has_user(cursor,name):
            return None
        return self._remove(cursor,self._user_table,name=name)
    
    
