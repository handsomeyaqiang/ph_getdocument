#!/usr/bin/env python
#-*- coding:utf-8 -*-
import copy
from data.scheduler.utils import do_sql as execute_sql
from data.scheduler.conf import conf

dbc=conf.sched_dbc
def do_sql(sql,**kwargs):
    try:
        return execute_sql(sql,dbc=dbc,**kwargs)
    except Exception,error:
        return error

def First_class_permission_check(menus, user,  **kwargs):
    c_menus = copy.deepcopy(menus)
    sql_str = "select *  from first_permission where userName = '%s'" % user
    res = do_sql(sql_str)
    if res:
        menu_list =  res[0][2].split(',')
        menu_list = [int(m) for m in menu_list if m]
        for i in c_menus.keys():
            if i not in menu_list:
                c_menus.pop(i)
    return c_menus

def Second_class_permission_check(c_menus, user, **kwargs):
    first_per = c_menus.keys()
    sql_str = "select * from second_permission where userName = '%s' and first_permission = %d"
    for i in first_per:
        res = do_sql(sql_str % (user, i))
        if res:
            menu_list = res[0][3].split(',')
            menu_list = [int(m) for m in menu_list if m]
            for j in c_menus[i][1].keys():
                if j not in menu_list:
                    c_menus[i][1].pop(j)
    return c_menus

def Third_class_permission_check(opers, user, first_menu_id, menu_id, **kwargs):
    c_opers = copy.deepcopy(opers)
    if int(first_menu_id) == 1 and int(menu_id) == 6:
        sql_str = ("select * from third_permission where userName='%s' and first_permission=%d "
                  "and second_permission=%d")
        res = do_sql(sql_str %(user, int(first_menu_id), int(menu_id)))
        if res:
            menu_list = res[0][4].split(',')
            menu_list = [int(m) for m in menu_list if m]
            for i in c_opers.keys():
                if i not in menu_list:
                    c_opers.pop(i)
    if int(first_menu_id) ==1 and int(menu_id) ==5:
        sql_str = ("select * from third_permission where userName='%s' and first_permission=%d "
                  "and second_permission=%d")
        res = do_sql(sql_str %(user, int(first_menu_id), int(menu_id)))
        if res:
            menu_list = res[0][4].split(',')
            menu_list = [int(m) for m in menu_list if m]
            for i in c_opers[0].keys():
                if i not in menu_list:
                    c_opers[0].pop(i)
            for j in c_opers[1].keys():
                if j not in menu_list:
                    c_opers[1].pop(j)
    return c_opers
    

