#!/usr/bin/env python
import sys

job="""
****************************************************************************
Job: Python,Shell,Java,Perl,...,etc, Script or Command's Executor
****************************************************************************
Job: Job's describer
    attrs: name(unique),cmd,timer,host,priority,retries,delay,zipper,man,desc
    out styles: to_string,to_list,to_dict,to_object
JobCrontab: Job's Timer
    like crontab styles, eg: hourly: 0 */1 * * *
    triggered by the scheduler, when the timer is to the time
JobDependency: Job's Dependency
    attrs: name,dependency,state
    triggered by the scheduler, when the depened jobs are all DONE
JobExecutor: Job's Launcher
    job's really executor, operated by the worker
JobRecord: Executor's Recorder
    attrs: name,state,cmd,start_time,end_time,return_code,retried,host,path
    record the job executor's information, and notify to the master by the worker
JobVar: Job's Param Vars
    plain vars: home,localhost,minute,hour,date,month,job's attrs
    tx_time vars: txminute,txhour,txdate,txmonth
""".lstrip()

master="""
****************************************************************************
Master: Global Controller
****************************************************************************
Master controls scheduler's activities,
    and responses the results to workers or askers;
Master receives heartbeats from workers,
    and responses scheduled jobs to the specified worker;
Master checks workers's heartbeats,
    and transfers scheduled jobs to the idle or live workers,
    if it doesn't receive any worker's heartbeat;
Master receives requests from askers,
    and tells the scheduler to schedule,
    and responses the scheduled to the asker.
""".lstrip()

worker="""
****************************************************************************
Worker: Job Executor
****************************************************************************
Worker sends heartbeat to the master, periodically,
    and recevies the commands from it;
Worker executes the specified commands(do or kill job),
    and notifies executed's records to the master.
""".lstrip()

asker="""
****************************************************************************
Asker: Command Requestor
****************************************************************************
Asker sends many request commands:
    job's add,remove,get or list,update,kill;
    job's record add,remove,get or list,update;
    other commands, show dead or busy workers, ... ,etc
and receives the response from the master.(RPC)
""".lstrip()

scheduler="""
****************************************************************************
Scheduler: Job Scheduler
****************************************************************************
Scheduler sends the deadline jobs to the scheduled queue, periodically,
    if the job's timer is to the time or the depended jobs are DONE;
Scheduler is a really operationer,
    it does the operations: add,remove,get or list,update,kill, ... ,etc
Scheduler receives commands from the master, and then make schedule,
    finally submits the scheduled to it.
""".lstrip()

usage="""
****************************************************************************
python {script} COMMANDS
****************************************************************************
COMMANDS:

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
master -start|stop|restart          #start|stop|restart master
worker -start|stop|restart          #start|stop|restart worker
   web -start|stop|restart          #start|stop|restart web server
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   job -get      name               #get job info by name
   job -do       name <key=value>   #do job immediately, set key=value to change some attrs
   job -loop     name [start] [stop]#loop to do job from start_txtime to stop_txtime
   job -batch    names [tx_time]    #batch to do [host] [tx_time]'s jobs sequently
   job -redo     <key=value>        #redo undone jobs, filter by setting key=value
   job -rerun    names              #rerun jobs, including dependency jobs
   job -add      name <key=value>   #add job, needed keys: name,cmd,[timer],...,etc
   job -kill     name               #kill job by name
   job -list     <key=value>        #list job, filter by setting key=value
   job -update   name <key=value>   #update job's attrs by setting key=value
   job -remove   name               #remove job by name
   job -transfer name host          #transfer job to other worker
record -get      name               #get job's record by name
record -list     <key=value>        #list job's record, filter by setting key=value
record -update   name <key=value>   #update job's record by setting key=value
record -remove   name               #remove job's record by name
depend -get      name               #get job's dependencies
depend -add      depend name        #add depend to name's job
depend -remove   depend [name]      #remove depend [from name's job]
   log -get      name [tx_time]     #get job's log, filter by tx_time
   log -remove   name [tx_time]     #remove job's log, filter by tx_time
  user -get      name               #get user's info by name
  user -add      name <key=value>   #add user, needed keys: mobile,email,desc
  user -update   name <key=value>   #update user's info by setting key=value
  user -remove   name               #remove user by name
  file -dist     name               #dist job to all workers
  file -tail     name               #tail master|worker|job's log
  file -cat      name               #cat master|worker|job's log
  file -remove   name [tx_time]     #remove master|worker|job's [tx_time] log
 intro -|master|worker|scheduler|job#introduce system, if '-', introduce all
****************************************************************************
""".strip().format(script=sys.argv[0])

intro=job+master+worker+asker+scheduler

def readme():
    print intro
    print usage
    
if __name__ == '__main__':
    readme()
    
