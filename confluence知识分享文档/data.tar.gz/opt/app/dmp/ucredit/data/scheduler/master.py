#!/usr/bin/env python
#-*- coding:utf-8 -*-
from socket import socket,AF_INET,SOCK_STREAM,SOL_SOCKET,SO_REUSEADDR,timeout as TimeoutError,error as SocketError
import time
import sys
from threads import ThreadPool,MsgQueue,Lock,spawn
from logger import Logger
from scheduler import Scheduler
from utils import ignore_errors,get_pid,store_pid,kill_pid,param2str,send,recv,log,get_value
from job import JobInfo

IGNORED_ERRORS=ignore_errors()

class HeartBeat(object):
    
    def __init__(self,workers=None,worker_groups=None,timeout=60):
        self._workers=workers or []
        self._worker_groups=worker_groups or dict()
        self._timeout=timeout
        
    def set_workers(self,workers):
        self._workers=workers
        
    def set_worker_groups(self,worker_groups):
        self._worker_groups=worker_groups
        
    def set_timeout(self,timeout):
        self._timeout=timeout
        
    def setup(self):
        self._heartbeats=dict((host,(time.time(),-1)) for host in self._workers)
        self._lock=Lock()
        
    def get_dead_workers(self):
        limit=time.time()-self._timeout
        dead_workers=[host for host,(start,is_busy) in self._heartbeats.items() if start<limit or is_busy==-1]
        return dead_workers
    
    def get_live_workers(self):
        limit=time.time()-self._timeout
        live_workers=[host for host,(start,is_busy) in self._heartbeats.items() if start>=limit and is_busy!=-1]
        return live_workers
    
    def get_busy_workers(self):
        limit=time.time()-self._timeout
        busy_workers=[host for host,(start,is_busy) in self._heartbeats.items() if start>=limit and is_busy is True]
        return busy_workers
    
    def get_idle_workers(self,host=None):
        limit=time.time()-self._timeout
        idle_workers=[_host for _host,(start,is_busy) in self._heartbeats.items() if start>=limit and is_busy is False]
        if host:
            worker_group=self._worker_groups.get(host,set(idle_workers))
            idle_workers=[_host for _host in idle_workers if _host in worker_group]
        return idle_workers
    
    def record_heartbeat(self,host,is_busy):
        try:
            self._lock.acquire()
            self._heartbeats[host]=(time.time(),is_busy)
        finally:
            self._lock.release()
            
    def add_worker(self,host):
        self.record_heartbeat(host,False)
        return True
    
    def remove_worker(self,host):
        try:
            self._lock.acquire()
            value=self._heartbeats.pop(host,None)
        finally:
            self._lock.release()
        return value and True or False
    
    def _get_transfer_jobs(self,jobs):
        return [job for job in jobs if job.get('transfer')]
    
    def _get_untransfer_jobs(self,jobs):
        return [job for job in jobs if not job.get('transfer')]
        
    def heartbeat(self,host,scheduler,is_busy=False):
        self.record_heartbeat(host,is_busy)
        idle_workers=self.get_idle_workers(host)
        if not idle_workers:
            return []
        dead_workers=self.get_dead_workers()
        busy_workers=self.get_busy_workers()
        if host in dead_workers:
            jobs=scheduler.get_scheduled_jobs(host)
            undone_jobs=scheduler.get_undone_jobs(host)
            scheduler.transfer_jobs(self._get_transfer_jobs(jobs+undone_jobs),idle_workers)
            return []
        elif is_busy:
            jobs=scheduler.get_scheduled_jobs(host)
            scheduler.transfer_jobs(self._get_transfer_jobs(jobs),idle_workers)
            return self._get_untransfer_jobs(jobs)
        if busy_workers or dead_workers:
            for worker in busy_workers+dead_workers:
                idle_workers=self.get_idle_workers(worker)
		if not idle_workers:
		    continue
		jobs=scheduler.get_scheduled_jobs(worker)
                scheduler.transfer_jobs(self._get_transfer_jobs(jobs),idle_workers)
        jobs=scheduler.get_scheduled_jobs(host)
        return jobs
    
class Master(object):
    
    def __init__(self,conf=None):
        self._conf=conf
        
    def set_conf(self,conf):
        self._conf=conf
    
    def _setup_var(self):
        self._host=get_value(self._conf,'master_host','localhost')
        self._port=get_value(self._conf,'master_port',8090)
        self._address=(self._host,self._port)
        self._workers=get_value(self._conf,'workers',[])
        self._worker_groups=get_value(self._conf,'worker_groups',{})
        self._timeout=get_value(self._conf,'connection_timeout',60)
        self._max_connections=get_value(self._conf,'max_connections',20)
        self._log_path=get_value(self._conf,'master_log_path','.')
        self._pid_path=get_value(self._conf,'pid_path','.')
    
    def get_pid_file(self):
        return '{path}/master.pid'.format(path=self._pid_path)
        
    def _setup_master(self):
        self._sock=None
        pid_file=self.get_pid_file()
        pid=get_pid(pid_file)
        if pid is not None:
            log("Master{addr} is already started".format(addr=self._address),flush=True)
            sys.exit(2)
        store_pid(pid_file)
        self._logger=Logger(name='master',path=self._log_path)
        self._scheduler=Scheduler(logger=self._logger,conf=self._conf)
        self._connect_pool=ThreadPool(self._max_connections,logger=self._logger)
        self._notify_queue=MsgQueue(logger=self._logger)
        self._setup_heartbeat()
        
    def _start_server(self):
        self._server=spawn(self._serve_forever,thread_name='Master')
        
    def _setup_heartbeat(self):
        self._heartbeat=HeartBeat(self._workers,self._worker_groups,self._timeout)
        self._heartbeat.setup()
        
    def log(self,msg,**kwargs):
        log(msg,logger=self._logger,**kwargs)
        
    def get_scheduler(self):
        return self._scheduler
    
    def _start_master(self):
        try:
            self._sock=socket(AF_INET,SOCK_STREAM)
            self._sock.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
            self._sock.bind(self._address)
            self._sock.listen(self._max_connections)
            self._start_server()
            log("Master{addr} is started".format(addr=self._address),flush=True)
        except Exception,error:
            log("Master{addr} start failed, because {error}".format(addr=self._address,error=error),flush=True)
            sys.exit(1)
            
    def _serve(self):
        try:
            sock,address=self._sock.accept()
            self._connect_pool.submit(self.handle,sock,address)
        except TimeoutError:
            self.log("Serve error: TimeoutError")
        except KeyboardInterrupt:
            self.log("Serve error: KeyboardInterrupt")
            return False
        except SocketError,e:
            self.log("Serve error: {error}".format(error=e))
            if e.args[0] not in IGNORED_ERRORS:
                return False
        except Exception,error:
            self.log("Serve error: {error}".format(error=error))
            return False
        return True
    
    def _serve_forever(self):
        while True:
            serving=self._serve()
            if not serving:
                break
            
    def _check_master(self):
        if hasattr(self,'_server') and self._server.isAlive():
            return
        if self._sock:
            self._sock.close()
            self._sock=None
        self.log('Master{addr} is dead, begin to restart it'.format(addr=self._address))
        self._start_master()
        
    def _check_scheduler(self):
        if not self._scheduler.is_alive:
            self.log('Scheduler is dead, begin to restart it')
            self._start_scheduler()
            
    def _check_notify_queue(self):
        notify_count=self._notify_queue.jobs
        if notify_count>0:
            self.log('NotifyQueue: notify_count={count}'.format(count=notify_count))
            if not self._notify_queue.is_alive:
                self.log("NotifyQueue's worker is dead, begin to spawn a new worker")
                self._notify_queue.spawn()
                
    def _start_deamon(self):
        while True:
            self._check_master()
            self._check_scheduler()
            self._check_notify_queue()
            self.wait(120)
            
    def _start_scheduler(self):
        self._scheduler.start()
        
    def start(self):
        self._setup_var()
        self._setup_master()
        self._start_master()
        self._start_scheduler()
        self._start_deamon()
        
    def send(self,sock,data):
        send(sock,data,logger=self._logger)
        
    def recv(self,sock):
        return recv(sock,logger=self._logger)
    
    def wait(self,seconds):
        time.sleep(seconds)
    
    def handle(self,sock,address):
        data=self.recv(sock)
        if not data:
            return
        function,args,kwargs=data
        function=function.lower()
        if function=='heartbeat':
            try:
                self.handle_heartbeat(sock,address,**kwargs)
            except Exception,error:
                self.log("Handle heartbeat error: {error}".format(error=error))
        elif function=='notify':
            try:
                self.handle_notify(sock,address,**kwargs)
            except Exception,error:
                self.log("Handle notify error: {error}".format(error=error))
        else:
            try:
                self.handle_request(sock,address,function,*args,**kwargs)
            except Exception,error:
                self.log("Handle request error: {error}".format(error=error))
                self.send(sock,error)
        sock.close()
        
    def handle_heartbeat(self,sock,address,is_busy=False):
        self.log("Get from worker{addr}'s heartbeat: is_busy={is_busy}".format(addr=address,is_busy=is_busy))
        jobs=self._heartbeat.heartbeat(address[0],self._scheduler,is_busy=is_busy)
        self.send(sock,jobs)
        self.log("Send to worker{addr}'s jobs: {jobs} ".format(addr=address,jobs=jobs))
        
    def _handle_notify(self,**record):
        try:
            return self._scheduler.handle_notify(**record)
        except Exception,error:
            self.log("Handle notify error: {error}".format(error=error))
            
    def handle_notify(self,sock,address,**record):
        params=param2str(**record)
        self.log("Get from worker{addr}'s notify: record({params})".format(params=params,addr=address))
        self._notify_queue.submit(self._handle_notify,**record)
        self.send(sock,True)
        self.log("Send to worker{addr}'s notify: {notify} ".format(addr=address,notify=True))
        
    def handle_request(self,sock,address,function,*args,**kwargs):
        out_style=kwargs.pop('out_style','to_string')
        params=param2str(*args,**kwargs)
        self.log("Get from worker{addr}'s request: {oper}({params})".format(oper=function,params=params,addr=address))
        if hasattr(self._scheduler,function):
            result=getattr(self._scheduler,function)(*args,**kwargs)
            if isinstance(result,JobInfo):
                result=getattr(result,out_style)()
            elif isinstance(result,(list,tuple)):
                result=[isinstance(res,JobInfo) and getattr(res,out_style)() or res for res in result]
            self.send(sock,result)
            self.log("Send to worker{addr}'s response: {result} ".format(result=result,addr=address))
        elif hasattr(self._heartbeat,function):
            result=getattr(self._heartbeat,function)(*args,**kwargs)
            self.send(sock,result)
            self.log("Send to worker{addr}'s response: {result} ".format(result=result,addr=address))
        else:
            result="No such operation: {oper}".format(oper=function)
            self.send(sock,result)
            self.log(result)
            
    def stop(self):
        self._setup_var()
        pid_file=self.get_pid_file()
        state=kill_pid(pid_file)
        if state==0:
            log('Master{addr} is stopped'.format(addr=self._address),flush=True)
        elif state==1:
            log('Master{addr} stop failed'.format(addr=self._address),flush=True)
        else:
            log('Master{addr} is not started'.format(addr=self._address),flush=True)
            
