#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys
import os
from datetime import datetime

class Logger(object):
    
    def __init__(self,name=None,path=None,opened=True):
        self._name=name
        self._path=path
        self.out=None
        if opened:
            self.open()
            
    def open(self):
        if self.out:
            return self.out
        if self._path:
            log_file='{path}/{name}.log'.format(path=self._path,name=self._name)
            if not os.path.exists(self._path):
                os.mkdir(self._path)
	    if os.path.exists(log_file):
                new_log='{log}.{time}'.format(log=log_file,time=str(datetime.now()).replace('-','').replace(' ','.'))
                os.rename(log_file,new_log)
            self.out=open(log_file,'w')
        else:
            self.out=sys.stdout
        return self.out
    
    def log(self,msg,has_time=True,line_sep='\n',flush=False):
        line=''
        if has_time:
            now=datetime.now()
            line='[{now}] '.format(now=now)
	line+='{msg}'.format(msg=msg)
        if line_sep:
            line+=line_sep
        self.out.write(line)
        if flush:
            self.out.flush()
            
    def close(self):
        if self.out:
            if self._path:
		self.out.flush()
                self.out.close()
                
