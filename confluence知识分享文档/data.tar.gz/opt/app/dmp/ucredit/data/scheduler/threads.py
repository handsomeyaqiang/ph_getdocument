#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys
from threading import Thread,Lock,currentThread,Event
from time import time,sleep
from Queue import Queue,LifoQueue,Empty
from heapq import heappush,heappop

def spawn(func,*args,**kwargs):
    name=kwargs.pop('thread_name',func.__name__)
    daemon=kwargs.pop('thread_daemon',True)
    t=Thread(target=func,args=args,kwargs=kwargs,name=name)
    t.setDaemon(daemon)
    t.start()
    return t

def log(msg,logger=None,flush=False,**kwargs):
    if logger:
        logger.log(msg,flush=flush,**kwargs)
    else:
        sys.stdout.write('{msg}\n'.format(msg=msg))
        if flush:
            sys.stdout.flush()
            
class PriorityQueue(Queue):
    
    def _init(self,maxsize):
        self.queue=[]
        self._index=0
        
    def _qsize(self,len=len):
        return len(self.queue)
    
    def _put(self,item):
        if isinstance(item,tuple) and len(item)==2:
            item,priority=item
        elif hasattr(item,'priority'):
            priority=item.priority
        else:
            priority=0
        heappush(self.queue,(-priority,self._index,item))
        self._index+=1
        
    def _get(self):
        return heappop(self.queue)[-1]

class Worker(object):
    
    def __init__(self,func,args=(),kwargs={},timeout=None,name=None):
        self._func=func
        self._args=args
        self._kwargs=kwargs
        self._timeout=timeout
        self._name=name or self.__class__.__name__
        self._stopped=False
        self._start_time=0
        self._master=None
        self._worker=None
        self._result=None
        self._error=None
        self._is_done=False
        
    def start(self):
        self._master=spawn(self.run,thread_name=self._name,thread_daemon=False)
        
    def do_job(self):
        try:
            self._result=self._func(*self._args,**self._kwargs)
        except Exception as error:
            self._error=error
        finally:
            self._is_done=True
    
    def on_start(self):
        self._start_time=time()
        self._worker=spawn(self.do_job)
        
    def run(self):
        self.on_start()
        while not self.is_stopped():
            if self.is_done():
                self.on_done()
                break
            if self.is_timeout():
                self.on_timeout()
                break
        self.on_stop()
        
    def is_timeout(self):
        if not self._timeout:
            return False
        if time()-self._start_time>=self._timeout:
            return True
        return False
    
    def on_timeout(self):
        self.kill()
        
    def wait(self,timeout=None):
        if self._worker:
            self._worker.join(timeout)
        if self._master:
            self._master.join(timeout)
            
    def is_done(self):
        return self._is_done
    
    def on_done(self):
        pass
    
    def is_stopped(self):
        return self._stopped
    
    def kill(self):
        if self._worker:
            self._worker.join(0.5)
            
    def on_stop(self):
        pass
    
    def stop(self):
        self._stopped=True
        if not self.is_done():
            self.kill()
            
class ThreadPool(object):
    
    def __init__(self,max_workers=20,queue=Queue,keep_alive=5,out=False,logger=None):
        self._max_workers=max_workers
        self._keep_alive=keep_alive
        self._out=out
        self._logger=logger
        self._inq=queue()
        self._outq=Queue()
        self._workers=[]
        self._lock=Lock()
        self._shutdown=False
        self._terminator=object()
        
    def log(self,msg,**kwargs):
        log(msg,logger=self._logger,**kwargs)
        
    @property
    def is_alive(self):
        for worker in self._workers:
            if worker.isAlive():
                return True
        else:
            return False
        
    @property
    def jobs(self):
        return self._inq.qsize()
    
    @property
    def workers(self):
        return len(self._workers)
    
    def poll(self):
        if self.jobs>0:
            if not self.is_alive:
                self.spawn()
                
    def spawn(self):
        try:
            self._lock.acquire()
            name='worker{idx}'.format(idx=self.workers+1)
            worker=spawn(self._do_jobs,thread_name=name)
            self._workers.append(worker)
        except Exception,error:
            self.log("Spawn worker error: {error}".format(error=error))
            raise error
        finally:
            self._lock.release()
            
    @property
    def is_busy(self):
        return len(self._workers)>=self._max_workers
    
    def do_job(self,job):
        func,args,kwargs=job
        try:
            result=func(*args,**kwargs)
        except Exception as error:
            self.log("Do job error: {error}".format(error=error))
            result=error
        finally:
            if self._out:
                self._outq.put(result)
            
    def _do_jobs(self):
        if self._keep_alive<=0:
            block=False
            timeout=None
        else:
            block=True
            timeout=self._keep_alive
        while True:
            try:
                job=self._inq.get(block=block,timeout=timeout)
            except Empty:
                break
            if self._shutdown:
                break
            if job is self._terminator:
                break
            self.do_job(job)
        try:
            self._lock.acquire()
            self._workers.remove(currentThread())
        except:
            pass
        finally:
            self._lock.release()
            
    def submit(self,func,*args,**kwargs):
        if self._shutdown:
            error='Cannot sumbit new job after shutdown'
            self.log("Submit job error: {error}".format(error=error))
            raise RuntimeError(error)
        self._inq.put((func,args,kwargs))
        if not self.is_busy:
            self.spawn()
        
    def wait(self):
        self._lock.acquire()
        workers=tuple(self._workers)
        self._lock.release()
        for worker in workers:
            worker.join()
            
    def outs(self):
        while True:
            try:
                job=self._outq.get(block=False)
            except Empty:
                break
            yield job
            
    def shutdown(self,wait=True):
        if self._shutdown:
            return
        self._lock.acquire()
        for _ in self._workers:
            self._inq.put(self._terminator)
        self._lock.release()
        if wait:
            self.wait()
            
class MsgQueue(ThreadPool):
    
    def __init__(self,queue=Queue,keep_alive=5,logger=None):
        ThreadPool.__init__(self,max_workers=1,queue=queue,keep_alive=keep_alive,logger=logger)
        
class Looper(object):
    
    def __init__(self,func,args=(),kwargs={},name=None,callback=lambda result:result,daemon=True):
        self._func=func
        self._args=args
        self._kwargs=kwargs
        self._name=name or self.__class__.__name__
        self._daemon=daemon
        self._callback=callback
        self._stopped=False
        self._worker=None
        self._delay=0
        
    def start(self):
        self._worker=spawn(self.loop,thread_name=self._name,thread_daemon=self._daemon)
        
    @property
    def is_alive(self):
        return self._worker and self._worker.isAlive()
    
    def set_delay(self,seconds):
        self._delay=seconds
        
    def wait(self):
        if self._delay and not self._stopped:
            sleep(self._delay)
            
    def loop(self):
        while not self._stopped:
            result=self._func(*self._args,**self._kwargs)
            self._callback(result)
            self.wait()
        self.on_stop()
        
    def on_stop(self):
        pass
    
    def stop(self):
        if self._stopped:
            return
        self._stopped=True
        
        
class ActorExit(Exception):
    pass

class Actor(object):
    
    def __init__(self):
        self._terminated=Event()
        self._queue=Queue()
        
    def send(self,msg):
        self._queue.put(msg)
        
    def recv(self):
        msg=self._queue.get()
        if msg is ActorExit:
            raise ActorExit
        return msg
    
    def close(self):
        self.send(ActorExit)
        
    def start(self):
        return spawn(self._bootstrap)
    
    def _bootstrap(self):
        try:
            self.run()
        except ActorExit:
            pass
        finally:
            self._terminated.set()
    
    def join(self):
        self._terminated.wait()
        
    def run(self):
        while True:
            msg=self.recv()
            self.handle(msg)
            
    def handle(self,msg):
        pass
    
class PrintActor(Actor):
    
    def handle(self,msg):
        print msg
        
class TaggedActor(Actor):
    
    def handle(self,msg):
        tag,args,kwargs=msg
        getattr(self,'do_' % (tag))(*args,**kwargs)
        
    def do_tag(self,*args,**kwargs):
        pass
    
class WorkResult(object):
    
    def __init__(self):
        self._event=Event()
        self._result=None
        
    def set_result(self,value):
        self._result=value
        self._event.set()
        
    def result(self):
        self._event.wait()
        return self._result
    
class WorkActor(Actor):
    
    def submit(self,func,*args,**kwargs):
        r=WorkResult()
        self.send((func,args,kwargs,r))
        return r
    
    def handle(self,msg):
        func,args,kwargs,r=msg
        result=func(*args,**kwargs)
        r.set_result(result)
        
        
