#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os
user_home=os.environ['DMP_HOME']
LOGS_PATH=user_home+'/sched/logs'
pid_path=user_home+'/sched/pid'
job_path=user_home+'/sched/jobs'
master_log_path=LOGS_PATH
worker_log_path=LOGS_PATH
web_log_path=LOGS_PATH
sched_path=user_home+'/ucredit/data/scheduler'

#单个worker运行最大连接数
max_connections=20
#单个worker运行最大任务数
max_jobs=10
#worker与master心跳传输间隔
heartbeat_period=20
#worker与master心跳传输超时
connection_timeout=60
#master地址及监听端口
master_host='172.16.2.102'
master_port=8090
#web管理界面地址及监听端口
web_host='172.16.2.104'
web_port=8080

#web管理界面地址及监听端口
worker_group1=[
    '172.16.2.102',
    '172.16.2.104',
    '172.16.2.107'
]

worker_group2=[
    '172.16.2.102',
    '172.16.2.104',
    '172.16.2.104'
]

def get_worker_groups():
    import re
    pat=re.compile(r'^worker_group\d+$')
    groups=dict()
    for k,v in globals().items():
        if pat.match(k):
            v=set(v)
            for w in v:
                groups[w]=v
    return groups

worker_groups=get_worker_groups()
workers=[wg[0] for wg in sorted(worker_groups.items())]

check_hadoop=False
hadoop_user='hadoop.hadoop'
hadoop_url=''
sms_url=''
#调度底层表及连接配置
sched_job='sched_job'
sched_job_record='sched_job_record'
sched_job_dependency='sched_job_dependency'
sched_job_log='sched_job_log'
sched_job_user='sched_job_user'
#调度连接配置
sched_dbc=dict(host='172.16.2.103',port=3306,user='diaodu',passwd='zjKSt0QQrEIMsjm',db='db_datamgrcfg')

