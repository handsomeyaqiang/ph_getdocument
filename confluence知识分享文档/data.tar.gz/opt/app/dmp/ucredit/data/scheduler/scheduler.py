#!/usr/bin/env python
#-*- coding:utf-8 -*-
from threads import spawn,Queue,Empty
from time import time,sleep
from datetime import datetime,timedelta
from job import Job,JobVar,JobRecord,JobState
from store import TableStore
from utils import send_sms,get_value
from copy import deepcopy
from sendmail import send_email


class Scheduler(object):
    
    def __init__(self,logger=None,conf=None,store_cls=TableStore):
        self._conf=conf
        self._job_store=store_cls(logger,conf)
        self._scheduled_jobs=dict()
        self._rerun_jobs=set()
        self._wait_jobs=dict()
        self._timer=None
        self._stopped=False
        
    def __getattr__(self,attr):
        if attr not in self.__dict__:
            value=getattr(self._job_store,attr)
            setattr(self,attr,value)
        return getattr(self,attr)
    
    @property
    def is_alive(self):
        return self._timer and self._timer.isAlive()
    
    def get_job(self,name):
        job=self._job_store.get_job(name)
        if job is None:
            return None
        return Job(**job)
    
    def get_record(self,name):
        record=self._job_store.get_record(name)
        if record is None:
            return None
        return JobRecord(**record)
    
    def _get_mobiles(self,name):
        users=self._job_store.get_users()
        mobiles=[]
        for _name in users:
            user=users[_name]
            mobile=user['mobile']
            if name==_name:
                if mobile not in mobiles:
                    mobiles.append(mobile)
            if user['desc']=='admin':
                if mobile not in mobiles:
                    mobiles.append(mobile)
        mobiles = list(set(mobiles))
        return mobiles
    
    def _get_emails(self, name):
        users = self._job_store.get_users()
        emails = list()
        for _name, _item  in users.items():
            if _name == name:
                emails.append(_item['email'])
            if _item['desc'] == 'admin':
                emails.append(_item['email'])
        return emails

    def handle_notify(self,**record):
        name=record.pop('name')
        end=record.pop('end',False)
        self._job_store.update_record(name,**record)
        if not end:
            return
        self._job_store.add_log(name,**record)
        state=record.get('state')
        tx_time=record.get('tx_time')
        if state==JobState.DONE:
            self._depend_on_end(name,state=state,tx_time=tx_time)
        else:
            job=self.get_job(name)
            if job is None:
                return
            job.state=state
            job.tx_time=tx_time
            self._alert_job(job)
        self._on_callback(name,**record)
        
    def _on_callback(self,name,**record):
        if name in self._rerun_jobs:
            self._rerun_jobs.remove(name)
            
    def _alert_job(self,job):
        emails = self._get_emails(job.man)
        mobiles=self._get_mobiles(job.man)
        logger=self._job_store.get_logger()
        sms_url=get_value(self._conf,'sms_url')
        for mobile in mobiles:
            if sms_url:
                send_sms(job,mobile,logger=logger)
            else:
                send_sms(job,mobile,logger=logger)
        if emails:
            send_email(emails, job)
                
    def setup_jobs(self):
        jobs=dict()
        rows=self._job_store.get_full_jobs()
        for name in rows:
            row=deepcopy(rows.get(name))
            depends=row.pop('depends',{})
            last_state=row.pop('state',None)
            last_txtime=row.pop('tx_time',None)
            job=Job(name=name,**row)
            job.setup()
            if row.get('timer'):
		try:
                    job.setup_crontab(state=last_state,tx_time=last_txtime)
                except Exception, error:
                    self._job_store.log("setup jobs error: {error}".format(error=error))
            if depends:
                if name in self._rerun_jobs:
                    job.timer=None
                job.setup_dependency(state=last_state,tx_time=last_txtime)
                for dependency in depends:
                    dep_row=rows.get(dependency,{})
                    if not dep_row:
                        continue
                    dep_row=deepcopy(dep_row)
                    dep_row.pop('depends',{})
                    dep_state=dep_row.pop('state',None)
                    dep_state=depends[dependency].get('state') or dep_state
                    dep_txtime=dep_row.pop('tx_time',None)
                    dep_job=Job(name=dependency,**dep_row)
                    job.dependency.add(dep_job,state=dep_state,tx_time=dep_txtime)
            jobs[name]=job
        return jobs
    
    def list_job(self,enable=1,**kwargs):
        jobs=[]
        _jobs=self._job_store.get_jobs(enable=enable,**kwargs)
        for name in _jobs:
            _job=_jobs.get(name)
            job=Job(name=name,**_job)
            jobs.append(job)
        return jobs
    
    def list_record(self,**kwargs):
        records=[]
        _records=self._job_store.get_records(**kwargs)
        for name in _records:
            _record=_records.get(name)
            record=JobRecord(name=name,**_record)
            records.append(record)
        return records
    
    def _do_schedule(self,job,host=None):
        host=host or job.host
        try:
            self._job_store._lock.acquire()
            self._scheduled_jobs.setdefault(host,Queue())
            self._scheduled_jobs[host].put(job)
        finally:
            self._job_store._lock.release()
        self._job_store.log("Schedule job: {job}".format(job=job))
        return True
    
    def _batch_schedule(self,jobs,host=None):
        if not jobs:
            return False
        host=host or jobs[0].host
        return self._do_schedule(jobs,host)
    
    def _refresh_record(self,job):
        record=job.record.to_dict()
        name=record.pop('name')
        self._job_store.renew_record(name,**record)
        return True
    
    def _schedule_job(self,job):
        self._refresh_record(job)
        return self._do_schedule(job)
    
    def get_scheduled_jobs(self,host=None):
        if host is None:
            return self._scheduled_jobs
        def _get_job(job):
            _job=job.to_dict()
            _job['state']=job.state
            _job['tx_time']=job.tx_time
            return _job
        job_queue=self._scheduled_jobs.get(host,Queue())
        jobs=[]
        while True:
            try:
                job=job_queue.get(block=False)
                if isinstance(job,list):
                    job=map(_get_job,job)
                else:
                    job=_get_job(job)
                jobs.append(job)
            except Empty:
                break
        if jobs:
            self._job_store.log("Schedule {count} jobs to worker('{host}')".format(count=len(jobs),host=host))
        return jobs
    
    def transfer_job(self,job,host):
        if isinstance(job,basestring):
            job=self.get_job(job)
            job=Job(**job)
        elif isinstance(job,dict):
            tx_time=job.pop('tx_time',None)
            state=job.pop('state',None)
            job=Job(**job)
            job.tx_time=tx_time
        else:
            return False
        job.host=host
        job.state=JobState.TRANSFER
        self._job_store.update_record(job.name,state=job.state,host=host)
        return self._do_schedule(job)
    
    def transfer_jobs(self,jobs,hosts):
        for jid,job in enumerate(jobs):
            idx=jid % len(hosts)
            host=hosts[idx]
            self.transfer_job(job,host)
        return True
    
    def kill_job(self,name):
        job=self.get_job(name)
        if job is None:
            return False
        job.state=JobState.KILLED
        self._job_store.log("Kill job: {name}".format(name=name))
        return self._do_schedule(job)
    
    def kill_jobs(self,name):
        if isinstance(name,basestring):
            names=name.split(',')
        elif isinstance(name,(tuple,list)):
            names=name
        else:
            return False
        for name in names:
            self.kill_job(name)
        return True
        
    def do_job(self,name,tx_time=None,host=None,**kwargs):
        job=self.get_job(name)
        if job is None:
            return False
        kwargs['tx_time']=tx_time
        kwargs['host']=host or job.host
        kwargs.setdefault('retries',0)
        job.setup(**kwargs)
        return self._schedule_job(job)
    
    def loop_job(self,name,start_txtime=None,stop_txtime=None):
        job=self.get_job(name)
        if job is None:
            return False
        record=self.get_record(name)
        if record is None:
            return False
        start_txtime=start_txtime or (record.state!=JobState.DONE and record.tx_time or job.var.txtime_add(record.tx_time,1))
        stop_txtime=stop_txtime or job.get_txtime()
        if start_txtime>stop_txtime:
            return False
        jobs=[]
        attrs=job.to_dict()
        for tx_time in job.var.txtime_range(start_txtime,stop_txtime,step=int(job.step or 1)):
            job=Job(**attrs)
            job.setup(tx_time=tx_time,retries=0)
            jobs.append(job)
        return self._batch_schedule(jobs)
    
    def batch_job(self,name,tx_time=None,host=None):
        if isinstance(name,basestring):
            names=name.split(',')
        elif isinstance(name,(tuple,list)):
            names=name
        else:
            return False
        jobs=[]
        for name in names:
            job=self.get_job(name)
            if job is None:
                return None
            job.setup(tx_time=tx_time,retries=0)
            jobs.append(job)
        return self._batch_schedule(jobs,host=host)
    
    def do_jobs(self,jobs):
        if isinstance(jobs,basestring):
            names=jobs.split(',')
        elif isinstance(jobs,(tuple,list)):
            names=jobs
        else:
            return False
        for name in names:
            self.do_job(name)
        return True
    
    def redo_job(self,**kwargs):
        new_txtime=kwargs.pop('new_txtime',None)
        rows=self._job_store.get_redo_jobs(**kwargs)
        for row in rows:
            old_txtime=row.pop('tx_time',None)
            job=Job(**row)
            job.setup(tx_time=new_txtime or old_txtime,retries=0)
            self._schedule_job(job)
        return True
    
    def __get_depends(self,name,all_depends,depends):
        _depends=all_depends.get(name,{})
        for _name in _depends:
            depends.add(_name)
            self.__get_depends(_name,all_depends,depends)
            
    def rerun_job(self,jobs):
        if isinstance(jobs,basestring):
            names=jobs.split(',')
        elif isinstance(jobs,(tuple,list)):
            names=jobs
        else:
            return False
        for name in names:
            self.do_job(name)
        forward_depends=self._job_store.get_depends()
        backward_depends=dict()
        for _name in forward_depends:
            for _depend in forward_depends[_name]:
                backward_depends.setdefault(_depend,set()).add(_name)
        depends=set()
        for name in names:
            self.__get_depends(name,backward_depends,depends)
        records=self._job_store.get_records()
        jobs=self._job_store.get_jobs()
        for name in depends:
            job=jobs.get(name)
            if not job:
                continue
            record=records.get(name)
            if not record:
                continue
            if job['timer']:
                self._rerun_jobs.add(name)
            last_txtime=JobVar.txtime_add(record['tx_time'],-1)
            self._job_store.update_record(name,tx_time=last_txtime)
        return True
    
    def _depend_on_end(self,name,**kwargs):
        state=kwargs.pop('state',JobState.DONE)
        tx_time=kwargs.pop('tx_time',None)
        if not tx_time:
            self._job_store.update_depend(name,state=state)
            depends=self._job_store.get_depend(name)
            if depends:
                self._job_store.update_dependency(name,state=JobState.UNSTART)
    
    def _wait_dependency_job(self,job):
        job.record.state=JobState.WAIT
        self._wait_jobs[job.name]=job.get_txtime()
        self._refresh_record(job)
        return True
    
    def _check_wait_job(self,job):
        if not job.is_periodic:
            return False
        if not job.is_dependency:
            return False
        if job.crontab.last_state==JobState.WAIT:
            if job.dependency.check_depends():
                job.state=JobState.PENDING
                self._job_store.update_record(job.name,state=job.state)
                job.tx_time=self._wait_jobs.pop(job.name,job.tx_time)
                job.replace(job.tx_time)
                return self._do_schedule(job)
        return False
    
    def _check_periodic_job(self,job,now=None):
        if not job.is_periodic:
            return False
        if job.crontab.check(now):
            if job.is_dependency:
                self._wait_dependency_job(job)
            else:
                return self._schedule_job(job)
        return False
    
    def _check_dependency_job(self,job):
        if not job.is_dependency:
            return False
        if job.is_periodic:
            return False
        if job.dependency.check():
            return self._schedule_job(job)
        return False
    
    def check_jobs(self,now=None):
        jobs=self.setup_jobs()
        for name in jobs:
            job=jobs.get(name)
            self._check_periodic_job(job,now)
            self._check_dependency_job(job)
            self._check_wait_job(job)
        return True
    
    def start(self):
        self._timer=spawn(self._loop,thread_name='Timer')
        
    def stop(self):
        self._stopped=True
    
    def _loop(self):
        last=None
        while not self._stopped:
            try:
                this=datetime.now().replace(second=0,microsecond=0)
                dt=last and (last+timedelta(minutes=1)) or this
                while dt<=this:
                    self._job_store.log("Start to check {now}'s jobs".format(now=dt))
                    try:
                        self.check_jobs(dt)
                    except Exception,error:
                        self._job_store.log("Check jobs error: {error}".format(error=error))
                    dt=dt+timedelta(minutes=1)
                now=datetime.now()
                delay=60-now.second-now.microsecond
                if delay>0:
                    sleep(delay)
                last=this
            except Exception,error:
                self._job_store.log("Timer's looper error: {error}".format(error=error))


