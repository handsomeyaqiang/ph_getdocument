#!/usr/bin/env python
#-*- coding:utf-8 -*-
import re
import time
import os
from subprocess import Popen,PIPE,STDOUT
from datetime import datetime
from utils import get_localhost,store_pid,kill_pid
from logger import Logger
from timer import Crontab
from threads import ThreadPool,PriorityQueue

class JobState(object):
    UNSTART='UNSTART'
    WAIT='WAIT'
    PENDING='PENDING'
    TRANSFER='TRANSFER'
    RUNNING='RUNNING'
    RETRY='RETRY'
    KILLED='KILLED'
    TIMEOUT='TIMEOUT'
    FAILED='FAILED'
    DONE='DONE'
    
job_state=JobState

class JobInfo(object):
    
    def to_dict(self):
        attrs=self.attrs
        return dict((k,v) for k,v in self.__dict__.items() if k in attrs)
    
    def to_string(self):
        return self.__str__()
        
    def to_list(self):
        attrs=self.attrs
        attr_dict=self.to_dict()
        return [attr_dict.get(attr) for attr in attrs]
    
    def to_object(self):
        return self
    
    @property
    def attrs(self):
        return [k for k,v in self.__dict__.items() if not any([k.startswith('_'),callable(v)])]
    
    @property
    def clsname(self):
        return self.__class__.__name__
    
    def _get_value(self,value):
        if isinstance(value,basestring):
            return "'%s'" % (value)
        return repr(value)
    
    def __str__(self):
        attrs=self.attrs
        attr_dict=self.to_dict()
        attrs=', '.join('{k}={v}'.format(k=attr,v=self._get_value(attr_dict.get(attr))) for attr in attrs)
        return '{cls}({attrs})'.format(cls=self.clsname,attrs=attrs)
    
    def __repr__(self):
        return '<{cls}>'.format(cls=self.__str__())
    
    def update(self,**kwargs):
        attrs=self.attrs
        attr_dict=dict((k,v) for k,v in kwargs.items() if k in attrs)
        self.__dict__.update(attr_dict)
    
class JobCrontab(JobInfo):
    
    def __init__(self,job,state=None,tx_time=None):
        self.job=job
        self.last_state=str(state or JobState.DONE).upper()
        self.last_txtime=tx_time
        if job.timer:
            self.crontab=Crontab(job.timer)
            
    def get_prev_txtime(self,now=None):
        step=self.job.step
        if step:
            prev_txtime=self.job.var.txtime_add(self.job.tx_time,-step)
        else:
            dt=str(self.crontab.prev(self.crontab.prev(now)))
            prev_txtime=self.job.dt2txtime(dt)
        return prev_txtime
    
    def check(self,now=None):
        if not self.job.timer:
            return False
        is_due=self.crontab.check(now)
        if is_due:
            if not self.job.zipper:
                return True
            if self.last_state!=JobState.DONE:
                return False
            prev_txtime=self.get_prev_txtime(now)
            last_txtime=self.last_txtime or prev_txtime
            if prev_txtime==last_txtime:
                return True
            elif self.job.tx_time==last_txtime:
                return True
        return False
    
    def prev(self,now=None):
        if not self.job.timer:
            return None
        return self.crontab.prev(now)
    
    def next(self,now=None):
        if not self.job.timer:
            return None
        return self.crontab.next(now)
    
class JobDepender(JobInfo):
    
    def __init__(self,job,state=None,tx_time=None):
        self.job=job
        self.dependency=job.name
        self.state=str(state).upper()
        self.tx_time=tx_time
    
    @property
    def attrs(self):
        return ('dependency','state','tx_time')
    
    def _get_prev_txtime(self,tx_time):
        prev_txtime=self.job.var.txtime_add(tx_time,-int(self.job.step or 1))
        return prev_txtime
    
    def check(self,wait=False):
        if self.state!=JobState.DONE:
            return False
        tx_time=self.job.get_txtime()
        if wait:
            prev_txtime=self._get_prev_txtime(tx_time)
            if prev_txtime<self.tx_time<=tx_time:
                return True
            return False
        if self.tx_time!=tx_time:
            return False
        return True
    
class JobDependency(JobInfo):
    
    def __init__(self,job,state=None,tx_time=None):
        self.job=job
        self.name=job.name
        self.last_state=str(state or JobState.DONE).upper()
        self.last_txtime=tx_time
        self.depends=dict()
        
    @property
    def attrs(self):
        return ('name','depends')
    
    def add(self,job,state=None,tx_time=None):
        dependency=job.name
        if self.has(dependency):
            return False
        depender=JobDepender(job,state=state,tx_time=tx_time)
        self.depends[dependency]=depender
        return True
    
    def remove(self,dependency):
        if not self.has(dependency):
            return False
        self.depends.pop(dependency)
        return True
    
    def has(self,dependency):
        return dependency in self.depends
    
    def get(self):
        return self.depends.keys()
        
    def update_depend(self,dependency,**kwargs):
        if not self.has(dependency):
            return False
        self.depends[dependency].update(**kwargs)
        return True
    
    def _get_prev_txtime(self):
        prev_txtime=self.job.var.txtime_add(self.job.tx_time,-int(self.job.step or 1))
        return prev_txtime
    
    def check_self(self):
        if not self.depends:
            return False
        if self.last_state!=JobState.DONE:
            return False
        prev_txtime=self._get_prev_txtime()
        last_txtime=self.last_txtime or prev_txtime
        if last_txtime!=prev_txtime:
            return False
        return True
    
    def check_depends(self):
        wait=self.last_state==JobState.WAIT
        for dependency in self.depends:
            depender=self.depends.get(dependency)
            if not depender.check(wait):
                return False
        else:
            return True
    
    def check(self):
        if not self.check_self():
            return False
        return self.check_depends()
        
class JobRecord(JobInfo):
    
    def __init__(self,name=None,state=None,cmd=None,tx_time=None,start_time=None,end_time=None,exit_code=None,retried=0,host=None,path=None):
        self.name=name
        self.state=state
        self.cmd=cmd
        self.tx_time=tx_time
        self.start_time=start_time
        self.end_time=end_time
        self.exit_code=exit_code
        self.retried=retried
        self.host=host
        self.path=path
        
    @property
    def attrs(self):
        return ('name','state','cmd','tx_time','start_time','end_time','exit_code','retried','host','path')
    
class JobExecutor(object):
    
    def __init__(self,job):
        self.job=job
        self._retried=0
        self._delay=self.job.delay or 60
        
    def log(self,msg):
        self.job.logger.log(msg)
        
    def _get_pid_file(self):
        pid_file='{path}/{name}.pid'.format(path=self.job.pid_path,name=self.job.name)
        return pid_file
    
    def _remove_pid_file(self):
        pid_file=self._get_pid_file()
        if os.path.exists(pid_file):
            os.remove(pid_file)
            
    def kill(self):
        pid_file=self._get_pid_file()
        return kill_pid(pid_file)
        
    def _execute(self,start_time=str(datetime.now())):
        state=JobState.RUNNING if self._retried==0 else JobState.RETRY
        self.job.report(start_time=start_time,state=state)
        now=time.time()
        self._sub_proc=Popen(self.job.cmd,shell=True,stdout=self.job.logger.out,stderr=self.job.logger.out)
        store_pid(self._get_pid_file(),pid=self._sub_proc.pid)
        timeout=int(self.job.timeout or 0)
        exit_code=-1
        while True:
            if timeout and time.time()-now>timeout:
		self.kill()
                exit_code=500
                state=JobState.TIMEOUT
                break
            if self._sub_proc.poll() is not None:
                exit_code=self._sub_proc.returncode
                if exit_code==0:
                    state=JobState.DONE
                elif abs(exit_code) in (15,9):
                    state=JobState.KILLED
                else:
                    state=JobState.FAILED
                break
            else:
                time.sleep(0.1)
        end=self.is_end(state)
        self.job.report(end=end,cmd=self.job.cmd,tx_time=self.job.tx_time,state=state,exit_code=exit_code,start_time=start_time,end_time=str(datetime.now()),retried=self._retried,host=self.job.host,path=self.job.path)
        return end
    
    def execute(self):
        start_time=str(datetime.now())
        try:
            while True:
                end=self._execute(start_time)
                if end:
                    break
                self._retried+=1
                time.sleep(self._delay)
        except Exception,error:
            self.log("Execute job error: {error}".format(error=error))
            self.job.report(end=True,cmd=self.job.cmd,tx_time=self.job.tx_time,state=JobState.FAILED,exit_code=100,start_time=start_time,end_time=str(datetime.now()),retried=0,host=self.job.host,path=self.job.path)
        finally:
            self._on_end()
            
    def is_end(self,state):
        if state in (JobState.DONE,JobState.KILLED):
            return True
        if self.job.retries==0:
            return True
        if self._retried==self.job.retries:
            return True
        return False
    
    def _on_end(self):
        self.job.logger.close()
        self._remove_pid_file()
    
VAR_REGEX=re.compile(r'\$\{([^\}]+?)\}')

class JobVar(JobInfo):
    
    txtime_vars=dict(txsecond='%Y%m%d%H%M%S',txminute='%Y%m%d%H%M',txhour='%Y%m%d%H',txdate='%Y%m%d',txmonth='%Y%m',txyear='%Y')
    
    def __init__(self,job=None):
        self.job=job
        
    @staticmethod
    def var_home():
        cmd='echo $HOME'
        proc=Popen(cmd,shell=True,stdout=PIPE,stderr=STDOUT)
        stdout,error=proc.communicate()
        stdout=stdout and stdout.strip() or JobVar.var_sched_home()
        return stdout
    
    @staticmethod
    def var_sched_home():
        return os.getcwd()
    
    @staticmethod
    def var_localhost():
        return get_localhost()
        
    @staticmethod
    def var_second(itv=-1,dsep='',hsep=' ',msep=':',ssep=':',has_date=False,has_hour=False,has_minute=False):
        itv=int(itv)
        fmt='%S'
        if has_minute:
            fmt=ssep.join(['%M',fmt])
        if has_hour:
            fmt=msep.join(['%H',fmt])
        if has_date:
            fmt=hsep.join([dsep.join(['%Y','%m','%d']),fmt])
        second=time.strftime(fmt,time.localtime(time.time()+itv*60))
        return second
    
    @staticmethod
    def var_txsecond(itv=-1):
        return JobVar.var_second(itv=itv,dsep='',hsep='',msep='',ssep='',has_date=True,has_hour=True,has_minute=True)
    
    @staticmethod
    def var_minute(itv=-1,dsep='',hsep=' ',msep=':',has_date=False,has_hour=False):
        itv=int(itv)
        fmt='%M'
        if has_hour:
            fmt=msep.join(['%H',fmt])
        if has_date:
            fmt=hsep.join([dsep.join(['%Y','%m','%d']),fmt])
        minute=time.strftime(fmt,time.localtime(time.time()+itv*60))
        return minute
    
    @staticmethod
    def var_txminute(itv=-1):
        return JobVar.var_minute(itv=itv,dsep='',hsep='',msep='',has_date=True,has_hour=True)
    
    @staticmethod
    def var_hour(itv=-1,dsep='',hsep=' ',has_date=False):
        itv=int(itv)
        fmt='%H'
        if has_date:
            fmt=hsep.join([dsep.join(['%Y','%m','%d']),fmt])
        hour=time.strftime(fmt,time.localtime(time.time()+itv*60*60))
        return hour
    
    @staticmethod
    def var_txhour(itv=-1):
        return JobVar.var_hour(itv=itv,dsep='',hsep='',has_date=True)
    
    @staticmethod
    def var_date(itv=-1,sep=''):
        itv=int(itv)
        fmt=sep.join(['%Y','%m','%d'])
        return time.strftime(fmt,time.localtime(time.time()+itv*24*60*60))
        
    @staticmethod
    def var_txdate(itv=-1):
        return JobVar.var_date(itv=itv,sep='')
        
    @staticmethod
    def var_month(itv=-1,sep='',has_year=False):
        itv=int(itv)
        abs_itv=abs(itv)
        year,month=map(int,time.strftime('%Y-%m',time.localtime()).split('-'))
        while abs_itv>0:
            if itv>0:
                if (month+1)>12:
                    year=year+1
                    month=1
                else:
                    month+=1
            else:
                if (month-1)==0:
                    year=year-1
                    month=12
                else:
                    month-=1
            abs_itv-=1
        month='0%s' % month if month<10 else str(month)
        if has_year:
            return sep.join([str(year),month])
        return month
    
    @staticmethod
    def var_txmonth(itv=-1):
        return JobVar.var_month(itv=itv,sep='',has_year=True)
        
    @staticmethod
    def var_year(itv=-1):
        year=time.strftime('%Y',time.localtime(time.time()))
        return str(int(year)+int(itv))
        
    var_txyear=var_year
    
    def replace(self,string,tx_time=None):
        if (not string) or (not isinstance(string,basestring)):
            return string
        for _var in VAR_REGEX.findall(string):
            parts=_var.split(':',1)
            var,args=len(parts)>1 and parts or (parts[0],None) 
            if args is not None:
                args=tuple(args.split(','))
            else:
                args=()
            attr='var_{var}'.format(var=var)
            if tx_time and var in self.txtime_vars:
                new=tx_time
            elif hasattr(self,attr):
                new=getattr(self,attr)(*args)
            elif self.job and hasattr(self.job,var):
                new=getattr(self.job,var)
            else:
                new='${%s}' % (_var)
            string=re.sub(r'\$\{%s(?:[^\}]+?)?\}' %(var),str(new),string)
        return string
    
    @staticmethod
    def get_txvar(string):
        if (not string) or (not isinstance(string,basestring)):
            return (None,None)
        for var in VAR_REGEX.findall(string):
            parts=var.split(':',1)
            var=parts[0]
            if var in JobVar.txtime_vars:
                return (var,int(parts[1]) if len(parts)>1 else None)
        return (None,None)
    
    @staticmethod
    def has_txtime(string):
        var,step=JobVar.get_txvar(string)
        return var is not None
    
    @staticmethod
    def get_txtime(string,itv=-1,has_default=False,times=1):
        var,step=JobVar.get_txvar(string)
        itv=int(step if step is not None else itv)*times
        if var is not None:
            attr='var_{0}'.format(var)
            val=getattr(JobVar,attr)(itv)
            return val
        return has_default and JobVar.var_txdate(itv=itv) or None
    
    @staticmethod
    def txtime_add(tx_time,itv=-1):
        tx_time,itv=str(tx_time),int(itv)
        if len(tx_time)==4:
            return str(int(tx_time)+itv)
        elif len(tx_time)==6:
            abs_itv=abs(itv)
            year,month=int(tx_time[:4]),int(tx_time[4:])
            while abs_itv>0:
                if itv>0:
                    if (month+1)>12:
                        year=year+1
                        month=1
                    else:
                        month+=1
                else:
                    if (month-1)==0:
                        year=year-1
                        month=12
                    else:
                        month-=1
                abs_itv-=1
            month=month<10 and '0'+str(month) or str(month)
            return str(year)+month
        elif len(tx_time)==8:
            fmt,num='%Y%m%d',24*60*60
        elif len(tx_time)==10:
            fmt,num='%Y%m%d%H',60*60
        elif len(tx_time)==12:
            fmt,num='%Y%m%d%H%M',60
        elif len(tx_time)==14:
            fmt,num='%Y%m%d%H%M%S',1
        return time.strftime(fmt,time.localtime(time.mktime(time.strptime(tx_time,fmt))+itv*num))
    
    @staticmethod
    def txtime_range(start_txtime,stop_txtime=None,step=1):
        start_txtime=int(start_txtime)
        stop_txtime=int(stop_txtime or start_txtime)
        if start_txtime>stop_txtime:
            step=step>0 and 0-step or step
            tx_time=start_txtime
            while tx_time<=start_txtime and tx_time>=stop_txtime:
                yield str(tx_time)
                tx_time=int(JobVar.txtime_add(tx_time,step))
        else:
            tx_time=start_txtime
            while tx_time>=start_txtime and tx_time<=stop_txtime:
                yield str(tx_time)
                tx_time=int(JobVar.txtime_add(tx_time,step))
    
    @staticmethod
    def dt2txtime(string,dt):
        var,step=JobVar.get_txvar(string)
        if var is None:
            return None
        fmt=JobVar.txtime_vars.get(var)
        tx_time=time.strftime(fmt,time.localtime(time.mktime(time.strptime(dt,'%Y-%m-%d %X'))))
        return tx_time
    
class JobUser(JobInfo):
    
    def __init__(self,name=None,email=None,mobile=None,desc=None,enable=1):
        self.name=name
        self.email=email
        self.mobile=mobile
        self.desc=desc
        self.enable=int(enable)
        
    @property
    def attrs(self):
        return ('name','email','mobile','desc','enable')
    
class Job(JobInfo):
    
    def __init__(self,name=None,timer=None,cmd=None,host=None,priority=0,retries=0,delay=0,timeout=0,step=None,zipper=1,transfer=1,path=None,group=None,man=None,desc=None,enable=1):
        self.name=name
        self.timer=timer
        self.cmd=self._cmd=cmd
        self.host=host or get_localhost()
        self.priority=int(priority)
        self.retries=int(retries)
        self.delay=int(delay)
        self.timeout=int(timeout)
        self.step=None if step in (None,'') else int(step)
        self.zipper=int(zipper)
        self.transfer=int(transfer)
        self.path=self._path=path
        self.group=group
        self.man=man
        self.desc=desc
        self.enable=int(enable)
        self.pid_path='.'
        self.state=JobState.UNSTART
        self.tx_time=None
        self.setup_var()
        
    def get_txtime(self,itv=-1):
        if self.zipper:
            return self.var.get_txtime(self._cmd,itv=itv,has_default=True)
        else:
            return self.var.get_txtime(self._cmd,itv=itv,has_default=False)
    
    def dt2txtime(self,dt):
        return self.var.dt2txtime(self._cmd,dt)
    
    def setup(self,state=JobState.PENDING,tx_time=None,replace=True,**kwargs):
        opened=kwargs.pop('opened',False)
        self.__dict__.update(kwargs)
        self.state=str(state).upper()
        self.tx_time=tx_time or self.get_txtime()
        if replace:
            self.replace(self.tx_time)
        self.setup_record(cmd=self.cmd,state=self.state,tx_time=self.tx_time,host=self.host,path=self.path)
        self.setup_logger(opened)
        
    def replace(self,tx_time):
        self.cmd=self.var.replace(self._cmd,tx_time)
        self.path=self.var.replace(self._path,tx_time)
        
    def setup_record(self,**kwargs):
        self.record=JobRecord(name=self.name,**kwargs)
        
    def execute(self):
        executor=JobExecutor(self)
        executor.execute()
        return self.record
    
    @property
    def attrs(self):
        return ('name','cmd','timer','host','priority','retries','delay','timeout','step','zipper','transfer','path','group','man','desc','enable')
    
    def setup_var(self):
        self.var=JobVar(self)
        
    def setup_crontab(self,state=None,tx_time=None):
        self.crontab=JobCrontab(self,state=state,tx_time=tx_time)
        
    def setup_dependency(self,state=None,tx_time=None):
        self.dependency=JobDependency(self,state=state,tx_time=tx_time)
        
    def setup_logger(self,opened=False):
        self.logger=Logger(self.name,path=self.path,opened=opened)
    
    def report(self,**record):
        self.record.update(**record)
        record.setdefault('name',self.name)
        self.notify(**record)
        
    def do(self):
        self.setup()
        return self.execute()
    
    def notify(self,**record):
        return record
    
    @property
    def is_periodic(self):
        if not self.timer:
            return False
        return True
    
    @property
    def is_dependency(self):
        if not hasattr(self,'dependency'):
            return False
        return len(self.dependency.get()) and True or False
    
    @property
    def is_eager(self):
        if not any([self.is_periodic,self.is_dependency]):
            return True
        return False
    
class JobPool(ThreadPool):
    
    def __init__(self,max_workers=30,queue=PriorityQueue,logger=None):
        ThreadPool.__init__(self,max_workers=max_workers,queue=queue,logger=logger)
        
    def do_job(self,job):
        job,_,_=job
        if isinstance(job,list):
            for _job in job:
                record=_job.record.to_dict()
                _job.report(**record)
                record=_job.execute()
                if record.state!=JobState.DONE:
                    break
        else:
            job.execute()
            
def do_job(**kwargs):
    job=Job(**kwargs)
    return job.do()


