#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os,sys,re,time
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
from data.util.Logger import logger
from data.util.Shell import Shell


SQL_REGEX=re.compile(r'-q "([^"]+)"',re.MULTILINE)
ERROR_REGEX=re.compile(r'(?:FAILED|Exception):',re.I)
TIME_TAKEN_REGEX=re.compile(r'Returned \d+ row\(s\) in ([\d\.]+)s')


class Impala(object):
    
    def __init__(self):
        self._sql=None
        self._timeout=7200
        self._has_header=False
        self._silent=False
	self._date=None
        
    def set_date(self,date):
        self._date=date
        return self
        
    def set_silent(self,silent):
        self._silent=silent
        return self
    
    def get_silent(self):
        return self._silent
    
    def set_timeout(self,timeout):
        self._timeout=timeout
        return self
    
    def get_timeout(self):
        return self._timeout
    
    def set_sql(self,sql):
        self._sql=str(sql).strip()
        return self
    
    def get_sql(self):
        return self._sql
    
    add_sql=set_sql
    
    def set_has_header(self,has_header):
        self._has_header=has_header
        return self
    
    def get_has_header(self):
        return self._has_header
    
    def _clean_sql(self,sql):
        sql=sql.split('\n')
        cleaned_sql=''
        for line in sql:
            if line=='':
                continue
            elif line.startswith('--'):
                continue
            elif '--' in line:
                cleaned_sql+=line[:line.find('--')] + ' '+ '\n'
            else:
                cleaned_sql+=line + ' ' + '\n'
        return cleaned_sql
    
    def execute(self):
        assert self._sql is not None,"Must set sql at first"
        _sql=self.get_sql()
        sql='impala-shell -B -r '
        if self._has_header:
            sql+='--print_header '
        if self._silent:
            sql+='-S '
        if _sql.endswith('.sql') and os.path.exists(_sql):
            sql+='-f %s' % (_sql)
        else:
            sql+='-q "\n'
            sql+=self._clean_sql(_sql).replace('"', '\\"')
            sql+='";\n'
        self.set_sql(sql)
        
    def rows(self):
        shell=Shell(self._sql)
        outs=shell.outs()
        if self._silent:
            for line in outs:
                yield line
        else:
            start=time.time()
            m=re.search(SQL_REGEX,self._sql)
            if m:
                parts=m.group(1).split(';')
            else:
                parts=self._sql
            idx=-1
            line=outs.next()
            outing=False
            while line:
                if line.startswith('Query: '):
                    outing=True
                    print line
                    line=outs.next()
                elif re.search(ERROR_REGEX,line):
                    raise Exception("Execute sql error: %s" % line)
                else:
                    if not re.search(TIME_TAKEN_REGEX,line):
                        print line
                    line=outs.next()
                if time.time()-start>=self._timeout:
                    raise Exception("TimeoutError: %s" % parts[(0 if idx==-1 else idx)].strip())
                while outing:
                    if time.time()-start>=self._timeout:
                        raise Exception("TimeoutError: %s" % parts[(0 if idx==-1 else idx)].strip())
                    m=re.search(TIME_TAKEN_REGEX,line)
                    if m:
                        outing=False
                        idx+=1
                        print
                        logger.info('Sql "%s" take %s seconds' % (parts[idx].strip(),m.group(1)))
                        print
                    elif re.search(ERROR_REGEX,line):
                        raise Exception("Execute sql error: %s" % line)
                    elif line.startswith('Query: '):
                        outing=False
                    else:
                        yield line
                        line=outs.next()
        
    def fetch(self):
        self.execute()
        logger.info('Begin execute sql: \n%s' % self._sql)
        try:
            for row in self.rows():
                yield row
        except SystemExit,exit_code:
            sys.exit(exit_code)
        except Exception as msg:
            msg=str(msg)
            logger.error(msg)
            m=re.search(r'error code is ([^\.]+)\.',msg)
            if m:
                exit_code=int(m.group(1))
            else:
                exit_code=100
            sys.exit(exit_code)
        logger.info('End execute sql.')
        
    def export(self,out=sys.stdout,sep='\t',line_sep='\n'):
	if isinstance(out,basestring):
            f=open(out,'w')
        else:
            f=out
        for line in self.fetch():
            if sep=='\t':
                f.write(line+line_sep)
            else:
                f.write(sep.join(line.split('\t'))+line_sep)
        if isinstance(out,basestring):
            f.close()
            
    def run(self):
        for line in self.fetch():
	    print line


def demo():
    impala=Impala()
    #impala.set_timeout(seconds)
    #impala.set_has_header(True)
    impala.set_sql(sql)
    #rows=list(impala.fetch())
    #impala.export(out=out_file)
    impala.run()
 
