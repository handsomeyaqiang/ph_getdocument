#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os

dictetl=dict(host='172.16.2.103',port=3306,user='diaodu',passwd='zjKSt0QQrEIMsjm',db='test')
youcredit=dict(host='172.16.2.139',port=3309,user='dwuser',passwd='m8P7sppammbsmeqJIDuP',db='youcredit')
thread=dict(host='172.16.2.139',port=3309,user='dwuser',passwd='m8P7sppammbsmeqJIDuP',db='thread')
sps=dict(host='172.16.2.81',port=3306,user='diaodu_r',passwd='X5JRC4978yvAOdlcyV4q',db='sps')
nirvana=dict(host='172.16.2.90',port=3308,user='shucang_r',passwd='7LdmV54woCMzU5gNbjIL',db='nirvana')
#print dictetl
