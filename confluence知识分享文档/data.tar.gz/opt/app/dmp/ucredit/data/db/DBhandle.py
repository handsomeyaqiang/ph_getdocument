# -*- coding: utf: utf-8 -*-

import os
import sys
import datetime
import MySQLdb

class DBhandle(object):
    def __init__(self, config):
        self.conn = MySQLdb.connect(host=config['host'], user=config['user'],
                                    passwd=config['passwd'], db=config['db'],
                                    port=config['port'], charset='utf8')
        self.cursor = self.conn.cursor()

    def insert(self, sql):
        res = self.execute(sql)
        return res

    def update(self, sql):
        res = self.execute(sql)
        return res

    def delete(self, sql):
        res = self.execute(sql)
        return res

    def select(self, sql):
        res = self.execute(sql)
        data = self.cursor.fetchall()
        return data

    def execute(self, sql):
        res = self.cursor.execute(sql)
        #self.cursor.fetchall()
        self.conn.commit()
        return res

    def close(self):
        self.cursor.close()
        self.conn.close()



