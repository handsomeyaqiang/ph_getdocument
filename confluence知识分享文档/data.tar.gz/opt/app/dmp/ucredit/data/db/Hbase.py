#!/usr/bin/env python
#-*- coding:utf-8 -*-
import re
from data.util.Shell import Shell


class Hbase(object):
    
    def help(self):
        return self.do('help')
    
    def exists(self,table):
        start=r'^Table [^\s]+ does(\snot)? exist$'
        cmd="exists '{table}'".format(table=table)
        line=list(self.fetch(cmd,start,has_start_line=True))[0]
        m=re.search(start,line)
        if m:
            if m.group(1):
                return False
            return True
        return False
    
    def execute(self,cmd):
        code="""hbase shell<<EOF\n{cmd}\nEOF""".format(cmd=cmd)
        shell=Shell(code)
        return shell.outs()
    
    def fetch(self,cmd,start=None,end=r'^\d+ row\(s\) in [\d\.]+ seconds$',has_start_line=False,has_end_line=False):
        sre=re.compile(start,re.DOTALL) if start else None
        ere=re.compile(end,re.DOTALL)
        outing=False
        for line in self.execute(cmd):
            if line.startswith('SLF4J:'):
                continue
            if sre is None:
                if re.search(ere,line):
                    if has_end_line:
                        yield line
                    else:
                        break
                else:
                    yield line
            else:
                if re.search(sre,line):
                    outing=True
                    if has_start_line:
                        yield line
                    else:
                        continue
                elif re.search(ere,line):
                    outing=False
                    if has_end_line:
                        yield line
                    else:
                        break
                if outing:
                    yield line
                
    def do(self,cmd):
        if isinstance(cmd,basestring):
            cmds=cmd
        elif isinstance(cmd,(tuple,list)):
            cmds='\n'.join(cmd)
        try:
            for line in self.execute(cmds):
                print line
            return True
        except Exception as msg:
            print msg
            return False
        
    def list(self):
        cmd='list'
        start='^TABLE$'
        return list(self.fetch(cmd,start))
    
    def is_enabled(self,table):
        cmd="is_enabled '{table}'".format(table=table)
        line=list(self.fetch(cmd,start=r'^(true|false)$',has_start_line=True))[1]
        if line=='true':
            return True
        else:
            return False
        
    def is_disabled(self,table):
        cmd="is_disabled '{table}'".format(table=table)
        line=list(self.fetch(cmd,start=r'^(true|false)$',has_start_line=True))[1]
        if line=='true':
            return True
        else:
            return False
        
    def disable(self,table):
        cmd="disable '{table}'".format(table=table)
        return self.do(cmd)
    
    def enable(self,table):
        cmd="enable '{table}'".format(table=table)
        return self.do(cmd)
    
    def drop(self,table):
        if self.exists(table):
            if self.is_enabled(table):
                self.disable(table)
            cmd="drop '{table}'".format(table=table)
            return self.do(cmd)
        return True
    
    def get(self,table,row_key,where=None,out_style='to_dict'):
        cmd="get '{table}', '{row_key}'".format(table=table,row_key=row_key)
        if where:
            cmd+=", {where}".format(where=repr(where))
        start=r'COLUMN\s+CELL'
        for line in self.fetch(cmd,start):
            row=self._process_line(line,out_style)
            yield row
            
    def _process_line(self,line,out_style,has_row_key=False):
        if out_style=='ori_string':
            return line
        column,cell=line.split(' ',1)
        cells=map(lambda f:f.split('=',1),cell.split(', ',1))
        if out_style=='to_string':
            row='\t'.join([column]+map(lambda f:f[1],cells))
            return row
        elif out_style=='to_list':
            row=[column]+map(lambda f:f[1],cells)
            return row
        elif out_style=='to_dict':
            if has_row_key:
                row=dict(row_key=column)
            else:
                row=dict(column=column)
            row.update(dict(cells))
            return row
        return None
    
    def put(self,*row):
        table,row_key,cf,value=row
        cmd="put '{table}', '{row_key}', '{cf}', '{value}'".format(table=table,row_key=row_key,cf=cf,value=value)
        return self.do(cmd)
    
    def puts(self,rows):
        cmds=[]
        for row in rows:
            table,row_key,cf,value=row
            cmd="put '{table}', '{row_key}', '{cf}', '{value}'".format(table=table,row_key=row_key,cf=cf,value=value)
            cmds.append(cmd)
        return self.do(cmds)
    
    def scan(self,table):
        for line in self.rows(table,out_style='ori_string'):
            print line
            
    def rows(self,table,out_style='to_dict'):
        start=r'ROW\s+COLUMN\+CELL'
        cmd="scan '{table}'".format(table=table)
        for line in self.fetch(cmd,start=start):
            row=self._process_line(line,out_style,has_row_key=True)
            yield row
            
    def create(self,table,*cf):
        if self.exists(table):
            return True
        cmd="create '{table}', {cf}".format(table=table,cf=", ".join(map(repr,cf)))
        return self.do(cmd)
    
    def delete(self,table,row_key,where=None):
        cmd="delete '{table}', '{row_key}'".format(table=table,row_key=row_key)
        if where:
            cmd+=", {where}".format(where=repr(where))
        return self.do(cmd)
    
    def count(self,table):
        cmd="count '{table}'".format(table=table)
        start=r'^{cmd}$'.format(cmd=cmd)
        end='^(\d+)$'
        line=list(self.fetch(cmd,start=start,end=end,has_end_line=True))[-1]
        return int(line)
    
hbase=Hbase()

