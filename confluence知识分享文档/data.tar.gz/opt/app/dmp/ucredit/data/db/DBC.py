#!/usr/bin/env python
#-*- coding:utf-8 -*-

class BaseDBC(object):
    def __init__(self):
        self.dbc={}
        self.set_dbc()
        
    def __call__(self):
        return self.dbc
        
    def register(self,dbn,db=None,**dbc):
        dbc['db']=db
        if dbn not in self.dbc:
            self.dbc[dbn]=dbc
	    
    def set_dbc(self):
        for k in dir(self.__class__):
            if k.startswith('_') and k.endswith('_dbs'):
                getattr(self,k)()

class UcreditDBC(BaseDBC):
    def __init__(self):
        self.dbc={}
        self.set_dbc()
	
    def _stat_dbs(self):
	for dbn,db in [
	    ('db_hermes','hermes'),
	    ('db_thread','thread'),
	    ('db_youcredit','youcredit'),
	    ]:
	    self.register(dbn,db=db,host='211.155.80.57',port=3309,user='shucang_r',passwd='shucang#$123!')
	    
    def _user_dbs(self):
	for dbn,db in [
	    ('db_ecif','ecif'),
	    ]:
	    self.register(dbn,db=db,host='115.182.210.158',port=3306,user='ecif_shucang',passwd='ecif_shucang')
	for dbn,db in [
	    ('db_3307_recruit','DB_RECRUIT'),
	    ]:
	    self.register(dbn,db=db,host='10.10.67.24',port=3307,user='data_sel',passwd='dajie.data&')
	for dbn,db in [
	    ('db_3351_center','DB_CENTER'),
	    ]:
	    self.register(dbn,db=db,host='10.10.67.40',port=3351,user='data_sel',passwd='dajie.data&')
	for dbn,db in [
	    ('db_3352_business','DB_BUSINESS'),
	    ]:
	    self.register(dbn,db=db,host='10.10.67.40',port=3352,user='data_sel',passwd='dajie.data&')
	
    def _dw_dbs(self):
	for dbn,db in [
	    ('db_dw_dw','dw'),
	    ('db_dw_plat','dw_plat')]:
	    self.register(dbn,db=db,host='10.10.67.30',port=6001,user='statol',passwd='statol-5')
	for dbn,db in [
	    ('local_dw_dw','dw'),
	    ('local_dw_plat','dw_plat')]:
	    self.register(dbn,db=db,host='10.10.67.30',port=6001,user='wei.an',passwd='dajie.wei&')
	    
    def _rec_dbs(self):
	for dbn,db in [
	    ('db_rec_app','DB_APP'),
	    ('db_rec_ask','DB_ASK'),
	    ('db_rec_club','DB_CLUB'),
	    ]:
	    self.register(dbn,db=db,host='192.168.10.11',port=3316,user='recruit',passwd='uc1q2w3e4r')
	    
    def _dm_dbs(self):
	for dbn,db in [
	    ('db_dm_cfg','db_datamgrcfg'),
	    ('db_data_discover','db_data_discover'),
	    ('db_stg','stg'),
	    ]:
	    self.register(dbn,db=db,host='172.16.2.103',port=3306,user='diaodu',passwd='zjKSt0QQrEIMsjm')
	    
    def _hive_test_dbs(self):
	self.register('hive_test_dss','dss',host='192.168.11.122',port=10000)
	
    def _hive_dbs(self):
	self.register('hive_dw_dss','dss',host='64-67.bjyz.dajie-inc.com',port=10000)
	self.register('hive_dw_default','dss',host='64-67.bjyz.dajie-inc.com',port=10000)

class DBC(dict):
    def __init__(self,dbc=UcreditDBC()()):
        self.dbc=dbc
        self._set_attrs()
        self.update(self.dbc)
        
    def __getitem__(self,dbn):
        if dbn in self.dbc:
            return self.dbc.get(dbn)
        raise Exception('No defined dbn: %s in dbc.' % dbn)
        
    def _set_attrs(self):
        for dbn,dbc in self.dbc.items():
            setattr(self,dbn,dbc)
            
dbc=DBC()
