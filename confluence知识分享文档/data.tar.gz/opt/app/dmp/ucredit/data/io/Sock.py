#!/usr/bin/env python
import os,sys
import socket
import struct
from data.util.Error import ERRNO_RETRIES,ImplementError,ReadError,WriteError,NoTypeError
from data.io.IO import IO
from data.util.Module import pickle
    
class StrIO(IO):
    def __init__(self,sock=None,timeout=None,protocol='TCP'):
        self.sock=sock
        self.timeout=timeout
        self.protocol=protocol
        if protocol=='TCP':
            self.recv=self.sock.recv
        elif protocol=='UDP':
            self.recv=self.sock.recvfrom
        self._read_type='suffix'
        self._read_length=1024
        self._read_size=1024
        self._read_suffix='\n'*4
        
    def read_type(self,type=None):
        if type is not None:
            self._read_type=type
        return self._read_type
        
    def read_length(self,length=None):
        if length is not None:
            self._read_length=length
        return self._read_lenght
    
    def read_size(self,size=None):
        if size is not None:
            self._read_size=size
        return self._read_size
    
    def read_suffix(self,suffix=None):
        if suffix is not None:
            self._read_suffix=suffix
        return self._read_suffix
        
    def read_by_length(self,length=None):
        if length is None:
            length=self.read_length()
        data=''
        while len(data)<length:
            try:
                more=self.recv(length-len(data))
                if not more:
                    raise ReadError("No more data to read.")
                data+=more
            except socket.timeout:
                raise ReadError("Read data timeout.")
            except socket.error:
                x=sys.exc_info()[1]
                err=getattr(x,"errno",x.args[0])
                if err not in ERRNO_RETRIES:
                    raise ReadError("Read error: "+str(e))
        return data
    
    def read_by_size(self,size=None):
        if size is None:
            size=self.read_size()
        data=''
        while True:
            try:
                buffer=self.recv(size)
                if not buffer:
                    break
                data+=buffer
            except socket.timeout:
                raise ReadError("Read data timeout.")
            except socket.error:
                x=sys.exc_info()[1]
                err=getattr(x,"errno",x.args[0])
                if err not in ERRNO_RETRIES:
                    raise ReadError("Read error: "+str(e))
        return data
    
    def read_by_suffix(self,size=None,suffix=None):
        if size is None:
            size=self.read_size()
        if suffix is None:
            suffix=self.read_suffix()
        data=''
        while True:
            try:
                data+=self.recv(size)
                if data[-len(suffix):]==suffix:
                    break
            except socket.timeout:
                raise ReadError("Read data timeout.")
            except socket.error:
                x=sys.exc_info()[1]
                err=getattr(x,"errno",x.args[0])
                if err not in ERRNO_RETRIES:
                    raise ReadError("Read error: "+str(e))
        return data[:-len(suffix)]
    
    def read_by_suffix2(self,size=None,suffix=None):
        if size is None:
            size=self.read_size()
        if suffix is None:
            suffix=self.read_suffix()
        msg=''
        while not msg.endswith(suffix):
            try:
                data=self.recv(size)
                if not data:
                    raise ReadError("No enough read data.")
                msg+=data
            except socket.timeout:
                raise ReadError("Read data timeout.")
            except socket.error:
                x=sys.exc_info()[1]
                err=getattr(x,"errno",x.args[0])
                if err not in ERRNO_RETRIES:
                    raise ReadError("Read error: "+str(e))
        return msg
    
    def read(self):
        '''
        you should define your own suffix and suffix should be uniq. 
        '''
        rt=str(self.read_type()).lower()
        size=self.read_size()
        suffix=self.read_suffix()
        if rt=='size':
            return self.read_by_size(size)
        elif rt=='length':
            return self.read_by_length(self.read_length())
        elif rt=='suffix':
            return self.read_by_suffix(size,suffix)
        else:
            return self.read_by_suffix2(size,suffix)
        
    def write(self,data):
        rt=str(self.read_type).lower()
        suffix=self.read_suffix()
        if suffix is not None:
            data+=suffix
        if not self.timeout:
            try:
                self.sock.sendall(data)
            except socket.timeout:
                raise WriteError('Write data timeout.')
            except socket.error:
                x=sys.exc_info()[1]
                err=getattr(x,"errno",x.args[0])
                if err not in ERRNO_RETRIES:
                    raise WriteError("Write error: "+str(e))
        else:
            while data:
                try:
                    size=self.sock.send(data)
                    data=data[size:]
                except socket.timeout:
                    raise WriteError('Write data timeout.')
                except socket.error:
                    x=sys.exc_info()[1]
                    err=getattr(x,"errno",x.args[0])
                    if err not in ERRNO_RETRIES:
                        raise WriteError("Write error: "+str(e))

class ObjIO(StrIO):
    def __init__(self,**kwargs):
        super(ObjIO,self).__init__(**kwargs)
    
    def read(self):
        data=super(ObjIO,self).read()
        return pickle.loads(data)
    
    def write(self,obj):
        data=pickle.dumps(obj)
        super(ObjIO,self).write(data)
    
class FileIO(StrIO):
    def __init__(self,**kwargs):
        super(FileIO,self).__init__(**kwargs)
    
    def read(self,file):
        self.read_size(2048)
        data=super(FileIO,self).read()
        f=open(file,'wb')
        f.write(data)
        f.close()
    
    def write(self,file):
        data=open(file,'rb').read()
        super(FileIO,self).write(data)
        
def StructIO(StrIO):
    def __init__(self,fmt='!I',**kwargs):
        super(StructIO,self).__init__(**kwargs)
        self.fmt=struct.Struct(fmt)
    
    def read(self):
        length_data=self.read_by_length(self.fmt.size)
        length=self.fmt.unpack(length_data)
        return self.read_by_length(length)
    
    def write(self,data):
        data=self.fmt.pack(len(data))+data
        return super(StructIO,self).write(data)
        
def SockIO(type='str',*args,**kwargs):
    type=type.lower()
    types={
        'str':StrIO,
        'obj':ObjIO,
        'file':FileIO,
        'struct':StructIO,
    }
    cls=types.get(type,None)
    if cls is None:
        raise NoTypeError
    return cls(*args,**kwargs)
