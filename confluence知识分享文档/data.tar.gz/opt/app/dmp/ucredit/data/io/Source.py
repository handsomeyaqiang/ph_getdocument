#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os,sys
import glob
import re
import copy
from data.util.Logger import logger

class BaseSource(object):
    
    def __init__(self,source=None):
        self._source=source
        self._sep='\t'
        self._out_sep='\t'
        self._line_sep='\n'
        self._mode='r'
        self._block_size=-1
        self._handler=None
        self._source_type=None
        self._coding='utf-8'
        
    @property
    def is_compressed(self):
        return self.source_type in '.GZ,.BZ2,.ZIP,.TAR,.TAR.GZ,.TAR.BZ2'.split(',')
    
    @property
    def is_tar(self):
        return self.source_type.startswith('.TAR')
    
    @property
    def is_zip(self):
        return self.source_type=='.ZIP'
    
    @property
    def is_file(self):
        if self.is_compressed:
            return True
        return self.source_type=='.FILE'
    
    @property
    def is_url(self):
        return self.source_type=='.URL'
    
    @property
    def is_sql(self):
        return self.source_type=='.SQL'
    
    @property
    def is_excel(self):
        return self.source_type=='.EXCEL'
    
    @property
    def is_std(self):
        return self.source_type=='.STD'
    
    @property
    def is_str(self):
        return self.source_type=='.STR'
    
    @property
    def is_json(self):
        return self.source_type=='.JSON'
    
    @property
    def is_pickle(self):
        return self.source_type=='.PICKLE'
    
    @property
    def handler(self):
        return self._handler
    
    @property
    def source_type(self):
        return str(self._source_type)
    
    @property
    def coding(self):
        return self._coding
    
    def remove_line_sep(self,line):
        if isinstance(line,basestring):
            if line.endswith(self._line_sep):
                line=line[:-len(self._line_sep)]
        return line
    
    def default_line_func(self,line):
        return line
    
    def add_line_sep(self,line):
        if self._block_size>0:
            return line
        if not isinstance(line,basestring):
            return line
        if not line.endswith(self._line_sep):
            line+=self._line_sep
        return line
    
    def to_string(self,line):
        if isinstance(line,basestring):
            return line
        elif isinstance(line,(tuple,list)):
            return self._out_sep.join([(unicode(field) if isinstance(field,unicode) else str(field)) for field in line])
        return line
    
    def to_list(self,line):
        if isinstance(line,basestring):
            return line.strip().split(self._sep)
        elif isinstance(line,(tuple,list)):
            return line
        return line
    
    def get_size(self,**kwargs):
        try:
            if self.is_file:
                return os.path.getsize(self._source)
            else:
                return sum(len(self.to_string(line)) for line in self.read(**kwargs))
        except:
            return 0
        
    def get_line_count(self,**kwargs):
        try:
            return sum(1 for line in self.read(**kwargs))
        except:
            return 0
        
    def open(self,**kwargs):
        pass
    
    def close(self):
        if hasattr(self.handler,'close'):
            self.handler.close()
        self._handler=None
        
    def scan(self,**kwargs):
        for data in self.read(**kwargs):
            line=self.default_line_func(data)
            line=self.to_string(line)
            line=self.add_line_sep(line)
            sys.stdout.write(line)
            
    def _get_read_mode(self,mode,size):
        if mode:
            return mode
        if size>0:
            mode='rb' if not self._mode.startswith('r') else self._mode
        else:
            mode='r' if not self._mode.startswith('r') else self._mode
        return mode
    
    def read(self,**kwargs):
        mode=kwargs.pop('mode',None)
        debug=kwargs.pop('debug',True)
        size=kwargs.pop('size',self._block_size)
        if self.handler is None:
            mode=self._get_read_mode(mode,size)
            self.open(mode=mode,**kwargs)
        if size>0:
            iterable=self._read_blocks(size)
        else:
            iterable=self._read_lines()
        if debug:
            logger.info("Read source from [%s]" % self._source)
        for data in iterable:
            yield data
            
    def _read_blocks(self,size):
        read_block=self.handler.read
        while True:
            data=read_block(size)
            if not data:
                break
            yield data
            
    def _read_lines(self):
        lines=self.handler
        for line in lines:
            yield line
            
    def __iter__(self):
        return iter(self.read())
    
    def set_mode(self,mode):
        self._mode=mode
        return self
    
    def set_sep(self,sep):
        self._sep=sep
        return self
    
    def set_out_sep(self,sep):
        self._out_sep=sep
        return self
    
    def set_line_sep(self,sep):
        self._line_sep=sep
        return self
    
    def set_block_size(self,size):
        self._block_size=size
        return self
    
    def write(self,data,**kwargs):
        mode=kwargs.pop('mode',('w' if self._mode.startswith('r') else self._mode))
        if self.handler is None:
            self.open(mode=mode,**kwargs)
        self.handler.write(data)
    
    def compress(self,src,**kwargs):
        dest=self._source
        logger.info("Compress from %s into [%s]" % (src,dest))
        mode=kwargs.pop('mode',('w' if self._mode.startswith('r') else self._mode))
        if self.handler is None:
            self.open(mode=mode)
        write_line=self.handler.write
        s=Source(src)
        for line in s.read(**kwargs):
            write_line(line)
        s.close()
        self.close()
        
    def decompress(self,dest=None,**kwargs):
        if dest is None:
            dest=self._source[:-len(self.source_type)]
        logger.info('Decompress [%s] into %s' % (self._source,dest))
        s=Source(dest)
        write_line=s.write
        for line in self.read(**kwargs):
            write_line(line)
        self.close()
        s.close()
        
class FileSource(BaseSource):
    
    def __init__(self,source):
        super(FileSource,self).__init__(source)
        self._source_type='.FILE'
        
    def open(self,**kwargs):
        mode=kwargs.pop('mode',self._mode)
        f=open(self._source,mode=mode,**kwargs)
        self._handler=f
        return f
    
class GzipSource(BaseSource):
    
    def __init__(self,source):
        super(GzipSource,self).__init__(source)
        self._source_type='.GZ'
        
    def open(self,**kwargs):
        import gzip
        mode=kwargs.pop('mode',self._mode)
        gz=gzip.open(self._source,mode=mode,**kwargs)
        self._handler=gz
        return gz
    
class BZ2Source(BaseSource):
    
    def __init__(self,source):
        super(BZ2Source,self).__init__(source)
        self._source_type='.BZ2'
        
    def open(self,**kwargs):
        import bz2
        mode=kwargs.pop('mode',self._mode)
        bz=bz2.BZ2File(self._source,mode=mode,**kwargs)
        self._handler=bz
        return bz
    
def _get_member(members,member=0):
    default_member=members[0]
    if isinstance(member,int):
        if 0<=member<len(members):
            return members[member]
        return default_member
    elif isinstance(member,basestring):
        ms=[m for m in members if m.lower()==member.lower()]
        if len(ms)>0:
            return ms[0]
        return default_member
    return default_member
    
class ZipSource(BaseSource):
    
    def __init__(self,source):
        super(ZipSource,self).__init__(source)
        self._source_type='.ZIP'
        self._member=None
        
    def set_member(self,member):
        self._member=member
        return self
    
    def get_member(self,members,member=0):
        return _get_member(members,member)
    
    @property
    def members(self):
        return self.handler.namelist()
    
    def open(self,**kwargs):
        import zipfile
        member=kwargs.pop('member',self._member)
        mode=kwargs.get('mode',self._mode)
        zf=zipfile.ZipFile(self._source,**kwargs)
        self._handler=zf
        return zf
    
    def read(self,**kwargs):
        mode=kwargs.pop('mode',None)
        member=kwargs.pop('member',self._member)
        size=kwargs.pop('size',self._block_size)
        if self.handler is None:
            mode=self._get_read_mode(mode,size)
            self.open(mode=mode,**kwargs)
        members=[self.get_member(self.members,member)] if member is not None else self.members
        for member in members:
            logger.info("Read source from [%s]->%s" % (self._source,member))
            handler=self.handler.open(member)
            iterable=handler
            if size>0:
                iterable=self._read_blocks(handler,size)
            for data in iterable:
                yield data
                
    def _read_blocks(self,handler,size):
        read_block=handler.read
        while True:
            data=read_block(size)
            if not data:
                break
            yield data
        
    def write(self,data,member=None,**kwargs):
        mode=kwargs.pop('mode',('w' if self._mode.startswith('r') else self._mode))
        if self.handler is None:
            self.open(mode=mode,**kwargs)
        if os.path.isfile(data):
            if member is None:
                member=data
            self.handler.write(data,member)
        else:
            if member is None:
                member=self._source[:-len(self.source_type)]
            self.handler.writestr(member,data)
        
    def compress(self,src,**kwargs):
        dest=self._source
        s=Source(src)
        for src in s.sources:
            logger.info("Compress from %s into [%s]" % (src,dest))
            self.write(src,**kwargs)
        self.close()
        
    def decompress(self,path=None,**kwargs):
        if path is None:
            path=os.path.dirname(self._source)
        if not os.path.exists(path):
           os.mkdir(path)
        mode=kwargs.pop('mode',self._mode)
        if self.handler is None:
            self.open(mode=mode,**kwargs)
        extract_member=self.handler.extract
        for member in self.members:
            logger.info('Decompress [%s]->%s into %s' % (self._source,member,path))
            extract_member(member,path=path)
        self.close()
        
class TarSource(BaseSource):
    
    def __init__(self,source):
        super(TarSource,self).__init__(source)
        self._member=None
        
    def set_member(self,member):
        self._member=member
        return self
    
    def get_member(self,members,member=0):
        return _get_member(members,member)
    
    @property
    def members(self):
        return self.handler.getnames()
    
    def open(self,**kwargs):
        import tarfile
        mode=kwargs.get('mode',self._mode)
        if 'mode' in kwargs: del kwargs['mode']
        if mode.startswith('r'):
            if self._source.endswith('.tar.gz'):
                mode='r:gz'
            elif self._source.endswith('.tar.bz2'):
                mode='r:bz2'
        elif mode.startswith('w'):
            if self._source.endswith('.tar.gz'):
                mode='w:gz'
            elif self._source.endswith('.tar.bz2'):
                mode='w:bz2'
        tar=tarfile.open(self._source,mode=mode,**kwargs)
        self._handler=tar
        return tar
        
    def read(self,**kwargs):
        mode=kwargs.pop('mode',None)
        member=kwargs.pop('member',self._member)
        size=kwargs.pop('size',self._block_size)
        if self.handler is None:
            mode=self._get_read_mode(mode,size)
            self.open(mode=mode,**kwargs)
        members=[self.get_member(self.members,member)] if member else self.members
        extract_member=self.handler.extractfile
        for member in members:
            logger.info("Read source from [%s]->%s" % (self._source,member))
            handler=extract_member(member)
            iterable=handler
            if size>0:
                iterable=self._read_blocks(handler,size)
            for data in iterable:
                yield data
                
    def _read_blocks(self,handler,size):
        read_block=handler.read
        while True:
            data=read_block(size)
            if not data:
                break
            yield data
        
    def write(self,data,**kwargs):
        mode=kwargs.pop('mode',('w' if self._mode.startswith('r') else self._mode))
        if self.handler is None:
            self.open(mode=mode,**kwargs)
        self.handler.add(data)
        
    def compress(self,src,**kwargs):
        dest=self._source
        s=Source(src)
        for src in s.sources:
            logger.info("Compress from %s into %s" % (src,dest))
            self.write(src,**kwargs)
        self.close()
        
    def decompress(self,path=None,**kwargs):
        if path is None:
            path=os.path.dirname(self._source)
        mode=kwargs.pop('mode',self._mode)
        if self.handler is None:
            self.open(mode=mode,**kwargs)
        extract_member=self.handler.extract
        for member in self.members:
            logger.info('Decompress [%s]->%s into %s' % (self._source,member,path))
            extract_member(member,path=path)
        self.close()
    
    @property
    def source_type(self):
        st='.TAR'
        if self._source.endswith('.tar.gz'):
            st+='.GZ'
        elif self._source.endswith('.tar.bz2'):
            st+='.BZ2'
        self._source_type=st
        return self._source_type
    
class ExcelSource(BaseSource):
    
    def __init__(self,source):
        super(ExcelSource,self).__init__(source)
        self._source_type='.EXCEL'
        self._member=None
        
    def set_member(self,member):
        self._member=member
        return self
    
    @property
    def members(self):
        return self.handler.sheets()
        
    def default_line_func(self,line):
        return [unicode(field) for field in line]
        
    def get_member(self,members,member):
        default_member=members[0]
        if isinstance(member,int):
            if 0<=member<len(members):
                return members[member]
            return default_member
        elif isinstance(member,basestring):
            ms=[m for m in members if m.name.lower()==member.lower()]
            if len(ms)>0:
                return ms[0]
            return default_member
        return default_member
        
    def open(self,**kwargs):
        import xlrd,xlwt
        mode=kwargs.get('mode',self._mode)
        member=kwargs.pop('member',self._member)
        if mode.startswith('r'):
            excel=xlrd.open_workbook(self._source)
        elif mode.startswith('w'):
            excel=xlwt.Workbook()
        self._handler=excel
        return excel
    
    def read(self,**kwargs):
        mode=kwargs.pop('mode',None)
        member=kwargs.pop('member',self._member)
        size=kwargs.pop('size',self._block_size)
        if self.handler is None:
            mode=self._get_read_mode(mode,size)
            self.open(mode=mode,**kwargs)
        members=[self.get_member(self.members,member)] if member else self.members
        for sheet in members:
            logger.info("Read source from [%s]->%s" % (self._source,sheet.name))
            get_row=sheet.row_values
            for idx in range(sheet.nrows):
                yield get_row(idx)
                
    def decode_field(self,field,coding='utf8'):
        if isinstance(field,unicode):
            return field
        return field.decode(coding)
    
    def write(self,data,**kwargs):
        self.save(data,**kwargs)
        
    def save(self,src,**kwargs):
        sep=kwargs.pop('sep',self._sep)
        coding=kwargs.pop('coding',self._coding)
        if self.handler is None:
            self.open(mode='w',**kwargs)
        excel=self.handler
        s=Source(src)
        for obj in s.objs:
            if obj.is_sql or obj.is_url:
                sheet_name='%s_%s' % (obj.source_type[1:].lower(),str(abs(hash(obj._source))))
            else:
                sheet_name=obj._source
            sheet=excel.add_sheet(sheet_name)
            write_row=sheet.write
            for row,line in enumerate(obj.read(**kwargs)):
                if isinstance(line,basestring):
                    fields=line.split(sep)
                else:
                    fields=line
                for col,field in enumerate(fields):
                    write_row(row,col,self.decode_field(field,coding))
        excel.save(self._source)
        
class StdStreamSource(BaseSource):
    
    def __init__(self,source=None):
        super(StdStreamSource,self).__init__(source)
        self._source_type='.STD'
        
    def open(self,**kwargs):
        mode=kwargs.get('mode',self._mode)
        if mode.startswith('r'):
            f=sys.stdin
        elif mode.startswith('w'):
            f=sys.stdout
        self._handler=f
        return f
    
class UrlSource(BaseSource):
    
    def __init__(self,source):
        super(UrlSource,self).__init__(source)
        self._source_type='.URL'
        
    def open(self,**kwargs):
        import urllib2
        mode=kwargs.pop('mode','r')
        f=urllib2.urlopen(self._source,**kwargs)
        self._handler=f
        return f
    
    def write(self,*args,**kwargs):
        pass
    
class SqlSource(BaseSource):
    def __init__(self,source):
        super(SqlSource,self).__init__(source)
        self._source_type='.SQL'
        self._dbc=None
        
    def set_dbc(self,dbc):
        self._dbc=dbc
        return self
        
    @property
    def dbs(self):
        from data.db.DBC import dbc
        return dbc.keys()
    
    def default_line_func(self,line):
        return [(str(field) if field is not None else '') for field in line]
    
    def get_info(self):
        source=self._source
        regex=re.compile('^(?:select|show)\s+(?:.+?\s+from\s+([^\s]+))?',re.I|re.MULTILINE)
        m=regex.match(source)
        dbs=self.dbs
        db=None
        info={}
        if m:
            table=m.group(1)
            if not table:
                table=None
            elif table.find('.')>-1:
                _db,_table=table.split('.')
                if _db in dbs:
                    db=_db
                    source=re.sub(table,_table,source)
                    table=_table
        else:
            table=None
        info['source']=source
        info['db']=db
        info['table']=table
        return info
    
    def get_fields(self):
        info=self.get_info()
        db=info['db']
        if db is None:
            raise Exception("DBC must be in SQL,just like SELECT * FROM dbc.table!")
        sql=info['source']
        from data.db.DBI import DBI,dbc
        dbi=DBI(**dbc[db])
        dbi.execute(sql)
        fields=dbi.fields()
        dbi.close()
        return fields
    
    def open(self,**kwargs):
        from data.db.DBI import DBI,dbc
        mode=kwargs.pop('mode','r')
        info=self.get_info()
        source=info['source']
        db=info['db'] or kwargs.pop('db') or self._dbc
        self.set_dbc(self._dbc)
        if mode.startswith('r'):
            dbi=DBI(dbc=db)
            if 'has_fields' in kwargs and kwargs['has_fields']:
                has_fields=True
            else:
                has_fields=False
                kwargs['has_fields']=True
            rows=dbi.fetch(source,**kwargs)
            fields=rows.next()
            def get_rows():
                if has_fields:
                    yield fields
                for row in rows:
                    yield row
		dbi.close()
            self._handler=get_rows()
            return self._handler
        
    def write(self,*args,**kwargs):
        pass
    
class StrSource(BaseSource):
    def __init__(self,source=None):
        super(StrSource,self).__init__(source)
        self._source_type='.STR'
        self._buffer=None
        
    def open(self,**kwargs):
        import StringIO
        mode=kwargs.get('mode',self._mode)
        if mode.startswith('r'):
            if self._source is not None:
                self._buffer=StringIO.StringIO(self._source)
            else:
                raise Exception('No string data supplied')
        elif mode.startswith('w'):
            if self._buffer is not None:
                self._buffer.close()
            self._buffer=StringIO.StringIO()
        elif mode.startswith('a'):
            if self._buffer is None:
                self._buffer=StringIO.StringIO()
        self._handler=self._buffer
        return self._buffer
        
    @property
    def value(self):
        if self._buffer is not None:
            return self._buffer.getvalue()
        return None
    
class JsonSource(BaseSource):
    
    def __init__(self,source):
        super(JsonSource,self).__init__(source)
        self._source_type='.JSON'
        self._fp=None
        
    def open(self,**kwargs):
        mode=kwargs.pop('mode','r')
        import json
        self._handler=json
        if mode=='r':
            self._fp=open(self._source,'r')
        else:
            self._fp=open(self._source,'w')
        return json
    
    def close(self):
        super(JsonSource,self).close()
        if self._fp:
            self._fp.close()
            
    def read(self,**kwargs):
        mode=kwargs.pop('mode','r')
        if self.handler is None:
            self.open(mode=mode)
        yield self.handler.load(self._fp,**kwargs)
    
    def write(self,data,**kwargs):
        mode=kwargs.pop('mode','w')
        if self.handler is None:
            self.open(mode=mode)
        self.handler.dump(data,self._fp,**kwargs)
    
class PickleSource(BaseSource):
    
    def __init__(self,source):
        super(PickleSource,self).__init__(source)
        self._source_type='.PICKLE'
        self._fp=None
        
    def open(self,**kwargs):
        try:
            import cPickle as pickle
        except ImportError:
            import pickle
        mode=kwargs.pop('mode','r')
        self._handler=pickle
        if mode=='r':
            self._fp=open(self._source,'r')
        else:
            self._fp=open(self._source,'w')
        return pickle
    
    def close(self):
        super(PickleSource,self).close()
        if self._fp:
            self._fp.close()
    
    def read(self,**kwargs):
        mode=kwargs.pop('mode','r')
        if self.handler is None:
            self.open(mode=mode)
        yield self.handler.load(self._fp,**kwargs)
    
    def write(self,data,**kwargs):
        mode=kwargs.pop('mode','w')
        if self.handler is None:
            self.open(mode=mode)
        self.handler.dump(data,self._fp,**kwargs)
        
class ShellSource(BaseSource):
    
    def __init__(self,source):
        super(ShellSource,self).__init__(source)
        self._source_type='.SHELL'
        
    def open(self,**kwargs):
        from data.util.Shell import Shell
        shell=Shell(self._source)
        self._handler=shell
        return shell
    
    def read(self,**kwargs):
        if self.handler is None:
            self.open(**kwargs)
        for data in self.handler.outs():
            yield data
    
    def write(self,*args,**kwargs):
        pass
    
class HiveSource(BaseSource):
    def __init__(self,source):
        super(HiveSource,self).__init__(source)
        self._source_type='.HIVE'
        
    def open(self,**kwargs):
        from data.db.Hive import Hive
        hive=Hive()
        hive.add_sql(self._source)
        self._handler=hive
        return self._handler
    
    def read(self,**kwargs):
        if self.handler is None:
            self.open(**kwargs)
        for data in self.handler.fetch():
            yield data
    
    def write(self,*args,**kwargs):
        pass
        
def get_sources(source):
    sources=[]
    if isinstance(source,basestring):
        if os.path.isdir(source):
            for src in os.listdir(source):
                if src=='.' or src=='..':
                    continue
                sources.append(os.path.join(source,src))
        else:
            src=glob.glob(source)
            if not src:
                sources.append(source)
            else:
                sources.extend(src)
    elif isinstance(source,(tuple,list)):
        for src in source:
            sources.extend(get_sources(src))
    else:
        sources.append(source)
    sources.sort()
    return sources

source_drivers=dict((k.split('Source')[0].lower(),v) for k,v in locals().items() if k.endswith('Source'))

class Source(object):
    
    def __init__(self,source=None):
        self._source=self._get_source(source)
        self._driver=None
        self._obj=None
	self._objs=[]
        
    def _get_source(self,source):
        if source is None:
            return source
        if isinstance(source,basestring):
            return source.strip()
        return source
        
    def get_source(self):
        return self._source
    
    def set_source(self,source):
        self._source=self._get_source(source)
        self._obj=None
        return self
    
    @property
    def sources(self):
        return get_sources(self._source)
        
    def __getattr__(self,name):
        if not hasattr(self,name):
            setattr(self,name,getattr(self.obj,name))
        return self.__dict__.get(name)
        
    def set_driver(self,driver):
        assert driver in source_drivers,'No such driver %s' % driver
        self._driver=driver
        self._obj=None
        return self
    
    def get_driver(self):
        return self._driver
        
    @property
    def is_dir(self):
        if isinstance(self._source,basestring):
            return os.path.isdir(self._source)
        return False
        
    def get_obj(self):
        if self._driver is not None:
            return source_drivers.get(self._driver)(self._source)
        if isinstance(self._source,basestring):
            if self._source.startswith(('http://','https://','ftp://')):
                return UrlSource(self._source)
            elif self._source.endswith('.tar.gz'):
                return TarSource(self._source)
            elif self._source.endswith('.tar.bz2'):
                return TarSource(self._source)
            elif self._source.endswith('.tar'):
                return TarSource(self._source)
            elif self._source.endswith('.gz'):
                return GzipSource(self._source)
            elif self._source.endswith('.bz2'):
                return BZ2Source(self._source)
            elif self._source.endswith('.zip'):
                return ZipSource(self._source)
            elif re.match(r'^(?:select|show)\s',self._source,re.I|re.MULTILINE):
                return SqlSource(self._source)
            elif self._source.endswith(('.xls','.xlsx')):
                return ExcelSource(self._source)
            elif self._source.endswith('.json'):
                return JsonSource(self._source)
            elif self._source.endswith('.pickle'):
                return PickleSource(self._source)
            else:
                return FileSource(self._source)
        elif isinstance(self._source,BaseSource):
            return self._source
        elif self._source is None:
            return StdStreamSource()
        else:
            return self._source
        
    @property
    def source(self):
        return self._source
    
    @property
    def obj(self):
        if self._obj is None:
            self._obj=self.get_obj()
        return self._obj
    
    def __get_setted_attrs(self):
	setted_attrs=set()
        for driver,cls in source_drivers.items():
            for attr in dir(cls):
                if attr.startswith('set_'):
                    attr=attr.split('set')[1]
                    setted_attrs.add(attr)
        return setted_attrs
    
    @property
    def objs(self):
	if self._objs:
            return self._objs
        objs=[]
        for src in self.sources:
            s=Source(src)
            for attr in self.__get_setted_attrs():
                if attr in self.__dict__:
                    setattr(s.obj,attr,self.__dict__.get(attr))
            objs.append(s.obj)
        self._objs=objs
        return self._objs	
 
    def read(self,**kwargs):
        for obj in self.objs:
            kw=copy.deepcopy(kwargs)
            for data in obj.read(**kw):
                yield data
                
    def scan(self,**kwargs):
        for obj in self.objs:
            kw=copy.deepcopy(kwargs)
            obj.scan(**kw)
           
    def close(self):
        for obj in self.objs:
            obj.close()
             
