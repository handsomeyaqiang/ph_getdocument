#!/usr/bin/env python
from data.util.Error import ImplementError

class IO(object):
    
    def __init__(self,handler=None,**kwargs):
        self.handler=handler
        self.kwargs=kwargs
    
    def read(self,*args,**kwargs):
        raise ImplementError
    
    def write(self,*args,**kwargs):
        raise ImplementError
    
    def close(self):
        if hasattr(self.handler,'close') and callable(self.handler.close):
            self.handler.close()
            