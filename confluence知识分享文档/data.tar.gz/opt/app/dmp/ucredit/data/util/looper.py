#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys,os
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
from data.util.Time import Time

drivers=dict(
    py='python',
    pl='perl',
    pm='perl',
    sh='sh',
    jar='hadoop jar',
    php='php',
)

def _do_sched_job(name,tx_time):
    from data.scheduler.conf import conf
    from data.scheduler.worker import Asker
    asker=Asker(conf.master_host,conf.master_port)
    job=asker.get_job(name,out_style='to_object')
    if job is None:
        raise Exception("No such {job}".format(job=name))
    job.setup(tx_time=tx_time,path=None)
    job.execute()
    exit_code=job.record.return_code
    return exit_code

def _do_script_job(job,tx_time):
    suffix=job.split('.')[-1]
    driver=drivers.get(suffix)
    if driver is None:
        raise Exception("No such {job}'s driver".format(job=job))
    cmd="{driver} {job} {tx_time}".format(driver=driver,job=job,tx_time=tx_time)
    return os.system(cmd)

def do_job(job,tx_time):
    if job.find('.')>-1:
        return _do_script_job(job,tx_time)
    else:
        return _do_sched_job(job,tx_time)
    
def _parallel_do(job,tx_times,parallel):
    from data.util.Processes import ProcessPool
    pp=ProcessPool(parallel)
    for tx_time in tx_times:
        pp.put(do_job,job,tx_time)
    pp.wait()
    
def _seq_do(job,tx_times):
    for tx_time in tx_times:
        do_job(job,tx_time)
        
usage="""
****************************************************************
looper script|job [start_txtime] [stop_txtime] [parallel]
****************************************************************
script       script.py,script.pl,script.sh,...,etc
job          sched job name
start_txtime start tx_time, default is yesterday, like yyyymmdd
stop_txtime  stop tx_time, default is start_txtime
parallel     parallel process number, default is 4
""".strip()

def loop(job,start_txtime=Time.yesterday(sep=''),stop_txtime=None,parallel=4):
    tx_times=list(Time.txtime_range(start_txtime,stop_txtime))
    if int(parallel):
        _parallel_do(job,tx_times,int(parallel))
    else:
        _seq_do(job,tx_times)
        
def main():
    if len(sys.argv)<2:
        print usage
        sys.exit()
    else:
        loop(*sys.argv[1:])
    
if __name__ == '__main__':
    main()
    
