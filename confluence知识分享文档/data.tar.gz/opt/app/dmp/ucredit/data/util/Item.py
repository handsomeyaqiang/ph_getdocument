#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys

class Item(object):
    encoding=sys.getfilesystemencoding()
    decoding='utf-8'
    field_sep='\t'
    line_sep='\n'
    db=None
    table=None
    attrs=()
    pk=None
    
    def __init__(self,**kwargs):
        if not self.attrs:
            self.attrs=tuple(k for k,v in sorted(kwargs.items()))
        for attr in self.attrs:
            setattr(self,attr,kwargs.get(attr))
        
    @classmethod
    def from_dict(cls,dict):
        return cls(**dict)
    
    @classmethod
    def from_list(cls,list):
        return cls(**dict(zip(cls.attrs,list)))
        
    @classmethod
    def from_tuple(cls,tuple):
        return cls.from_list(tuple)
        
    @classmethod
    def from_string(cls,str,sep=None):
        sep=cls.field_sep if sep is None else sep
        return cls.from_list(str.split(sep))
    
    @staticmethod
    def _get_where_expr(where):
        def get_value(v):
            if v is None:
                return ' IS NULL'
            if isinstance(v,basestring):
                if v.find('*')>-1:
                    return ' LIKE "{0}"'.format(v.replace('*','%'))
            return '='+Item.repr_value(v,False)
        return ' AND '.join('`{k}`{v}'.format(k=k,v=get_value(v)) for k,v in where.items())
    
    @classmethod
    def from_table(cls,fields=(),**where):
        assert cls.db is not None,"Must set db at first"
        assert cls.table is not None,"Must set table at first"
        if not fields:
            fields="`,`".join(cls.attrs)
        else:
            fields="`,`".join(fields)
        sql="SELECT `{fields}` FROM `{table}` ".format(fields=fields,table=cls.table)
        if where:
            sql+="WHERE "+cls._get_where_expr(where)
        print sql
        items=[]
        rows=cls.db.fetch(sql,out_style='to_dict')
        for row in rows:
            item=cls(**row)
            items.append(item)
        cls.db.close()
        return items
    
    @classmethod
    def from_file(cls,file,sep=None):
        sep=cls.field_sep if sep is None else sep
        items=[]
        f=open(file) if file is not sys.stdin else file
        for line in f:
            row=line.rstrip(cls.line_sep).split(sep)
            item=cls(dict(cls.attrs,row))
            items.append(item)
        if file is not sys.stdin:
            f.close()
        return items
    
    @classmethod
    def from_stdin(cls,sep=None):
        return cls.from_file(sys.stdin,sep)
    
    def update(self,**kwargs):
        self.__dict__.update(dict((k,v) for k,v in kwargs.items() if k in self.attrs))
        return self
    
    def to_object(self):
        return self
    
    def to_dict(self):
        return dict((k,self.get(k)) for k in self.attrs)
    
    def to_list(self):
        return list(self.get(k) for k in self.attrs)
        
    def to_tuple(self):
        return tuple(self.to_list())
        
    def to_string(self,sep=None):
        sep=self.field_sep if sep is None else sep
        return sep.join(map(str,self.to_list()))
    
    @staticmethod
    def encode(s,_from,to):
        if not isinstance(s,basestring):
            return s
        if isinstance(s,unicode):
            return s.encode(to)
        return s.decode(_from).encode(to)
    
    @staticmethod
    def to_decoding(s,_from=None):
        _from=_from or Item.encoding
        return Item.encode(s,_from,Item.decoding)
    
    @staticmethod
    def to_encoding(s,_from=None):
        _from=_from or Item.decoding
        return Item.encode(s,Item.decoding,Item.encoding)
    
    def to_table(self,close=True):
        assert self.db is not None,'Must set db at first'
        assert self.table is not None,"Must set table at first"
        if self.pk:
            pk=dict((k,self.to_decoding(self.get(k))) for k in self.pk)
            self.db.delete(self.table,conditions=pk)
        self.db.insert(self.table,fields=self.attrs,values=tuple(map(self.to_decoding,self.to_list())))
        if close:
            self.db.close()
            
    def to_file(self,out,sep=None):
        sep=self.field_sep if sep is None else sep
        out.write(sep.join(map(lambda s:self.to_encoding(s) if isinstance(s,basestring) else str(s),self.to_list()))+self.line_sep)
        return out
    
    def to_stdout(self,sep=None):
        return self.to_file(sys.stdout,sep)
        
    def get(self,key,default=None):
        return self.__getitem__(key,default)
    
    def set(self,key,value=None):
        return self.__setitem__(key,value)
        
    @staticmethod
    def repr_value(value,encode=True):
        if not isinstance(value,basestring):
            return repr(value)
        if encode:
            return '"%s"' % Item.to_encoding(value).replace('"',"'")
        return '"%s"' % value.replace('"',"'")
    
    def __str__(self):
        clsname=self.__class__.__name__
        attrs=', '.join('%s=%s'% (key,self.repr_value(self.get(key))) for key in self.attrs)
        return '{cls}({attrs})'.format(cls=clsname,attrs=attrs)
        
    def __getitem__(self,key,default=None):
        if key not in self.attrs:
            raise AttributeError
        return self.__dict__.get(key,default)
    
    def __setitem__(self,key,value):
        if key not in self.attrs:
            raise AttributeError
        if isinstance(value,basestring):
            if not isinstance(value,unicode):
                value=value.decode(self.decoding)
        self.__dict__[key]=value
        return value
    
    def __getattr__(self,key,default=None):
        if key not in self.attrs+('attrs',):
            raise AttributeError
        return self.__dict__.get(key,default)
    
    def __setattr__(self,key,value):
        if key not in self.attrs+('attrs',):
            raise AttributeError
        if isinstance(value,basestring):
            if not isinstance(value,unicode):
                value=value.decode(self.decoding)
        self.__dict__[key]=value
        return value
    
    def __repr__(self):
        return '<%s>' % self.__str__()
    
