#!/usr/bin/env python
#-*- coding:utf-8 -*-

import traceback
import os,sys,re,random
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
#sys.path.append('D:\\python_dev\\ucredit')
from data.db.DBI import DBI
from data.db.DBI import do_sql
from data.util.Time import Time
from data.util.Logger import logger
import time, MySQLdb
from data.scheduler.conf import conf

class TypeMapper(object):
    
    def __init__(self):
        self._mysql=None
        self._oracle=None
        self._sqlserver=None
        
    @property
    def mysql(self):
        if self._mysql is None:
            self._mysql={
                'tinyint':'tinyint',
                'smallint':'smallint',
                'mediumint':'int',
                'int':'int',
                'bit':'int',
                'integer':'int',
                'bigint':'bigint',
                'float':'float',
                'double':'double',
                'decimal':'double',
                'char':'string',
                'varchar':'string',
                'tinyblob':'string',
                'tinytext':'string',
                'blob':'string',
                'text':'string',
                'mediumblob':'string',
                'mediumtext':'string',
                'logngblob':'string',
                'longtext':'string',
                'date':'string',
                'time':'string',
                'year':'string',
                'datetime':'string',
                'timestamp':'string',
                'enum':'string',
                'set':'string'
                }
        return self._mysql
    @property
    def mysqlnew(self):
        if self._mysqlnew is None:
            self._mysqlnew={
                'tinyint':'tinyint',
                'smallint':'smallint',
                'mediumint':'mediumint',
                'int':'int',
                'bit':'bit',
                'integer':'integer',
                'bigint':'bigint',
                'float':'float',
                'double':'double',
                'decimal':'decimal',
                'char':'char',
                'varchar':'varchar',
                'tinyblob':'tinyblob',
                'tinytext':'tinytext',
                'blob':'blob',
                'text':'text',
                'mediumblob':'mediumblob',
                'mediumtext':'mediumtext',
                'logngblob':'logngblob',
                'longtext':'longtext',
                'date':'date',
                'time':'time',
                'year':'year',
                'datetime':'datetime',
                'timestamp':'timestamp',
                'enum':'enum',
                'set':'set'
                }
        return self._mysqlnew

    @property
    def oracle(self):
        if self._oracle is None:
            self._oracle={
                'char':'string',
                'varchar2':'string',
                'varchar':'string',
                'nchar':'string',
                'nvarchar2':'string',
                'date':'string',
                'long':'string',
                'raw':'string',
                'blob':'string',
                'clob':'string',
                'nclob':'string',
                'bfile':'string',
                'decimal':'double',
                'integer':'int',
                'float':'double',
                'real':'double',
                'number':'undefine',
                'int':'int',
                'double':'double',
                'bigint':'bigint',
                'datetime':'string'
                }
        return self._oracle
        
        @property
        def sqlserver(self):
            if self._sqlserver is None:
                self._sqlserver={
                    'bit':'smallint',
                    'int':'int',
                    'string':'string',
                    'bigint':'bigint',
                    'smallint':'smallint',
                    'tinyint':'tinyint',
                    'numeric':'double',
                    'decimal':'double',
                    'float':'double',
                    'real':'double',
                    'datetime':'string',
                    'date':'string',
                    'datetime2':'string',
                    'smalldatetime':'string',
                    'char':'string',
                    'varchar':'string',
                    'varchar2':'string',
                    'text':'string',
                    'nchar':'string',
                    'nvarchar':'string',
                    'ntext':'string',
                    'money':'double',
                    'smallmoney':'double',
                    'timestamp':'string',
                    'uniqueidentifier':'string',
                    'binary':'string',
                    'varbinary':'string',
                    'datetime':'string',
                    'xml':'string',
                    'image':'string',
                    'number':'bigint'
                    }
            return self._sqlserver
        
tm=TypeMapper()

class BaseMaker(object):
    def __init__(self,db,tb,port,ods_type, man):
        self._db=db
        self._tb=tb
        self._port=port
        self._ods_type=ods_type
        self._man=man
        self._date=Time.today()
        self._table_types=('stg','ods')
        self._extract_type=None
        self._stg_table=None
        self._ods_table=None
        self._fields=None
        self._creates=None
        self._table_comment=None
        
    @property
    def table_types(self):
        return self._table_types
        
    @property
    def extract_type(self):
        logger.info('extract_type')
        logger.info(self._extract_type)
        if self._extract_type is not None:
            return self._extract_type
        #0:no time field 1:one time field 2:more time field in accord with is_time
        time_fields=[]
        for field in self.fields:
            fname,ftype,_,_=field
            is_time=self.field_is_time(ftype)
            if is_time:
                time_fields.append(fname)
        if not time_fields:
            extract_type=0
        elif len(time_fields)==1 and (time_fields[0].lower()=='create_date' or time_fields[0].lower()=='create_time' or time_fields[0].lower()=='lastupdatetime' or time_fields[0].lower()=='last_update_time'):
            extract_type=1
        else:
            extract_type=2
        self._extract_type=extract_type
        logger.info(self._extract_type)
        return self._extract_type
    
    def get_table(self,tt):
        logger.info('get_table')
        et=self.extract_type
        if et==0:
            ets='a' if tt=='stg' else 'h'
        elif et==1:
            ets='i'
        else:
            ets='i' if tt=='stg' else 'h'
        if self._ods_type and tt=='ods':
            ets=self._ods_type
        table='%s_%s_%s_%s' % (tt[0],self._db.lower(),self._tb.lower(),ets)
        return table
    
    def field_is_time(self,ftype):
        is_time=False
        if ftype in ('timestamp','datetime','date'):
            is_time=True
        return is_time
    
    def _get_fields_from_db_source(self):
        sql="select db_ip,db_user,db_password from db_source_cfg where db_port=%s and db_name='%s' " % (self._port,self._db)
        dbi=DBI(dbc='db_dm_cfg')
        rows=list(dbi.fetch(sql))
        dbi.close()
        print rows
        assert len(rows)>0,'No such db source %s:%s' % (self._port,self._db)
        row=rows[0]
        dbc=dict(host=row[0],port=self._port,user=row[1],passwd=row[2],db=self._db)
        dbi=DBI(**dbc)
        rows=dbi.fetch("show full fields from %s" % self._tb)
        rows2=dbi.fetch("SHOW CREATE TABLE %s" % self._tb)
        fields=[]
        create_ts=[]
        for row in rows:
            field=row[0],row[1],row[8],row[4]
            fields.append(field)
        for row in rows2:
            create_t=row[1]
            create_ts.append(create_t)
        dbi.close()
        return fields,create_ts

    def _get_fields_from_table_column(self):
        sql="select column_name,column_type,column_comment,column_key from db_dmap.tb_table_column where stats_date='%s' and instance_name=%s and table_schema='%s' and table_name='%s'" % (self._date,self._port,self._db,self._tb)
        dbi=DBI(dbc='db_dm_cfg')
        rows=dbi.fetch(sql)
        rows=list(rows)
        dbi.close()
        return rows
    
    @property
    def fields(self,n=1):
        if self._fields is not None:
            return self._fields
#        self._fields=self._get_fields_from_table_column() or self._get_fields_from_db_source()
        self._fields,self._creates=self._get_fields_from_db_source()
        if not self._fields:
            raise Exception('No such table %s.%s' (self._db,self._tb))
        logger.info(self._fields)
        return self._fields

    def creates(self):
        if self._creates is not None:
            return self._creates
#        self._fields=self._get_fields_from_table_column() or self._get_fields_from_db_source()
        self._fields,self._creates=self._get_fields_from_db_source()
        if not self._creates:
            raise Exception('No such table %s.%s' (self._db,self._tb))
        logger.info(self._creates)
        return self._creates

    @property
    def stg_table(self):
        logger.info('gen stg')
        if self._stg_table is None:
            self._stg_table=self.get_table('stg')
        logger.info(self._stg_table)
        return self._stg_table
    
    @property
    def ods_table(self):
        if self._ods_table is None:
            self._ods_table=self.get_table('ods')
        return self._ods_table
    
    def get_table_comment(self):
        sql="SELECT table_comment FROM db_dmap.tb_table_size WHERE table_name='%s' AND db_name='%s' AND stats_date='%s' " % (self._tb,self._db,Time.today())
        try:
            dbi=DBI(dbc='db_dm_cfg')
            comment=str(list(dbi.fetch(sql))[0][0]).replace('\n',' ').replace("'","\\'").replace(',',' ').replace('.',':').replace(';',' ').replace('`','').replace('--',' ')
            dbi.close()
            return comment
        except:
            return ''
    
    @property
    def table_comment(self):
        if self._table_comment is None:
            self._table_comment=self.get_table_comment()
        return self._table_comment
    
    def make(self):
        pass

class SqlMaker(BaseMaker):
    
    def __init__(self,db,tb,port,ods_type, man):
        super(self.__class__,self).__init__(db,tb,port, ods_type, man)
        
    @property
    def make_table_sqls(self):
        create_sqls=self.creates()
        logger.info(create_sqls)
#        fields_info=[]
#        for row in field_detail:
#            fname,ftype,fcomment,_=row
#            fname=fname.lower()
#            ftype=ftype.lower().split('(')[0]
#            ftype=ftype.lower()
#            ftype=tm.mysqlnew.get(ftype,'string')
#            try:
#                fcomment=str(fcomment).strip().replace('\n',' ').replace("'","\\'").replace(',',' ').replace('.',':').replace(';',' ').replace('`','').replace('--',' ')
#            except Exception as msg:
#                logger.error(msg)
#                fcomment=''
#            fields_info.append("\`%s\` %s COMMENT '%s'" % (fname,ftype,fcomment))
        table_sqls=[]
        for tt in self._table_types:
            logger.info(tt)
            table=self.get_table(tt)
            if tt=='stg':
                self._stg_table=table
            else:
                self._ods_table=table
            logger.info(table)
#            table_sql="USE %s;\nCREATE TABLE IF NOT EXISTS %s (\n%s\n) " % (tt,table,',\n'.join(fields_info))
            source_str="CREATE TABLE `%s`" %(self._tb)
            target_str="USE %s;CREATE TABLE IF NOT EXISTS `%s`" % (tt,table)
            table_sql=create_sqls[0].replace(source_str,target_str)
            sql_lines=table_sql.split('\n')
            table_sql_f=''
            for sql_line in sql_lines:
                if sql_line.replace(' ','').startswith('CONSTRAINT'):
                    sql_line=''
                elif sql_line.replace(' ','').startswith('UNIQUE'):
                    sql_line=''
                elif sql_line.replace(' ','').startswith('KEY'):
                    sql_line=''
                elif sql_line.replace(' ','').startswith(')ENGINE='):
                    sql_line=') ENGINE=InnoDB DEFAULT CHARSET=utf8'
                else :sql_line=sql_line
                table_sql_f+=sql_line
            logger.info(table_sql_f)
#            table_sql=re.sub(r"CONSTRAINT ([\s\w\`\(\)])+\n", "",table_sql).replace(ttt,')) ENGINE')+';'
            #table_sql=table_sql_f.replace('),)','))')+';'
            table_sql_m1=table_sql_f.replace('),)','))')+';'
            table_sql_m2=table_sql_m1.replace('AUTO_INCREMENT','')
            table_sql=table_sql_m2.replace('DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP','')
            if tt=='stg':
                stg_str_dt='''`dt` datetime default null comment'分区字段',PRIMARY KEY'''
                table_sql=table_sql.replace('PRIMARY KEY',stg_str_dt)
                
                stg_str_pk=''',dt)) ENGINE'''
                table_sql=table_sql.replace(')) ENGINE',stg_str_pk)
                
                stg_str_partition='''DEFAULT CHARSET=utf8 PARTITION BY RANGE(to_days(dt)) (
                                    PARTITION p_20150801 VALUES LESS THAN (to_days('2015-08-01')),
                                    PARTITION p_20150802 VALUES LESS THAN (to_days('2015-08-02')),
                                    PARTITION p_20150803 VALUES LESS THAN (to_days('2015-08-03')),
                                    PARTITION p_20150804 VALUES LESS THAN (to_days('2015-08-04')),
                                    PARTITION p_20150805 VALUES LESS THAN (to_days('2015-08-05')),
                                    PARTITION p_20150806 VALUES LESS THAN (to_days('2015-08-06')),
                                    PARTITION p_20150807 VALUES LESS THAN (to_days('2015-08-07'))) '''
                table_sql=table_sql.replace('DEFAULT CHARSET=utf8',stg_str_partition)
            #table_sqls.append(table_sql)

            if tt=='ods' and table.endswith('h'):
                ods_str="""`start_date` date DEFAULT NULL comment '开始日期',
  `end_date` date DEFAULT NULL comment '结束日期',
  PRIMARY KEY"""
                table_sql=table_sql.replace('PRIMARY KEY',ods_str)
                ods_str_pk=''',start_date)) ENGINE'''
                table_sql=table_sql.replace(')) ENGINE',ods_str_pk)
            table_sqls.append(table_sql)
        return table_sqls
    
    def make_sql_files(self,path=None,drop=False):
        path=path or '.'
        sqls=sqls or self.make_table_sqls
        if not os.path.exists(path):
            os.makedirs(path)
        for idx,sql in enumerate(sqls):
            file_name='%s%s%s.sql' % (path,os.sep,('stg' if idx==0 else 'ods'))
            if drop:
                if os.path.exists(file_name):
                    os.remove(file_name)
            f=open(file_name,'a')
            f.write(sql)
            f.close()
            
    def make(self,path=None):
        if path:
            return self.make_sql_files(path)
        return self.make_table_sqls


class ScriptMaker(BaseMaker):
    
    def __init__(self, db, tb, port, ods_type, man):
        super(self.__class__,self).__init__(db, tb, port, ods_type, man)
        logger.info(db+tb+port+ods_type+man)
        self._ods_sql=None
        
    def get_extract_select_expr(self):
        field_detail=self.fields
        fields=map(lambda f:'`%s`' % (f[0]),field_detail)
        return 'SELECT %s, $data_dt' % (','.join(fields))
    
    def get_extract_where_expr(self):
        et=self.extract_type
        wheres=[]
        lastupdate=''
        for row in self.fields:
            fname,ftype,_,_=row
            if fname.lower().find('last')>=0 and fname.lower().find('update')>0 and fname.lower().find('time')>0 :
                lastupdate=fname
            is_time=self.field_is_time(ftype)
            if et!=0:
                if is_time:
                    where='`{time_field}`>=$data_dt AND `{time_field}`<$data_dt_next'.format(time_field=fname)
                    wheres.append(where)
        where=''
        if et!=0:
            if len(wheres)==1:
                where+='where %s' % (' OR '.join(wheres))
            elif len(wheres)>1:
                if lastupdate=='':
                    where='where %s' % (' OR '.join(map(lambda f:'(%s)' % (f),wheres)))
                else: where='where `'+lastupdate+'` >=$data_dt '
        return where
        
    def make_extract_sql(self):
        select=self.get_extract_select_expr()
        _from="FROM %s " % (self._tb)
        where=self.get_extract_where_expr()
        extract_sql='%s%s%s' % (select,_from,where)
        return extract_sql
    
    def make_ods_sql(self):
        ods_sql='''INSERT into ods.%s ''' %(self.ods_table)
        et=self.extract_type
        field_detail=self.fields
        fields=map(lambda f:["`%s`" % f[0]]+list(f[1:]),field_detail)
        field_names=map(lambda f:f[0],fields)
        '''modified by cuixiaoming 2015-08-11'''
        #取主关键字段的信息
        pk_fields=filter(lambda f:f[3] and f[3]=='PRI',fields)
        pk_fields=map(lambda f:f[0],pk_fields) if pk_fields else ['id']
        #增量删除数据的where条件
        for pk_del_field in pk_fields:
            pk_del_strs=[]
            pk_del_str='%s.%s=stg.%s'%(self.ods_table,pk_del_field,pk_del_field)
            pk_del_strs.append(pk_del_str)
        pk_del_strs=' AND '.join(pk_del_strs)
        print '@'*80
        #print 'pk_del_str',pk_del_strs
        #关键字关联条件
        pk_str=map(lambda f:'ods.%s=stg.%s' % (f,f),pk_fields)
        pk_str=' AND '.join(pk_str)
        #print 'pk_str',pk_str
        #全字段对�
        #print 'fields', fields
        #all_notpk_fields=filter(lambda f:f[3] and f[3]!='PRI',fields)
        all_notpk_fields=filter(lambda f:f[3]!='PRI',fields)
        #print 'all_notpk_fields', all_notpk_fields
        all_notpk_fields=map(lambda f:f[0],all_notpk_fields)
        #print 'all_notpk_fields', all_notpk_fields
        all_str=map(lambda f:'ods.%s<>stg.%s' % (f,f),all_notpk_fields)
        all_str=' OR '.join(all_str)
        #print 'all_str',all_str
        filed_str_stg = ',\n'.join(field_names)
        
        if self.ods_table.endswith('h'):
            mid_table=self.ods_table.replace('o_','mid_')
            drop_mid_table='drop table if exists mid.%s;'%(mid_table)
            create_mid_table='''CREATE TABLE IF NOT EXISTS  mid.%s as '''%(mid_table)
            create_mid_table+='''\nselect stg.* from 
                            (select * from stg.%s where dt = '{date}') stg 
                            left join ods.%s ods
                            on %s and ods.end_date = '2099-12-31'
                            where ods.%s is null or %s;
                            '''%(self.stg_table,self.ods_table,pk_str,pk_fields[0],all_str)
            update_sql='''update ods.%s ods,mid.%s stg set ods.end_date = '{date}' '''%(self.ods_table,mid_table)
            update_sql+='''\nwhere %s and ods.end_date = '2099-12-31' ;'''%(pk_str)
            delete_sql=''
            ods_sql+='''\n(%s ,start_date,end_date)
                        select %s, '{date}' ,'2099-12-31' from mid.%s;
                    '''%(filed_str_stg,filed_str_stg,mid_table)
            check_partion_sql='''select partition_name from information_schema.partitions 
where table_schema='stg' and table_name='%s' 
and partition_name = '''%(self.stg_table)
            drop_stg_partion='''alter table stg.%s drop partition '''%(self.stg_table)
            drop_days=15
            check_is_recover='''select count(1) from ods.%s where start_date >= '{date}'; '''%(self.ods_table)
            recover_delete='''delete from ods.%s where start_date >= '{date}';'''%(self.ods_table)
            recover_update='''update ods.%s set end_date = '2099-12-31' where end_date >='{date}' and end_date < '2099-12-31';'''%(self.ods_table)
        else:
            drop_mid_table=''
            create_mid_table=''
            update_sql=''
            delete_sql='''delete from ods.%s where exists  '''%(self.ods_table)
            delete_sql+='''(select 1 from stg.%s stg where %s and stg.dt='{date}' ); '''%(self.stg_table,pk_del_strs)
            ods_sql+='''\n(%s)
                        select %s from stg.%s where dt = '{date}';
                    '''%(filed_str_stg,filed_str_stg,self.stg_table)
            check_partion_sql='''select partition_name from information_schema.partitions 
where table_schema='stg' and table_name='%s' 
and partition_name = '''%(self.stg_table)
            drop_stg_partion='''alter table stg.%s drop partition '''%(self.stg_table)
            drop_days=7
            check_is_recover=''
            recover_delete=''
            recover_update=''
        #if et==0:
        #    ods_sql+='''\nSELECT %s\nFROM stg.%s\nWHERE dt='{date}' ''' %(',\n'.join(field_names),self.stg_table)
        #elif et==1:
        #    time_fields=map(lambda f:f[0],filter(lambda f:self.field_is_time(f[1]),fields))
        #    time_field=time_fields[0]
        #    ods_sql+='''\nSELECT %s\nFROM stg.%s\nWHERE dt='{date}' AND %s<date_add('{date}',1);''' % (',\n'.join(field_names),self.stg_table,time_field)
        #elif et==2:
        #    pk_fields=filter(lambda f:f[3] and f[3]=='PRI',fields)
        #    pk_fields=map(lambda f:f[0],pk_fields) if pk_fields else ['__id__']
        #    ods_sql+='''\nSELECT\n'''
        #    case_exprs=[]
        #    for field in field_names:
        #        case_expr="CASE WHEN C.{pk} IS NOT NULL THEN C.{field} ELSE H.{field} END {field}".format(pk=pk_fields[0],field=field)
        #        case_exprs.append(case_expr)
        #    ods_sql+='''%s''' % (",\n".join(case_exprs))
        #    pks=map(lambda f:'C.%s=H.%s' % (f,f),pk_fields)
        #    ods_sql+='''\nFROM
#(SELECT * FROM stg.%s WHERE dt='{date}') C
#FULL OUTER JOIN\n(SELECT * FROM ods.%s WHERE dt=date_add('{date}',-1)) H
#ON %s;'''%(self.stg_table,self.ods_table,' AND '.join(pks))
        return (drop_mid_table,create_mid_table,update_sql,
                delete_sql,ods_sql,
                check_partion_sql,drop_stg_partion,
                check_is_recover,recover_delete,
                recover_update, drop_days)
    
    @property
    def ods_sql(self):
        if self._ods_sql is None:
            self._ods_sql=self.make_ods_sql()
        return self._ods_sql
    
    def make_ods_script(self,path=None):
        logger.info(path)
        path=path or '.'
        script="""#!/usr/bin/env python
#-*- coding:utf-8 -*-
##=====================BELONGS===========================================
# **AUTHOR:           lixinguang
# **CREATED TIME:     2015-06-25
# **FUN DESC    :     基础数据层
# **MODIFIED BY :     lixinguang
# **MODIFTED TIME:    2015-06-25
# **MODIFTED CONTENT:
# **REVIEWED BY:      lixinguang
# **REVIEWED TIME:    2015-06-25
##===================META BEGIN=============================================
# **INPUT TABLE:  
# **MID TABLE :
# **DIM TABLE :
# **OUTPUT TABLE: 
##===================META END=============================================
import sys,os
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
from data.util.Time import Time
from data.db.DictDb import dictetl
from data.db.DBhandle import DBhandle
#from data.db.DBI import execute_sql
from datetime import datetime, timedelta
##===================VARIABLE===============================================
################################################################
data_dt=Time.date_format(sys.argv[1].split('.')[0].split('_')[-1]) if len(sys.argv)>1 else Time.yesterday()
################### SQL EDITE ##################################
##==================SQL BEGIN==============================================
##=================取新增和变化的数据######################################
SQL1='''%s'''.format(date=data_dt).strip()
##=================将变化的数据置为失效######################################
SQL2='''%s'''.format(date=data_dt).strip()

##=================delete data####################################
SQL3='''%s'''.format(date=data_dt).strip()
##=================插入新增和变化的数据#########################
SQL4='''%s'''.format(date=data_dt).strip()
##=================删除临时计算表######################################
SQL5='''%s'''.format(date=data_dt).strip()
##=================check partition exist========================================
P_SQL6='''%s'''.format(date=data_dt).strip()
##=================drop partition===================================
P_SQL7='''%s'''.format(date=data_dt).strip()
##===============check recover===================================
R_SQL8='''%s'''.format(date=data_dt).strip()
##===============recover delete===================================
R_SQL9='''%s'''.format(date=data_dt).strip()
##===============recover update===================================
R_SQL10='''%s'''.format(date=data_dt).strip()
##==================RUN SCRIPT==============================================
drop_days = int('''%s''')
p_dtime_old = datetime.strptime(data_dt, %s) - timedelta(days=drop_days)
p_dtime_old_str = p_dtime_old.strftime(%s)
partition_old_str = 'p_' + p_dtime_old_str
P_SQL6 = P_SQL6 + ''.join(["'", partition_old_str, "';"])
P_SQL7 = P_SQL7 + ' ' + partition_old_str + ";"
sqls=map(lambda r:r[1],sorted([(int(k.split('SQL')[1]),v) for k,v in locals().items() if k.startswith('SQL')],key=lambda r:r[0]))
def excSql(sql):
    #dbc=dictetl
    dbcur = DBhandle(dictetl)
    res = dbcur.execute(sql)
    dbcur.close()
    return res

def selectSql(sql):
    dbcur = DBhandle(dictetl)
    res = dbcur.select(sql)
    dbcur.close()
    return res[0][0]

def main():
    time=str(datetime.now()).replace('-','').replace(' ','.')
    print '['+time+']--------------Start Run Job'
    if R_SQL8:
        r_res = selectSql(R_SQL8)
    else:
        r_res = 0
    if int(r_res)>=1:
        print 'recover data first step: delete data'
        recover_count1 = excSql(R_SQL9)
        print R_SQL9
        print '--------------------删除数据'+str(recover_count1)+'条------------------'
        print 'recover data second step: update data'
        recover_count2 = excSql(R_SQL10)
        print R_SQL10
        print '--------------------更新数据'+str(recover_count2)+'条------------------'
    i=1
    for sql in sqls:
        time=str(datetime.now()).replace('-','').replace(' ','.')
        print '['+time+']--------------Process SQL['+str(i)+']'
        print sql
        res_count = 0
        if sql:
            res_count=excSql(sql)
        time=str(datetime.now()).replace('-','').replace(' ','.')
        print '['+time+']--------------END Process SQL['+str(i)+']'
        print '['+time+']--------------'+str(res_count)+'RECORDS REFERENCE-----------'
        i=i+1
    res = excSql(P_SQL6)
    if int(res)==1:
        excSql(P_SQL7)
    print '['+time+']--------------Finish Process JOB'
    
if __name__ == '__main__':
    main()""" %(self.ods_sql[0], self.ods_sql[1],
                self.ods_sql[2], self.ods_sql[3],
                self.ods_sql[4], self.ods_sql[5],
                self.ods_sql[6], self.ods_sql[7],
                self.ods_sql[8], self.ods_sql[9],
                self.ods_sql[10], '\'%Y-%m-%d\'', '\'%Y%m%d\'')
	script_file='%s%s%s.py' % (path,os.sep,self.ods_table)
        f=open(script_file,'w')
        f.write(script)
        f.close()
        return script_file   
 
    def make(self,path=None):
        if path is not None:
            return self.make_ods_script(path)
        return self.make_extract_sql()

def get_localhost():
    import socket,fcntl,struct
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ifname='em2'
    inet = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
    return socket.inet_ntoa(inet[20:24])
#    return socket.gethostbyname(socket.gethostname())

def get_realhost():
    import socket,fcntl,struct
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ifname='em2'
    inet = fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
    return socket.inet_ntoa(inet[20:24])
class TaskMaker(BaseMaker):
    
    def __init__(self,db,tb,port=3306, ods_type='a', man=''):
        super(self.__class__,self).__init__(db,tb,port, ods_type, man)
        self._port=port
        self._man=man
        self._dbi=DBI(dbc='db_dm_cfg')
        self._script_maker=ScriptMaker(self._db, self._tb, self._port, self._ods_type, self._man)
        logger.info('-------')

        self._ods_path=os.environ['DMP_HOME']+'/sched/genscript'
#        self._ods_path='D:\\python_dev\\dwetl\\APP\\ODS\\bin'
        self._job_home=os.environ['DMP_HOME']+'/sched/jobs'
#        self._job_home='D:\\python_dev\\sched\\jobs'
        
    def create_dw_table(self):
        try:
            sm=SqlMaker(self._db, self._tb, self._port, self._ods_type, self._man)
            table_sqls=sm.make()
            logger.info(table_sqls[0])
            logger.info(table_sqls[1])
            print '='*80
            print '0 table_sqls',table_sqls[0]
            print '1 table_sqls',table_sqls[1]
#此处连接线上数仓数据库
            conn=MySQLdb.connect(host='172.16.2.103',port=3306,user='diaodu',passwd='zjKSt0QQrEIMsjm',db='stg',charset="utf8")
            cursor = conn.cursor()
            n = cursor.execute(table_sqls[0])
            cursor.close()
            cursor = conn.cursor()
            n = cursor.execute(table_sqls[1])
            logger.info(n)
            print '&'*80
            cursor.close()
            conn.close()
            logger.info('create mysql table success.')
        except Exception as msg:
            traceback.print_exc()
            logger.error('create mysql table error: %s' % msg)
            sys.exit(1)
        
    def create_ods_script(self,path=None):
        try:
            logger.info('================')
            res=self._script_maker.make(path)
            logger.info('create ods script success.')
            return res
        except Exception as msg:
            traceback.print_exc()
            logger.error('create ods script error: %s' % msg)
            sys.exit(1)
        
    def get_job(self,tt):
        job=self.stg_table.upper() if tt=='stg' else self.ods_table.upper()
        return job
    
    def _get_src_id(self):
        sql="SELECT dbsrc_id FROM db_source_cfg WHERE db_name='%s' AND db_port=%s" % (self._db,self._port)
        try:
            return int(list(self._dbi.fetch(sql))[0][0])
        except:
            return 0
        
    def _insert_record(self,table,record,fields=None,cdt=None):
        try:
            self._dbi.delete(table,conditions=cdt)
            self._dbi.insert(table,fields=fields,values=record)
            logger.info('table %s insert record success.' % (table))
        except Exception,e:
            logger.error('table %s insert record error: %s' % (table,str(e)))
            sys.exit(1)
        
    def _add_task_cfg(self,tt='stg'):
        table='task_info_cfg'
        fields='task_name,task_type_id,client_port,tbl_name,dbsrc_id,hive_db_name,hive_tbl_name,task_sql_all,task_sql_filter,is_increment,exec_cfg_id,step_lines,dbtgt_id'.split(',')
        select=self._script_maker.get_extract_select_expr()
        sql_all=select+' FROM %s ' % (self._tb)
        where=self._script_maker.get_extract_where_expr()
        record=(self.stg_table.upper(),0,0,self._tb,self._get_src_id(),tt,self.stg_table,sql_all,where,0,1,3000,217)
        self._insert_record(table,record,fields,cdt=dict(task_name=self.stg_table.upper()))

    def _add_sched_job(self,tt='stg'):
        table='sched_job'
        logger.info(self._man)
        job=self.get_job(tt).lower()
        fields='name,cmd,timer,host,retries,path,group,man'.split(',')
        if tt=='stg':
            cmd='python %s/DWExtract.py ${name}_${txdate}' % (self._job_home)
            hour=random.sample([0,1,2],1)[0]
            minute=random.randint(0,59)
            timer='%s %s * * *' % (minute,hour)
        else:
            cmd='python {path}/{job}.py '.format(path=self._job_home,job=job)
            cmd+='''${txdate}'''
            timer=None
        record_path=conf.LOGS_PATH+'/${txdate}'
        record=(job,cmd,timer,get_realhost(),3,record_path,tt,self._man)
        self._insert_record(table,record,fields,cdt=dict(name=job))
        
    def _add_sched_dependency_job(self,tt='ods'):
        table='sched_job_dependency'
        job=self.get_job(tt).lower()
        fields='name,dependency'.split(',')
        record=(job,self.stg_table)
        self._insert_record(table,record,fields,cdt=dict(name=job,dependency=self.stg_table))
        
    def add_stg_task(self):
        tt='stg'
        self._add_task_cfg(tt)
        self._add_sched_job(tt)
        logger.info('add stg task success.')
    
    def add_ods_task(self):
        tt='ods'
        self._add_sched_job(tt)
        self._add_sched_dependency_job(tt)
        logger.info('add ods task success.')
        
    def add_task(self):
        self.add_stg_task()
        self.add_ods_task()
        
    def _dist_script(self,script):
        dmp_home=os.environ['DMP_HOME']
        cmd='python '+dmp_home+'/ucredit/data/util/dist.py scp -P 22222 %s %s' % (script,self._job_home)
        os.system(cmd)
        
    def make(self):
        self.create_dw_table()
        logger.info(self._ods_path)
        script=self.create_ods_script(self._ods_path)
        self.add_task()
        logger.info(script)
        self._dist_script(script)
        
    def close(self):
        self._dbi.close()
        
def add_task(task):
    if isinstance(task,basestring):
        task=task.strip()
        if not task:
            return
        parts=re.split(',|\t|\s',task)
        if len(parts)<5:
            parts+=['']
        port, db, tb, ods_type, man=parts[:5]
    elif isinstance(task,(tuple,list)):
        port,db,tb, ods_type, man=task if len(task)==5 else list(task)+['']
        print port,db,tb,ods_type,man
    elif isinstance(task,dict):
        port,db,tb,man=map(lambda key:task.get(key,''),'port,db,tb,man'.split(','))
    else:
        raise Exception('wrong task type,must be string,tuple,list,dict.')
    #
    #print db+' '+tb+' '+port+' '+man
    tm=TaskMaker(db=db,tb=tb,port=port,ods_type=ods_type, man=man)
    tm.make()
    tm.close()
    
def add_tasks(tasks):
    if isinstance(tasks,basestring):
        if os.path.exists(tasks):
            from data.io.Source import Source
            s=Source(tasks)
            tasks=s.read()
        else:
            tasks=tasks.splitlines()
    elif isinstance(tasks,(tuple,list)):
        tasks=tasks
    else:
        raise Exception('wrong tasks %s,must be file,string,tuple or list' % str(tasks))
    for task in tasks:
        add_task(task)
        
def main():
    assert len(sys.argv)>1,'arg task needed.'
    tasks=[sys.argv[1:]] if len(sys.argv)>2 else sys.argv[1]
    print tasks
    add_tasks(tasks)
    
if __name__ == '__main__':
    main()
    
