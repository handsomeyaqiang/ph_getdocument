#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys
import os
sys.path.append(os.environ['DMP_HOME']+'/ucredit')
from data.util.Shell import ssh,scp
from data.util.Logger import logger
#hosts='10.10.64.31,41,90,181-189,190-192'
hosts='172.16.2.102,104,107'
args=sys.argv[:]

def show_usage():
    print 'python %s scp -P 22222 [from to]|run|host cmds' % args[0]
    sys.exit()
    
def do_scp(hosts,from_path,to_path):
    return scp.raise_error(False).connect(hosts).push(from_path,to_path)

def do_ssh(hosts,cmd):
    return ssh.raise_error(False).connect(hosts).execute(cmd).run()

def main():
    if len(args)<2:
        show_usage()
    elif len(args)==2 and args[1]=='scp':
        path1=os.environ['DMP_HOME']+'/ucredit'
        path2=os.environ['DMP_HOME']
        do_scp(hosts,path1,path2)
    elif len(args)>=3:
        if args[1]=='scp':
            from_path=args[4]
            if from_path.find('/')==-1:
                from_path=os.path.join(os.getcwd(),from_path)
            to_path=len(args)>3 and args[5] or os.path.dirname(from_path)
            logger.info(from_path+''+to_path)
            do_scp(hosts,from_path,to_path)
        elif args[1]=='run':
            do_ssh(hosts,' '.join(args[2:]))
        else:
            do_ssh(args[1],' '.join(args[2:]))
    else:
        show_usage()
        
if __name__ == '__main__':
    main()
    
