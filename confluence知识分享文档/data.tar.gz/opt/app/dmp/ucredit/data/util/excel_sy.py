#!/usr/bin/python27
#coding=utf-8
import os
import sys
import xlsxwriter

reload(sys)
sys.setdefaultencoding('utf-8')

#初始化workbook，生成sheet列表，设置各个sheet的格式
def init_workbook(workbook_name,sheet_names=[],sheet_title_list={}):
    workbook = xlsxwriter.Workbook(workbook_name)
    headerFormat = workbook.add_format({
            'border':1,
            'align':'center',
            'valign':'vcenter',
            'fg_color':'#366092',
            'font_color':'#FFFFFF',
            'font_size':'12'
    })

    #key为sheet名称，value为sheet本身
    sheet_list = {}
    for sheet_name in  sheet_names:
        sheet = workbook.add_worksheet(sheet_name)
        sheet_title = sheet_title_list.get(sheet_name)
        for i in range(len(sheet_title)):
          #设置每一个标题列的长度为标题字符的长度 
          if i/26 == 0: 
             col = chr(ord('A')+i)
          else: 
             w = chr(ord('A')+i/26-1)
             col = w+chr(ord('A')+i%26)
          print col
          sheet.set_column(col+':'+col,30)
          cell = col + '1'
          sheet.write(cell,sheet_title[i],headerFormat)
        sheet_list.__setitem__(sheet_name,sheet)
    return workbook,sheet_list
#填充数据到sheet中
def fill_sheet(sheet,data):
    for i in range(len(data)):
        for j in range(len(data[i])):
            if data[i][j]=='None':
                data[i][j] = ''
        sheet.write_row('A'+bytes(2+i),data[i])

