#coding=utf-8
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
class Email:
    mail_from = 'sendserver08@ucredit.com'
    mailto_list = ['cuixiaoming@ucredit.com','zhangqiang02@ucredit.com','tanjiefang@ucredit.com']
    mailcc_list = ['lixinguang@ucredit.com']
    mailbcc_list = []
    mail_host = 'owa.ucredit.com'
    mail_user = 'sendserver08'
    mail_pass = 'Thread@)!$'

    def __init__(self, mailto_list, mailcc_list, mailbcc_list):
        self.mailto_list = mailto_list
        self.mailcc_list = mailcc_list
        self.mailbcc_list = mailbcc_list

    def sendEmail(self, reportContent, subject, attachFileName):
        url = self.mail_host
        conn = smtplib.SMTP()
        conn.connect(url, 25)
        #conn.ehlo()
        #conn.starttls()
        conn.login(self.mail_user, self.mail_pass)
        message = MIMEMultipart()
        message['Subject'] = subject
        message['From'] = self.mail_from
        message['To'] = ';'.join(self.mailto_list)
        message['Cc'] = ';'.join(self.mailcc_list)
        message['Bcc'] = ';'.join(self.mailbcc_list)
        htmlTable = MIMEText(reportContent, 'html', 'utf-8')
        message.attach(htmlTable)
        print attachFileName
        excel = MIMEApplication(open(attachFileName, 'rb').read())
        #excel = MIMEText(open(attachFileName, 'rb').read(), 'base64', 'gb2312')
        excel.add_header('Content-Disposition', 'attachment', filename=str(attachFileName.split('/')[-1]))
        #excel.add_header('Content-Type', 'text/csv/zip')
        message.attach(excel)
        message['Accept-Language'] = 'zh-CN'
        message['Accept-Charset'] = 'ISO-8859-1,utf-8'
        conn.sendmail(self.mail_from, self.mailto_list + self.mailcc_list + self.mailbcc_list, message.as_string())
        conn.quit()
