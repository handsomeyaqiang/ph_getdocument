#!/usr/bin/env python
import os,sys
import errno

def errno_retries():
    errons=[errno.EINTR,errno.EAGAIN,errno.EWOULDBLOCK,errno.EINPROGRESS]
    for err in ["WSAEINTR","WSAEWOULDBLOCK","WSAEINPROGRESS"]:
        if hasattr(errno,err):
            errons.append(getattr(errno,err))
    return errons

ERRNO_RETRIES=errno_retries()


class Error(Exception):
    pass

class InterfaceError(Error):
    pass

class ImplementError(Error):
    def __init__(self,msg=None):
        if msg is None:
            msg='Not Implemented.'
        self.msg=msg
        
    def __str__(self):
        return repr(self.msg)

class ReadError(IOError):
    def __init__(self,msg=None):
        if msg is None:
            msg='Read error.'
        self.msg=msg
        
    def __str__(self):
        return repr(self.msg)

class WriteError(IOError):
    def __init__(self,msg=None):
        if msg is None:
            msg='Write error.'
        self.msg=msg
        
    def __str__(self):
        return repr(self.msg)

class NoTypeError(Error):
    def __init__(self,msg=None):
        if msg is None:
            msg='No corresponding type.'
        self.msg=msg
        
    def __str__(self):
        return repr(self.msg)
        
class ReadOnlyError(Error):
    pass

def throws(t,f,*a,**k):
    try:
        return [f(*a,**k)]
    except t:
        return []
        
