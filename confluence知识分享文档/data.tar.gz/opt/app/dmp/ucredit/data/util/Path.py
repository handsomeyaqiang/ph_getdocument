#!/usr/bin/env python
#-*- coding:utf-8 -*-


Path=dict(
    HIVE_PY='/opt/cloudera/parcels/CDH-4.3.0-1.cdh4.3.0.p0.22/lib/hive/lib/py',
)