#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os,sys
import threading
import multiprocessing
import traceback
import tempfile
import pstats
import time
import logging
import inspect
from threading import RLock
from data.util.Module import profile
from data.util.Time import Time
from data.util.Module import StringIO
from functools import wraps,partial

def timer(func):
    @wraps(func)
    def _timer(*args,**kwargs):
        func_name=func.__name__
        now=Time.timestamp()
        print "Func %s is started at %s." % (func_name,Time.now())
        result=func(*args,**kwargs)
        end=Time.timestamp()
        print "Func %s is ended at %s." % (func_name,Time.now())
        print "Func %s's total cost is %ss." % (func_name,end-now)
        return result
    return _timer

def counter(func):
    count=[0]
    @wraps(func)
    def _counter(*args,**kwargs):
        count[0]+=1
        func_name=func.__name__.capitalize()
        print "%s use %d count." % (func_name,count[0])
        result=func(*args,**kwargs)
        return result
    return _counter

def memorizer(func):
    cached={}
    @wraps(func)
    def _memorize(*args,**kwargs):
        key=(args,str(kwargs))
        if key not in cached:
            cached[key]=func(*args,**kwargs)
        return cached[key]
    return _memorize

cacher=memorizer

def watcher(func):
    seen={}
    @wraps(func)
    def watch(*args,**kwargs):
        key=(args,str(kwargs))
        if key not in seen:
            result=func(*args,**kwargs)
            seen[key]=result
        else:
            result=seen[key]
        return result
    return watch

def looper(mode='DAY'):
    mode=mode.upper()
    modes=['DAY','HOUR','DH']
    assert mode in modes,"Mode '%s' not in %s " % (mode,modes)
    def loop(func):
        t=Time()
        def loop_day(func,start_date,end_date,args,kwargs):
            date=int(start_date)
            start_date,end_date=int(start_date),int(end_date)
            while date>=start_date and date<=end_date:
                func(date,*args,**kwargs)
                date=int(t.date_add(date))
        def date_range(*args,**kwargs):
            start_date,end_date=None,None
            args=list(args)
            arg_num=len(args)
            if arg_num>=1:
                if arg_num==1:
                    date=args[0]
                    if t.is_date(date):
                        start_date=end_date=date
                        args.pop(0)
                elif arg_num>=2:
                    start,end=args[0],args[1]
                    if t.is_date(start):
                        start_date=start
                        args.pop(0)
                    if start_date and t.is_date(end):
                        end_date=end
                        args.pop(0)
                    else:
                        end_date=start_date
                if start_date and end_date:
                    return start_date,end_date,tuple(args),kwargs
            argv_num=len(sys.argv)
            if argv_num==1:
                start_date=end_date=t.yesterday(sep='')
            else:
                if argv_num==2:
                    start_date=end_date=t.date_format(sys.argv[1],sep='')
                elif argv_num>=3:
                    start_date,end_date=t.date_format(sys.argv[1],sep=''),t.date_format(sys.argv[2],sep='')
            return start_date,end_date,tuple(args),kwargs
        def loop_by_day(*args,**kwargs):
            start_date,end_date,args,kwargs=date_range(*args,**kwargs)
            loop_day(func,start_date,end_date,args,kwargs)
        def loop_hour(func,date,start_hour,end_hour,args,kwargs):
                start_hour=int(start_hour)
                end_hour=int(end_hour)
                assert start_hour>=0 and end_hour<=23,'Hour must be in range(0,24).'
                for hour in range(start_hour,end_hour+1):
                    hour=t.hour_format(hour)
                    func(date,hour,*args,**kwargs)
        def loop_by_hour(*args,**kwargs):
            date,start_hour,end_hour=None,None,None
            args=list(args)
            arg_num=len(args)
            if arg_num>=1:
                if arg_num==1:
                    date=args[0]
                    if t.is_date(date):
                        date=date
                        start_hour=end_hour=t.last_hour()
                        args.pop(0)
                    if not date:
                        return
                elif arg_num==2:
                    date,start=args[0],args[1]
                    if t.is_date(date):
                        date=date
                        args.pop(0)
                    if not date:
                        return 
                    if date and t.is_hour(start):
                        start_hour=end_hour=start
                        args.pop(0)
                    else:
                        end_hour=start_hour
                elif arg_num>=3:
                    date,start,end=args[0:3]
                    if t.is_date(date):
                        date=date
                        args.pop(0)
                    if not date:
                        return
                    if t.is_hour(start):
                        start_hour=start
                        args.pop(0)
                    else:
                        start_hour=t.last_hour()
                    if t.is_hour(end):
                        end_hour=end
                        args.pop(0)
                    else:
                        end_hour=start_hour
                if date and start_hour and end_hour:
                    loop_hour(func,date,start_hour,end_hour,tuple(args),kwargs)
                    return
            argv_num=len(sys.argv)
            if argv_num==1:
                date=t.yesterday(sep='')
                start_hour=end_hour=t.last_hour()
            elif argv_num==2:
                date=t.date_format(sys.argv[1],sep='')
                start_hour=end_hour=t.last_hour()
            elif argv_num==3:
                date=t.date_format(sys.argv[1],sep='')
                start_hour=end_hour=t.hour_format(sys.argv[2])
            else:
                date=t.date_format(sys.argv[1],sep='')
                start_hour=t.hour_format(sys.argv[2])
                end_hour=t.hour_format(sys.argv[3])
            loop_hour(func,date,start_hour,end_hour,tuple(args),kwargs)
        def loop_dh(func,start_date,end_date,args,kwargs):
            date=int(start_date)
            start_date,end_date=int(start_date),int(end_date)
            while date>=start_date and date<=end_date:
                for hour in range(0,24):
                    hour=t.hour_format(hour)
                    func(date,hour,*args,**kwargs)
                date=int(t.date_add(date,sep=''))
        def loop_by_dh(*args,**kwargs):
            start_date,end_date,args,kwargs=date_range(*args,**kwargs)
            loop_dh(func,start_date,end_date,args,kwargs)
            
        loop_dict=dict(
            DAY=loop_by_day,
            HOUR=loop_by_hour,
            DH=loop_by_dh,
        )
        @wraps(func)
        def run(*args,**kwargs):
            if mode in loop_dict:
                func=loop_dict[mode]
                func(*args,**kwargs)
        return run
    return loop

def date_looper(func=None,mode='DAY'):
    if func is None:
        return partial(date_looper,mode=mode)
    mode=mode.upper()
    modes=['DAY','HOUR','DH']
    assert mode in modes,"Mode '%s' not in %s " % (mode,modes)
    t=Time()
    def date_range(*args,**kwargs):
        start_date,end_date=None,None
        args=list(args)
        arg_num=len(args)
        if arg_num>=1:
            if arg_num==1:
                date=args[0]
                if t.is_date(date):
                    start_date=end_date=date
                    args.pop(0)
            elif arg_num>=2:
                start,end=args[0],args[1]
                if t.is_date(start):
                    start_date=start
                    args.pop(0)
                if start_date and t.is_date(end):
                    end_date=end
                    args.pop(0)
                else:
                    end_date=start_date
            if start_date and end_date:
                return start_date,end_date,tuple(args),kwargs
        argv_num=len(sys.argv)
        if argv_num==1:
            start_date=end_date=t.yesterday(sep='')
        else:
            if argv_num==2:
                start_date=end_date=t.date_format(sys.argv[1],sep='')
            elif argv_num>=3:
                start_date,end_date=t.date_format(sys.argv[1],sep=''),t.date_format(sys.argv[2],sep='')
        return start_date,end_date,tuple(args),kwargs
    def loop_by_day(*args,**kwargs):
        start_date,end_date,args,kwargs=date_range(*args,**kwargs)
        for date in t.date_range(start_date,end_date):
            func(date,*args,**kwargs)
    def loop_by_hour(*args,**kwargs):
        date,start_hour,end_hour=None,None,None
        args=list(args)
        arg_num=len(args)
        if arg_num>=1:
            if arg_num==1:
                date=args[0]
                if t.is_date(date):
                    start_hour=end_hour=t.last_hour()
                    args.pop(0)
                if not date:
                    raise RuntimeError('First args %s must be date!' % args[0])
            elif arg_num==2:
                date,start=args[0],args[1]
                if t.is_date(date):
                    args.pop(0)
                if not date:
                    raise RuntimeError('First args %s must be date!' % args[0])
                if date and t.is_hour(start):
                    start_hour=end_hour=start
                    args.pop(0)
                else:
                    end_hour=start_hour
            elif arg_num>=3:
                date,start,end=args[0:3]
                if t.is_date(date):
                    args.pop(0)
                if not date:
                    raise RuntimeError('First args %s must be date!' % args[0])
                if t.is_hour(start):
                    start_hour=start
                    args.pop(0)
                else:
                    start_hour=t.last_hour()
                if t.is_hour(end):
                    end_hour=end
                    args.pop(0)
                else:
                    end_hour=start_hour
            if date and start_hour and end_hour:
                for hour in t.hour_range(start_hour,end_hour):
                    func(date,hour,*args,**kwargs)
                return
        argv_num=len(sys.argv)
        if argv_num==1:
            date=t.yesterday(sep='')
            start_hour=end_hour=t.last_hour()
        elif argv_num==2:
            date=t.date_format(sys.argv[1],sep='')
            start_hour=end_hour=t.last_hour()
        elif argv_num==3:
            date=t.date_format(sys.argv[1],sep='')
            start_hour=end_hour=t.hour_format(sys.argv[2])
        else:
            date=t.date_format(sys.argv[1],sep='')
            start_hour=t.hour_format(sys.argv[2])
            end_hour=t.hour_format(sys.argv[3])
        for hour in t.hour_range(start_hour,end_hour):
            func(date,hour,*args,**kwargs)
    def loop_by_dh(*args,**kwargs):
        start_date,end_date,args,kwargs=date_range(*args,**kwargs)
        for date in t.date_range(start_date,end_date):
            for hour in t.hour_range():
                func(date,hour,*args,**kwargs)
    loop_dict=dict(DAY=loop_by_day,HOUR=loop_by_hour,DH=loop_by_dh)
    @wraps(func)
    def loop(*args,**kwargs):
        f=loop_dict[mode]
        f(*args,**kwargs)
    return loop
 
def capturer(mode='stdout'):
    mode=mode.lower()
    assert mode in ('stdout','stderr'),"Mode must be 'stdout' or 'stderr'"
    def _capture(func):
        @wraps(func)
        def __capture_stdout(*args,**kwargs):
            out=StringIO.StringIO()
            oldout=sys.stdout
            sys.stdout=out
            try:
                result=func(*args,**kwargs)
            finally:
                sys.stdout=oldout
            return out.getvalue(),result
        @wraps(func)
        def __capture_stderr(*args,**kwargs):
            out=StringIO.StringIO()
            oldout=sys.stdout
            sys.stderr=out
            try:
                result=func(*args,**kwargs)
            finally:
                sys.stderr=oldout
            return out.getvalue(),result
        if mode=='stdout':
            return __capture_stdout
        elif mode=='stderr':
            return __capture_stderr
    return _capture

def locker(func):
    lock=RLock()
    @wraps(func)
    def _lock(*args,**kwargs):
        lock.acquire()
        try:
            return func(*args,**kwargs)
        finally:
            lock.release()
    return _lock

def authorizer(roler,auths=globals()):
    def _authorize(func):
        @wraps(func)
        def __authorize(*args,**kwargs):
            if roler not in auths:
                raise Exception('%s is not authorized.' % roler)
            return func(*args,**kwargs)
        return __authorize
    return _authorize

def logger(func=None,level='INFO',name=None,msg=None):
    if func is None:
        return partial(logger,level=level,name=name,msg=msg)
    log_level=getattr(logging,level)
    log_name=name or func.__module__
    log=logging.getLogger(log_name)
    log_msg=msg or func.__name__
    @wraps(func)
    def _logger(*args,**kwargs):
        log.log(log_level,log_msg)
        return func(*args,**kwargs)
    return _logger

def profiler(column='time',limit=5):
    def _profile(func):
        @wraps(func)
        def __profile(*args,**kwargs):
            t=tempfile.mktemp()
            p=profile.Profile()
            p.runcall(func,*args,**kwargs)
            p.dump_stats(t)
            s=pstats.Stats(t)
            s.sort_stats(column).print_stats(limit)
        return __profile
    return _profile

def tracer(func=None,out=sys.stdout,mode='w'):
    if func is None:
        return partial(tracer,out=out,mode=mode)
    if isinstance(out,basestring):
        out=open(out,mode)
    @wraps(func)
    def trace(*args,**kwargs):
        try:
            return func(*args,**kwargs)
        except:
            exc_info=sys.exc_info()
            out.write('%s %s\n' % (str(exc_info[0]),str(exc_info[1])))
            tbs=traceback.extract_tb(exc_info[2])
            for tb in tbs[1:]:
                out.write('  File "%s", line %s, in %s\n    %s\n' % tb)
    return trace

def singleton(cls,*args,**kwargs):
    instances={}
    @wraps(cls)
    def _singleton():
        if cls not in instances:
            instances[cls]=cls(*args,**kwargs)
        return instances[cls]
    return _singleton

def decorator(func):
    def decorate(*args,**kwargs):
       return func(*args,**kwargs)
    decorate.__name__=func.__name__
    decorate.__dict__.update(func.__dict__)
    decorate.__doc__=func.__doc__
    decorate.__module__=func.__module__
    return decorate

def item_wiser(func):
    @wraps(func)
    def wise(args):
        if hasattr(args,'__getitem__'):
            return type(args)(map(func,args))
        return func(args)
    return wise

def attacher(obj,func=None):
    if func is None:
        return partial(attacher,obj)
    setattr(obj,func.__name__,func)
    return func

def logged(level='INFO',name=None,msg=None):
    log_level=getattr(logging,level)
    def _logged(func):
        log_name=name or func.__module__
        log=logging.getLogger(log_name)
        log_msg=msg or func.__name__
        log_info=dict(level=log_level,msg=log_msg)
        @wraps(func)
        def __logged(*args,**kwargs):
            log.log(log_info['level'],log_info['msg'])
            return func(*args,**kwargs)
        @attacher(__logged)
        def set_level(level):
            level=getattr(logging,level)
            log_info['level']=level
        @attacher(__logged)
        def get_level():
            return log_info.get('level')
        @attacher(__logged)
        def get_msg():
            return log_info.get('msg')
        @attacher(__logged)
        def set_msg(msg):
            log_info['msg']=msg
        return __logged
    return _logged

def profiled(func):
    info=dict(ncalls=0)
    @wraps(func)
    def _profiled(*args,**kwargs):
        info['ncalls']+=1
        return func(*args,**kwargs)
    _profiled.ncalls=lambda:info.get('ncalls')
    _profiled.info=lambda:info
    return _profiled

def optional_debuger(func):
    if 'debug' in inspect.getargspec(func).args:
        raise TypeError('debug argument already defined')
    @wraps(func)
    def _optional_debuger(debug=False,*args,**kwargs):
        if debug:
            print "Calling %s" % func.__name__
        return func(*args,**kwargs)
    return _optional_debuger


