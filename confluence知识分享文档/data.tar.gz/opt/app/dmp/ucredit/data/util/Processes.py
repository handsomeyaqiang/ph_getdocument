#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os,sys
from multiprocessing import Process,cpu_count,Pool,Manager
from multiprocessing.managers import BaseManager,BaseProxy
from datetime import datetime

def log(msg):
    line='[{now}] {msg}'.format(now=datetime.now(),msg=msg)
    print line
    
def do_job(func,exit_codes,*args,**kwargs):
    try:
        return func(*args,**kwargs)
    except KeyboardInterrupt:
        os.kill(os.getpid())
    except SystemExit,error:
	exit_code=error.code
        exit_codes.append(exit_code)
        log("System exit: {exit_code}".format(exit_code=exit_code))
        os.kill(os.getpid())
    except Exception,error:
        log("Do job error: {error}".format(error=error))
        raise error
    
def param2str(*args,**kwargs):
    def _get_value(value):
        if value is None:
            return 'None'
        if isinstance(value,basestring):
            return "'%s'" % (value)
        elif isinstance(value,(int,long,float,bool)):
            return repr(value)
        return str(value)
    params=[]
    if args:
        params.append(', '.join(map(_get_value,args)))
    if kwargs:
        params.append(', '.join('{k}={v}'.format(k=k,v=_get_value(v)) for k,v in kwargs.items()))
    return ', '.join(params)
    
class ProcessPool(object):
    
    def __init__(self,processes=None,**kwargs):
        self._pool=Pool(processes=processes,**kwargs)
        self._results=[]
	self._exit_codes=Manager().list()
        
    def put(self,func,*args,**kwargs):
        result=self._pool.apply_async(do_job,args=(func,self._exit_codes)+args,kwds=kwargs)
        log("Put job: {func}({params})".format(func=func.__name__,params=param2str(*args,**kwargs)))
        self._results.append(result)
        
    def wait(self):
        self._pool.close()
        self._pool.join()
        log("All jobs are done")
        if any(self._exit_codes):
            exit_code=[code for code in self._exit_codes if code!=0][0]
            sys.exit(exit_code)
        
    def outs(self):
        log("Output jobs's results")
        for result in self._results:
            yield result.get()
            
    def map(self,func,iter):
        return self._pool.map(func,iter)
    
    def apply(self,func,*args,**kwargs):
        return self._pool.apply(func,args=args,kwds=kwargs)
    
class ObjectManager(BaseManager):
    pass

class SharedObject(object):
    
    def __init__(self,host='localhost',port=5000,auth_key='abcedf'):
        self._host=host
        self._port=port
        if self._host:
            self._manager=ObjectManager(address=(host,port),authkey=auth_key)
        else:
            self._manager=ObjectManager()
        
    def start(self):
        if self._host:
            s=self._manager.get_server()
            s.serve_forever()
        else:
            self._manager.start()
            
    def connect(self):
        if self._host:
            self._manager.connect()
        
    def get(self,name):
        ObjectManager.register(name)
        return getattr(self._manager,name)
    
    def set(self,name,func):
        ObjectManager.register(name,func)

class ObjectProxy(BaseProxy):
    _exposed_=('get','set')
    
    def get(self,name,*args,**kwargs):
        return self._callmethod(name,args=args,kwds=kwargs)
    
    def set(self,name,func):
        return self._callmethod(name,args=(func,))


